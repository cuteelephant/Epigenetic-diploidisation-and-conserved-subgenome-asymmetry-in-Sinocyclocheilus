#!/usr/bin/env bash
set -euo pipefail
BASE=$HOME/mbe_review
D=$BASE/te_tad
TOOLS=$(dirname "$(readlink -f "$0")")
declare -A TE=([tl]=tianlinensis.filteredRepeats.gff [cx]=cx.filteredRepeats.gff)

case ${1:-} in
map)
  for sp in tl cx; do
    [ -s "$BASE/${sp}_AB.fa.fai" ] || samtools faidx "$BASE/${sp}_AB.fa"
    out=$D/$sp/renamed; mkdir -p "$out"
    awk 'NR==FNR{n[$2]++; new[$2]=$1; next}
         {s = ($2 in n) ? (n[$2]==1 ? "ok" : "DUP_LENGTH") : "NO_MATCH"; print $1"\t"(s=="ok"?new[$2]:"NA")"\t"$2"\t"s}' \
      "$BASE/${sp}_AB.fa.fai" "$D/$sp/chromosome_lengths/$sp.chrom.sizes" > "$out/chrom_map.tsv"
    nok=$(awk '$4=="ok"' "$out/chrom_map.tsv" | wc -l)
    nnew=$(cut -f2 "$out/chrom_map.tsv" | grep -v NA | sort -u | wc -l)
    echo "[$sp] mapped $nok / $(wc -l < "$out/chrom_map.tsv") chromosomes; distinct new names $nnew; problems:"
    awk '$4!="ok"' "$out/chrom_map.tsv"
    [ "$nok" -eq "$(wc -l < "$out/chrom_map.tsv")" ] && [ "$nok" -eq "$nnew" ] || { echo "[$sp] mapping not 1:1, stopping"; exit 1; }
    head -3 "$out/chrom_map.tsv"
    rn() { awk -F'\t' -v OFS='\t' 'NR==FNR{m[$1]=$2; next} ($1 in m){$1=m[$1]; print}' "$out/chrom_map.tsv" "$1"; }
    rn "$D/$sp/TE/${TE[$sp]}" > "$out/$sp.TE.gff"
    rn "$D/$sp/TAD_40k_named/${sp}_TADs_40k_boundaries.sorted.bed" | sort -k1,1 -k2,2n > "$out/$sp.TAD_boundaries.bed"
    rn "$D/$sp/TAD_40k_named/${sp}_TADs_40k_domains.sorted.bed" | sort -k1,1 -k2,2n > "$out/$sp.TAD_domains.bed"
    for f in "$D/$sp/TE/${TE[$sp]}" "$out/$sp.TE.gff" "$out/$sp.TAD_boundaries.bed" "$out/$sp.TAD_domains.bed"; do
      printf '  %-60s %s lines\n' "$(basename "$f")" "$(wc -l < "$f")"
    done
  done
  ;;
hicinfo)
  for sp in tl cx; do
    m=$D/$sp/HiC_generation_inputs/${sp}_matrix_norm.mcool
    echo "== $sp"; cooler ls "$m"
    cooler info "$m::resolutions/100000" | grep -E '"(nbins|nnz|sum)"' || true
    python3 -c "import cooler; c=cooler.Cooler('$m::resolutions/100000'); print('weight column present:', 'weight' in c.bins().columns)"
  done
  ;;
pc1)
  for sp in tl cx; do
    out=$D/$sp/renamed
    python3 "$TOOLS/hic_pc1.py" --mcool "$D/$sp/HiC_generation_inputs/${sp}_matrix_norm.mcool" --res 100000 \
      --gd "$D/$sp/PC1_generation_inputs/${sp}_gene_density.100k.bedgraph" --map "$out/chrom_map.tsv" \
      --out "$out/$sp.PC1_100k.bedgraph" --qc "$out/$sp.PC1_100k.qc.tsv" | tee "$out/$sp.PC1_100k.log"
  done
  ;;
*)
  echo "Usage: bash $0 {map|hicinfo|pc1}"; exit 1 ;;
esac
