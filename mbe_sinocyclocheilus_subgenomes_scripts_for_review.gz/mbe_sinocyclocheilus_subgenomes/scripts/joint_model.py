#!/usr/bin/env python3
import argparse, math, os, re, sys
from itertools import combinations
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, mannwhitneyu, fisher_exact

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from meth_tools import load_regions, load_cov, region_sums

NON_TE = ('Simple_repeat', 'Low_complexity', 'Satellite', 'rRNA', 'snRNA', 'tRNA', 'scRNA', 'srpRNA')
FLANK, RES, MIN_READS, N_BOOT, SEED = 2000, 100000, 10, 200, 1
K_RE = re.compile(r'KIMURA80=([0-9.eE+-]+)')


def merge(iv):
    iv = sorted(iv)
    out = []
    for s, e in iv:
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    a = np.array(out, dtype=np.int64).reshape(-1, 2)
    return a[:, 0], a[:, 1], np.concatenate([[0], np.cumsum(a[:, 1] - a[:, 0])])


def covered(m, x):
    S, E, CL = m
    k = np.searchsorted(S, x, 'left')
    out = np.zeros(len(x), dtype=np.int64)
    ok = k > 0
    kk = k[ok] - 1
    out[ok] = CL[kk] + np.minimum(E[kk], x[ok]) - S[kk]
    return out


def window_cov(m, a, b):
    return covered(m, b) - covered(m, a)


def read_te(path):
    te = pd.read_csv(path, sep='\t', header=None, usecols=[0, 2, 3, 4, 8], names=['chr', 'cls', 's', 'e', 'att'],
                     dtype={'chr': str, 'cls': str, 's': np.int64, 'e': np.int64, 'att': str})
    te = te[~te['cls'].str.startswith(NON_TE)]
    te['K'] = te['att'].str.extract(K_RE, expand=False).astype(float)
    return te.drop(columns='att')


def cmd_features(a):
    sp, B = a.sp, a.base
    reg = load_regions(f'{B}/{sp}_AB.gff', f'{B}/homoeolog/{sp}/{sp}.genes.tsv', FLANK)
    genes = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.genes.tsv', sep='\t')[['gene', 'cds_len']]
    reg = reg.merge(genes, on='gene')
    plus = reg['strand'] == '+'
    reg['tss0'] = np.where(plus, reg['b_start'] - 1, reg['b_end'] - 1)
    reg['mid0'] = ((reg['b_start'] - 1 + reg['b_end']) // 2).astype(np.int64)
    up_a, up_b = reg['p_start'].values - 1, reg['p_end'].values
    dn_a = np.where(plus, reg['b_end'], np.maximum(0, reg['b_start'] - 1 - FLANK))
    dn_b = np.where(plus, reg['b_end'] + FLANK, reg['b_start'] - 1)

    te = read_te(f'{B}/te_tad/{sp}/renamed/{sp}.TE.gff')
    k25 = te['K'].quantile(0.25)
    print(f'[{sp}] TE copies {len(te)}; young TE = KIMURA80 < {k25:.4f} (25th percentile)')
    for col in ('up_TE', 'down_TE', 'up_youngTE'):
        reg[col] = 0.0
    segs = []
    for chrom, idx in reg.groupby('chr').indices.items():
        t = te[te['chr'] == chrom]
        if t.empty:
            continue
        m_all = merge(list(zip(t['s'].values - 1, t['e'].values)))
        y = t[t['K'] < k25]
        m_young = merge(list(zip(y['s'].values - 1, y['e'].values))) if len(y) else None
        reg.loc[reg.index[idx], 'up_TE'] = window_cov(m_all, up_a[idx], up_b[idx]) / FLANK
        reg.loc[reg.index[idx], 'down_TE'] = window_cov(m_all, dn_a[idx], dn_b[idx]) / np.maximum(dn_b[idx] - dn_a[idx], 1)
        if m_young is not None:
            reg.loc[reg.index[idx], 'up_youngTE'] = window_cov(m_young, up_a[idx], up_b[idx]) / FLANK
        S, E, _ = m_all
        lo = np.searchsorted(E, up_a[idx], 'right')
        hi = np.searchsorted(S, up_b[idx], 'left')
        for gi, l, h, wa, wb in zip(idx, lo, hi, up_a[idx], up_b[idx]):
            for k in range(l, h):
                s, e = max(S[k], wa), min(E[k], wb)
                if e > s:
                    segs.append((gi, chrom, s + 1, e))
    seg = pd.DataFrame(segs, columns=['gi', 'chr', 's', 'e'])

    pc = pd.read_csv(f'{B}/te_tad/{sp}/renamed/{sp}.PC1_100k.bedgraph', sep='\t', header=None,
                     names=['chr', 'start', 'end', 'PC1'], na_values='NA')
    pcd = {c: dict(zip(d['start'] // RES, d['PC1'])) for c, d in pc.groupby('chr')}
    reg['PC1'] = [pcd.get(c, {}).get(m // RES, np.nan) for c, m in zip(reg['chr'], reg['mid0'])]

    bd = pd.read_csv(f'{B}/te_tad/{sp}/renamed/{sp}.TAD_boundaries.bed', sep='\t', header=None, usecols=[0, 1, 2],
                     names=['chr', 's', 'e'])
    reg['tad_dist'] = np.nan
    for chrom, idx in reg.groupby('chr').indices.items():
        b = bd[bd['chr'] == chrom].sort_values('s')
        if b.empty:
            continue
        x = reg['tss0'].values[idx]
        s, e = b['s'].values, b['e'].values
        k = np.searchsorted(s, x, 'right')
        dl = np.where(k > 0, np.maximum(0, x - e[np.maximum(k - 1, 0)] + 1), np.inf)
        dl = np.where((k > 0) & (x < e[np.maximum(k - 1, 0)]), 0, dl)
        dr = np.where(k < len(s), s[np.minimum(k, len(s) - 1)] - x, np.inf)
        reg.loc[reg.index[idx], 'tad_dist'] = np.minimum(dl, dr)

    SP = sp.upper()
    for tissue in ('eye', 'liver'):
        gm = pd.read_csv(f'{B}/meth/{sp}_{tissue}.gene_meth.tsv', sep='\t').set_index('gene')
        for tag in ('prom', 'body'):
            m = gm[f'rep1_{tag}_meth'] + gm[f'rep2_{tag}_meth']
            t = gm[f'rep1_{tag}_total'] + gm[f'rep2_{tag}_total']
            reg[f'{tissue}_{tag}_total'] = t.reindex(reg['gene']).values
            reg[f'{tissue}_{tag}_meth'] = (m / t.where(t > 0)).reindex(reg['gene']).values
        mm = np.zeros(len(reg)); tt = np.zeros(len(reg))
        for rep in (1, 2):
            cov, _ = load_cov(f'{B}/wgbs/meth/{SP}_{tissue}_rep{rep}_pe.deduplicated.bismark.cov.gz')
            _, m_, t_ = region_sums(cov, seg, 's', 'e')
            np.add.at(mm, seg['gi'].values, m_)
            np.add.at(tt, seg['gi'].values, t_)
        reg[f'{tissue}_teprom_total'] = tt
        reg[f'{tissue}_teprom_meth'] = np.where(tt > 0, mm / np.maximum(tt, 1), np.nan)
        print(f'[{sp}] {tissue}: genes with >= {MIN_READS} reads on promoter TE CpGs: {int((tt >= MIN_READS).sum())}')

    cols = ['gene', 'sub', 'chr', 'strand', 'tss0', 'mid0', 'cds_len', 'up_TE', 'down_TE', 'up_youngTE', 'PC1',
            'tad_dist'] + [c for c in reg.columns if c.startswith(('eye_', 'liver_'))]
    os.makedirs(f'{B}/analysis', exist_ok=True)
    reg[cols].to_csv(f'{B}/analysis/joint_features_{sp}.tsv.gz', sep='\t', index=False, na_rep='NA')
    print(reg[['up_TE', 'down_TE', 'up_youngTE', 'PC1', 'tad_dist']].describe().round(3).to_string())
    print(f'-> {B}/analysis/joint_features_{sp}.tsv.gz')


def r2_subsets(R, p):
    out = {frozenset(): 0.0}
    for k in range(1, p + 1):
        for S in combinations(range(p), k):
            S = list(S)
            rxx, rxy = R[np.ix_(S, S)], R[S, p]
            try:
                out[frozenset(S)] = float(rxy @ np.linalg.solve(rxx, rxy))
            except np.linalg.LinAlgError:
                out[frozenset(S)] = np.nan
    return out


def lmg(R, p):
    r2 = r2_subsets(R, p)
    w = {k: math.factorial(k) * math.factorial(p - k - 1) / math.factorial(p) for k in range(p)}
    imp = np.zeros(p)
    for S, v in r2.items():
        for j in range(p):
            if j not in S:
                imp[j] += w[len(S)] * (r2[S | {j}] - v)
    return imp, r2[frozenset(range(p))]


def fit(X, y):
    Z = np.column_stack([X, y])
    R = np.corrcoef(Z, rowvar=False)
    p = X.shape[1]
    imp, r2 = lmg(R, p)
    beta = np.linalg.solve(R[:p, :p], R[:p, p])
    return imp, r2, beta


def run_model(d, preds, resp, block, rng, n_boot):
    d = d.dropna(subset=preds + [resp])
    X, y = d[preds].values.astype(float), d[resp].values.astype(float)
    imp, r2, beta = fit(X, y)
    chroms = np.unique(block[d.index])
    bidx = {c: np.where(block[d.index] == c)[0] for c in chroms}
    bi, br, bb = [], [], []
    for _ in range(n_boot):
        pick = np.concatenate([bidx[c] for c in rng.choice(chroms, len(chroms), replace=True)])
        i_, r_, b_ = fit(X[pick], y[pick])
        bi.append(i_); br.append(r_); bb.append(b_)
    bi, bb = np.array(bi), np.array(bb)
    ci = lambda v: (np.nanpercentile(v, 2.5, axis=0), np.nanpercentile(v, 97.5, axis=0))
    (ilo, ihi), (blo, bhi), (rlo, rhi) = ci(bi), ci(bb), ci(np.array(br))
    rows = [dict(predictor=p, beta=beta[k], beta_lo=blo[k], beta_hi=bhi[k], LMG=imp[k], LMG_lo=ilo[k],
                 LMG_hi=ihi[k], share_of_R2=imp[k] / r2 if r2 > 0 else np.nan) for k, p in enumerate(preds)]
    return rows, dict(n=len(d), R2=r2, R2_lo=rlo, R2_hi=rhi)


def cmd_model(a):
    B = a.base
    rng = np.random.default_rng(SEED)
    lmg_rows, sum_rows, comp_rows = [], [], []
    for sp in ('tl', 'cx'):
        f = pd.read_csv(f'{B}/analysis/joint_features_{sp}.tsv.gz', sep='\t').set_index('gene')
        f['log_tad'] = np.log10(f['tad_dist'] + 1000)
        f['log_len'] = np.log10(f['cds_len'])
        af = f'{B}/atac/promoter_counts_{sp}.tsv'
        atac = pd.read_csv(af, sep='\t').set_index('gene')['pooled'] if os.path.exists(af) else None
        tp = pd.read_csv(f'{B}/rna/counts/{sp}.tpm.tsv', sep='\t').set_index('gene')
        m = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
        m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)][['A_gene', 'B_gene', 'A_chr', 'HE']].reset_index(drop=True)

        base_feats = ['up_TE', 'down_TE', 'up_youngTE', 'PC1', 'log_tad', 'log_len']
        for tissue in ('eye', 'liver', 'muscle'):
            cols = [c for c in tp.columns if c.startswith(f'{tissue}_')]
            if not cols:
                continue
            tpm = tp[cols].mean(axis=1)
            feats = base_feats + ([f'{tissue}_prom_meth', f'{tissue}_body_meth'] if tissue != 'muscle' else [])
            d = m.copy()
            for s in 'AB':
                g = d[f'{s}_gene']
                d[f'tpm_{s}'] = tpm.reindex(g).values
                for c in feats + ([f'{tissue}_prom_total', f'{tissue}_body_total', f'{tissue}_teprom_meth',
                                   f'{tissue}_teprom_total'] if tissue != 'muscle' else []):
                    d[f'{c}_{s}'] = f[c].reindex(g).values
            keep = (np.maximum(d['tpm_A'], d['tpm_B']) >= 1)
            if tissue != 'muscle':
                for s in 'AB':
                    keep &= (d[f'{tissue}_prom_total_{s}'] >= MIN_READS) & (d[f'{tissue}_body_total_{s}'] >= MIN_READS)
            d = d[keep].copy()
            d['log2FC'] = np.log2((d['tpm_B'] + 1) / (d['tpm_A'] + 1))
            d['abs_log2FC'] = d['log2FC'].abs()
            names = {}
            for c in feats:
                short = c.replace(f'{tissue}_', '')
                d[f'd_{short}'] = d[f'{c}_B'] - d[f'{c}_A']
                d[f'ad_{short}'] = d[f'd_{short}'].abs()
                names[c] = short
            dp = [f'd_{names[c]}' for c in feats]
            ap_ = [f'ad_{names[c]}' for c in feats]
            block = d['A_chr'].values
            d = d.reset_index(drop=True)
            block = d['A_chr'].values
            specs = [('signed', dp, 'log2FC'), ('magnitude', ap_, 'abs_log2FC')]
            if tissue != 'muscle':
                ok = (d[f'{tissue}_teprom_total_A'] >= MIN_READS) & (d[f'{tissue}_teprom_total_B'] >= MIN_READS)
                d['d_teprom_meth'] = np.where(ok, d[f'{tissue}_teprom_meth_B'] - d[f'{tissue}_teprom_meth_A'], np.nan)
                d['ad_teprom_meth'] = d['d_teprom_meth'].abs()
                specs += [('signed_M2', dp + ['d_teprom_meth'], 'log2FC'),
                          ('magnitude_M2', ap_ + ['ad_teprom_meth'], 'abs_log2FC')]
            if tissue == 'liver' and atac is not None:
                nA, nB = atac.reindex(d['A_gene']).values, atac.reindex(d['B_gene']).values
                d['d_atac'] = np.where(nA + nB >= 20, np.log2((nB + 1) / (nA + 1)), np.nan)
                d['ad_atac'] = d['d_atac'].abs()
                specs += [('signed_M3', dp + ['d_atac'], 'log2FC'), ('magnitude_M3', ap_ + ['ad_atac'], 'abs_log2FC')]
            for pset, dd in (('all', d), ('noHE', d[d['HE'] == 'none'])):
                for name, preds, resp in specs:
                    rows, s = run_model(dd, preds, resp, block, rng, a.boot)
                    key = dict(species=sp, tissue=tissue, model=name, pair_set=pset)
                    sum_rows.append({**key, **s})
                    lmg_rows += [{**key, **r} for r in rows]
                    top = sorted(rows, key=lambda r: -r['LMG'])[:3]
                    print(f"{sp}\t{tissue}\t{name}\t{pset}\tn={s['n']}\tR2={s['R2']:.4f} [{s['R2_lo']:.4f}-{s['R2_hi']:.4f}]\t" +
                          '; '.join(f"{r['predictor']} {100 * r['share_of_R2']:.0f}%" for r in top), flush=True)

            if tissue == 'muscle':
                sameA = (d['PC1_A'] > 0) & (d['PC1_B'] > 0); sameB = (d['PC1_A'] < 0) & (d['PC1_B'] < 0)
                diff = ((d['PC1_A'] > 0) & (d['PC1_B'] < 0)) | ((d['PC1_A'] < 0) & (d['PC1_B'] > 0))
                x, y = d.loc[diff, 'abs_log2FC'], d.loc[sameA | sameB, 'abs_log2FC']
                comp_rows.append(dict(species=sp, test='|log2FC| muscle: different vs same compartment',
                                      n1=len(x), n2=len(y), value1=x.median(), value2=y.median(),
                                      p=mannwhitneyu(x, y).pvalue))
                r = spearmanr(d['ad_log_tad'], d['abs_log2FC'], nan_policy='omit')
                comp_rows.append(dict(species=sp, test='Spearman |delta log TAD-boundary distance| vs |log2FC| muscle',
                                      n1=int(d['ad_log_tad'].notna().sum()), value1=r[0], p=r[1]))
                g = f.join(np.log2(tpm + 1).rename('logtpm'))
                r = spearmanr(g['PC1'], g['logtpm'], nan_policy='omit')
                comp_rows.append(dict(species=sp, test='Spearman PC1 vs log2(TPM+1) muscle, all genes',
                                      n1=int(g['PC1'].notna().sum()), value1=r[0], p=r[1]))
        g = f.dropna(subset=['PC1'])
        tab = [[int(((g['sub'] == s) & (g['PC1'] > 0)).sum()), int(((g['sub'] == s) & (g['PC1'] <= 0)).sum())] for s in 'BA']
        orr, p = fisher_exact(tab)
        comp_rows.append(dict(species=sp, test='fraction of genes in A compartment: SubB vs SubA', n1=sum(tab[0]),
                              n2=sum(tab[1]), value1=tab[0][0] / sum(tab[0]), value2=tab[1][0] / sum(tab[1]),
                              OR=orr, p=p))

    os.makedirs(f'{B}/analysis', exist_ok=True)
    pd.DataFrame(lmg_rows).round(5).to_csv(f'{B}/analysis/joint_model_lmg.tsv', sep='\t', index=False)
    pd.DataFrame(sum_rows).round(5).to_csv(f'{B}/analysis/joint_model_summary.tsv', sep='\t', index=False)
    ct = pd.DataFrame(comp_rows)
    ct.to_csv(f'{B}/analysis/compartment_tests.tsv', sep='\t', index=False)
    print('\n' + ct.to_string(index=False))
    print(f'-> {B}/analysis/joint_model_lmg.tsv, joint_model_summary.tsv, compartment_tests.tsv')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('features'); p.add_argument('--sp', required=True, choices=['tl', 'cx'])
    p = sp.add_parser('model'); p.add_argument('--boot', type=int, default=N_BOOT)
    a = ap.parse_args()
    {'features': cmd_features, 'model': cmd_model}[a.cmd](a)


if __name__ == '__main__':
    main()
