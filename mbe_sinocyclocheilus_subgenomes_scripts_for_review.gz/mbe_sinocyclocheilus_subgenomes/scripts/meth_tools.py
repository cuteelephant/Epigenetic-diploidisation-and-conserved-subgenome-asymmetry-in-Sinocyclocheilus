#!/usr/bin/env python3
import argparse
import numpy as np
import pandas as pd


def attrs(s):
    d = {}
    for kv in s.strip().strip(';').split(';'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            d[k.strip()] = v.strip()
    return d


def load_regions(gff, genes_tsv, flank):
    genes = pd.read_csv(genes_tsv, sep='\t', dtype=str)
    want = dict(zip(genes['mrna'], genes['gene']))
    sub = dict(zip(genes['gene'], genes['sub']))
    rows = []
    with open(gff) as f:
        for line in f:
            if line.startswith('#'):
                continue
            p = line.rstrip('\n').split('\t')
            if len(p) < 9 or p[2] not in ('mRNA', 'transcript'):
                continue
            mid = attrs(p[8]).get('ID')
            if mid not in want:
                continue
            chrom, s, e, strand = p[0], int(p[3]), int(p[4]), p[6]
            ps, pe = (max(1, s - flank), s - 1) if strand == '+' else (e + 1, e + flank)
            rows.append((want[mid], sub[want[mid]], chrom, strand, ps, pe, s, e))
    return pd.DataFrame(rows, columns=['gene', 'sub', 'chr', 'strand', 'p_start', 'p_end', 'b_start', 'b_end'])


def region_sums(cov, reg, s_col, e_col):
    n = np.zeros(len(reg), np.int64)
    m = np.zeros(len(reg), np.int64)
    t = np.zeros(len(reg), np.int64)
    for chrom, idx in reg.groupby('chr').indices.items():
        c = cov.get(chrom)
        if c is None:
            continue
        pos, cm, ct = c
        i0 = np.searchsorted(pos, reg[s_col].values[idx], 'left')
        i1 = np.searchsorted(pos, reg[e_col].values[idx], 'right')
        n[idx] = i1 - i0
        m[idx] = cm[i1] - cm[i0]
        t[idx] = ct[i1] - ct[i0]
    return n, m, t


def load_cov(path):
    df = pd.read_csv(path, sep='\t', header=None, usecols=[0, 1, 4, 5], names=['chr', 'pos', 'm', 'u'],
                     dtype={'chr': str, 'pos': np.int64, 'm': np.int64, 'u': np.int64}, compression='infer')
    out = {}
    for chrom, d in df.groupby('chr', sort=False):
        d = d.sort_values('pos')
        tot = (d['m'] + d['u']).values
        out[chrom] = (d['pos'].values,
                      np.concatenate([[0], np.cumsum(d['m'].values)]),
                      np.concatenate([[0], np.cumsum(tot)]))
    return out, len(df)


def cmd_regions(a):
    reg = load_regions(a.gff, a.genes, a.flank)
    res = reg[['gene', 'sub', 'chr', 'strand']].copy()
    for path, name in zip(a.cov, a.names):
        cov, ncpg = load_cov(path)
        for tag, s_col, e_col in (('prom', 'p_start', 'p_end'), ('body', 'b_start', 'b_end')):
            n, m, t = region_sums(cov, reg, s_col, e_col)
            res[f'{name}_{tag}_nCpG'] = n
            res[f'{name}_{tag}_meth'] = m
            res[f'{name}_{tag}_total'] = t
            res[f'{name}_{tag}_level'] = np.where(t > 0, m / np.maximum(t, 1), np.nan).round(4)
        ok = res[f'{name}_prom_total'] >= a.min_reads
        med = res[ok].groupby('sub')[f'{name}_prom_level'].median()
        print(f'{name}: {ncpg} covered CpGs; genes {len(res)}; promoter >= {a.min_reads} reads: {ok.sum()} '
              f'({100 * ok.mean():.1f}%); median promoter level subA {med.get("A", np.nan):.3f} '
              f'subB {med.get("B", np.nan):.3f}')
    res.to_csv(a.out, sep='\t', index=False, na_rep='NA')
    if len(a.names) == 2:
        x, y = a.names
        for tag in ('prom', 'body'):
            ok = (res[f'{x}_{tag}_total'] >= a.min_reads) & (res[f'{y}_{tag}_total'] >= a.min_reads)
            r = np.corrcoef(res.loc[ok, f'{x}_{tag}_level'], res.loc[ok, f'{y}_{tag}_level'])[0, 1] if ok.sum() > 2 else np.nan
            print(f'replicate r ({tag}, both >= {a.min_reads} reads): n={ok.sum()} r={r:.3f}')
    print(f'-> {a.out}')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('regions')
    p.add_argument('--gff', required=True); p.add_argument('--genes', required=True)
    p.add_argument('--cov', nargs='+', required=True); p.add_argument('--names', nargs='+', required=True)
    p.add_argument('--flank', type=int, default=2000); p.add_argument('--min-reads', type=int, default=10)
    p.add_argument('--out', required=True)
    a = ap.parse_args()
    assert len(a.cov) == len(a.names), '--cov and --names must have the same length'
    cmd_regions(a)


if __name__ == '__main__':
    main()
