#!/usr/bin/env python3
import argparse, os, re, sys
import numpy as np
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Border, Side
from openpyxl.utils import get_column_letter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
T_METH, T_FC = 0.3, 1.0
SPN = {'tl': 'S. tianlinensis', 'cx': 'S. longibarbatus'}
F = Font(name='Arial', size=9)
FB = Font(name='Arial', size=9, bold=True)
FI = Font(name='Arial', size=9, bold=True, italic=True)
LINE = Border(bottom=Side(style='thin'))
WARN = []


def sig(v):
    if isinstance(v, (float, np.floating)):
        if not np.isfinite(v):
            return None
        return float(f'{v:.6g}')
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    return v


def write_sheet(wb, num, legend, blocks, side_by_side=None):
    name = f'Supplementary Table {num}'
    if name in wb.sheetnames:
        del wb[name]
    ws = wb.create_sheet(name)
    if num >= 10 and num not in (15, 19, 23):
        legend = legend.rstrip() + ' Species codes: tl, S. tianlinensis; cx, S. longibarbatus.'
    ws.cell(1, 1, f'Supplementary Table {num}. {legend}').font = FB
    r = 3
    widths = {}
    for sub, df in blocks:
        if df is None or df.empty:
            continue
        if sub:
            ws.cell(r, 1, sub).font = FI
            r += 1
        for j, c in enumerate(df.columns, 1):
            cell = ws.cell(r, j, str(c))
            cell.font, cell.border = FB, LINE
            widths[j] = max(widths.get(j, 0), len(str(c)))
        r += 1
        for row in df.itertuples(index=False):
            for j, v in enumerate(row, 1):
                v = sig(v)
                if v is None or (isinstance(v, float) and np.isnan(v)):
                    continue
                ws.cell(r, j, v).font = F
            r += 1
        for j in range(1, df.shape[1] + 1):
            s = df.iloc[:200, j - 1].astype(str).str.len()
            widths[j] = max(widths.get(j, 0), int(s.max()) if len(s) else 0)
        r += 1
    for j, w in widths.items():
        ws.column_dimensions[get_column_letter(j)].width = min(max(8, w + 1), 45)
    ws.freeze_panes = 'A4' if len(blocks) == 1 and not blocks[0][0] else None
    print(f'  Table S{num}: {sum(len(b[1]) for b in blocks if b[1] is not None)} rows')


def side(dfs, gap=1):
    out = []
    for i, (lab, d) in enumerate(dfs):
        d = d.reset_index(drop=True).copy()
        d.columns = pd.MultiIndex.from_product([[lab], d.columns])
        out.append(d)
        if i < len(dfs) - 1:
            out.append(pd.DataFrame({(' ' * (i + 1), ''): [None] * len(d)}))
    t = pd.concat(out, axis=1)
    top = [c[0] if k == 0 or t.columns[k - 1][0] != c[0] else '' for k, c in enumerate(t.columns)]
    hdr = pd.DataFrame([[c[1] for c in t.columns]], columns=top)
    body = pd.DataFrame(t.values, columns=top)
    return pd.concat([hdr, body], ignore_index=True)


def read(p, **k):
    return pd.read_csv(p, sep='\t', **k)


def guard(num, fn):
    try:
        fn()
    except Exception as e:
        WARN.append(f'Table S{num} skipped: {type(e).__name__}: {e}')
        print(f'  WARNING {WARN[-1]}')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    ap.add_argument('--out', default=None)
    a = ap.parse_args()
    B = a.base
    A, FG = f'{B}/analysis', f'{B}/figs'
    print('loading the original workbook ...', flush=True)
    wb = load_workbook(f'{B}/Supplemental_Tables.xlsx')
    for n in (10, 11, 12, 13, 14, 16, 17, 18):
        if f'Supplementary Table {n}' in wb.sheetnames:
            del wb[f'Supplementary Table {n}']
    pairs = read(f'{A}/methexpr_pairs.tsv.gz', dtype={'individual': str, 'HE': str})
    master = {sp: read(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', dtype={'HE': str, 'A_chr': str, 'B_chr': str})
              for sp in ('tl', 'cx')}
    strict = {sp: m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)].reset_index(drop=True) for sp, m in master.items()}

    def s10(sp, num):
        from bias_stats import moderated_t, bh
        tp = read(f'{B}/rna/counts/{sp}.tpm.tsv').set_index('gene')
        m = strict[sp][['A_gene', 'B_gene', 'A_chr', 'B_chr', 'HE']].copy()
        tissues = sorted({c.rsplit('_', 1)[0] for c in tp.columns if re.fullmatch(r'.+_\d+', c)},
                         key=lambda x: (x not in ('eye', 'liver'), x))
        for t in tissues:
            reps = sorted(c for c in tp.columns if re.fullmatch(rf'{t}_\d+', c))
            Am, Bm = tp[reps].reindex(m['A_gene']).values, tp[reps].reindex(m['B_gene']).values
            ok = np.isfinite(Am).all(1) & np.isfinite(Bm).all(1) & (np.maximum(Am.mean(1), Bm.mean(1)) >= 1)
            r = np.log2((Bm + 1) / (Am + 1))
            m[f'{t}_TPM_A'], m[f'{t}_TPM_B'] = Am.mean(1), Bm.mean(1)
            m[f'{t}_log2FC'] = np.where(ok, r.mean(1), np.nan)
            if len(reps) >= 2:
                q = np.full(len(m), np.nan)
                _, _, p, _ = moderated_t(r[ok])
                q[ok] = bh(p)
                m[f'{t}_FDR'] = q
                fc = m[f'{t}_log2FC']
                m[f'{t}_class'] = np.where(~ok, '', np.where(q >= 0.05, 'not significant',
                                           np.where(fc >= T_FC, 'SubB-biased', np.where(fc <= -T_FC, 'SubA-biased',
                                                                                         'significant, < 2-fold'))))
            else:
                fc = m[f'{t}_log2FC']
                m[f'{t}_class'] = np.where(~ok, '', np.where(fc >= T_FC, 'SubB >= 2-fold', np.where(
                    fc <= -T_FC, 'SubA >= 2-fold', '< 2-fold')))
        nrep = {t: len([c for c in tp.columns if re.fullmatch(rf'{t}_\d+', c)]) for t in tissues}
        write_sheet(wb, num, f'Homoeolog expression bias of strict 1:1 SubA-SubB pairs in {SPN[sp]}, per tissue '
                    f'(replicates: ' + ', '.join(f'{t} {n}' for t, n in nrep.items()) + '). TPM = mean over replicates; '
                    'log2FC = mean over replicates of log2[(TPM_B + 1)/(TPM_A + 1)], pairs with max(TPM) >= 1. '
                    'Tissues with replicates: moderated t-test (empirical-Bayes variance), Benjamini-Hochberg FDR; '
                    'biased = FDR < 0.05 and |log2FC| >= 1. Single-sample tissues: fold change only (descriptive). '
                    'HE: overlap with homoeologous-exchange signatures (published or recalibrated calls).',
                    [(None, m)])
    guard(10, lambda: s10('tl', 10))
    guard(11, lambda: s10('cx', 11))

    def s12():
        blocks = []
        p = f'{FG}/fig3/source_data/fig3d_te_density_age.tsv'
        if os.path.exists(p):
            blocks.append(('Mean paired difference (lower - higher copy) with bootstrap 95% CI', read(p)))
        blocks.append(('Paired tests, original form (bridge to the first submission)', read(f'{A}/bridge_te.tsv')))
        if os.path.exists(f'{A}/extra_teclass.tsv'):
            blocks.append(('Kimura K by TE class and flank (mean paired difference x 100, bootstrap 95% CI; '
                           'TE-copy level Mann-Whitney)', read(f'{A}/extra_teclass.tsv')))
        if os.path.exists(f'{A}/extra_tedist.tsv'):
            blocks.append(('Distance of flanking TE midpoints to the gene boundary (bp; Kolmogorov-Smirnov and '
                           'Mann-Whitney at the TE-copy level, paired Wilcoxon at the pair level)',
                           read(f'{A}/extra_tedist.tsv')))
        write_sheet(wb, 12, 'Transposable elements (TEs) in the 2-kb flanks of the lower- vs higher-expressed copy of '
                    'homoeolog pairs biased >= 2-fold (pooled replicates, eye and liver). TE cover = fraction of the flank '
                    'covered by TEs; young TE = Kimura distance below the species 25th percentile; K = median Kimura '
                    'distance of the flanking TE copies; also by TE class and flank, and the distance of flanking TE '
                    'midpoints to the gene boundary. Paired Wilcoxon signed-rank tests; Mann-Whitney U and '
                    'Kolmogorov-Smirnov tests for TE copies.',
                    blocks)
    guard(12, s12)

    def s13():
        blocks = [('Fraction of genes and 100-kb bins in the A compartment', read(f'{FG}/fig4/source_data/fig4a_compartment_occupancy.tsv')),
                  ('Compartment configuration of homoeolog pairs and muscle expression', read(f'{FG}/fig4/source_data/fig4c_compartment_pairs_muscle.tsv')),
                  ('Tests', read(f'{A}/compartment_tests.tsv'))]
        write_sheet(wb, 13, 'A/B compartments (100-kb PC1 from muscle Hi-C, oriented by gene density) by subgenome. '
                    'Pair-level comparisons use muscle RNA-seq only (the Hi-C tissue). Exact binomial 95% CI for fractions; '
                    'Fisher exact test for SubB vs SubA; bootstrap 95% CI for medians.', blocks)
    guard(13, s13)

    def s14():
        q = []
        for sp in ('tl', 'cx'):
            d = read(f'{B}/te_tad/{sp}/renamed/{sp}.PC1_100k.qc.tsv'); d.insert(0, 'species', sp); q.append(d)
        cov = []
        for sp in ('tl', 'cx'):
            lg = f'{B}/te_tad/{sp}/renamed/{sp}.PC1_100k.log'
            if os.path.exists(lg):
                cov += [dict(species=sp, coverage=l.strip()) for l in open(lg) if 'median cis contacts per bin' in l]
        blocks = [('Per chromosome: eigenvector chosen (PC1 or PC2), correlation with gene density, explained fraction',
                   pd.concat(q)), ('Hi-C coverage at the resolutions used', pd.DataFrame(cov))]
        p = f'{FG}/supp/source_data/figS14b_compartment_expression_te_tad.tsv'
        if os.path.exists(p):
            blocks.append(('PC1 vs muscle expression and TE cover; TAD-boundary distance vs expression divergence', read(p)))
        write_sheet(wb, 14, 'Compartment eigenvector quality control. Per chromosome, the eigenvector of the '
                    'observed/expected correlation matrix most strongly correlated with gene density was kept and oriented '
                    'so that positive values are gene-rich (A compartment). Spearman correlations.', blocks)
    guard(14, s14)

    def s16():
        h = read(f'{A}/he_calls_legacy.tsv', dtype={'A_chr': str, 'B_chr': str})
        h = h.assign(length_kb=((h['A_end'] - h['A_start']) / 1000).round(1))
        cols = ['HE_type', 'A_chr', 'A_start', 'A_end', 'B_chr', 'B_start', 'B_end', 'n_windows', 'length_kb']
        h = h.rename(columns={'type': 'HE_type'})
        h['Species'] = h['species'].map(SPN)
        h['Call_set'] = h['set'].map({'recalibrated': 'recalibrated (used)', 'published': 'published thresholds'})
        h['_o'] = h['species'].map({'tl': 0, 'cx': 1}) * 10 + h['set'].map({'recalibrated': 0, 'published': 1})
        h = h.sort_values(['_o', 'A_chr', 'A_start'])[['Species', 'Call_set'] + cols]
        write_sheet(wb, 16, 'Signatures of homoeologous exchanges (HEs) in S. tianlinensis and S. longibarbatus. '
                    'Recalibrated calls use symmetric thresholds (HI = median B / median A, LO = its inverse, medians over '
                    'partnered windows); published-threshold calls are listed for comparison. B coordinates from the '
                    'partner windows. Detection power was estimated by simulating exchanges of 5, 10 and 20 windows in '
                    'each direction; sequence evidence compares A-B identity, TE composition similarity and homoeolog Ks '
                    'inside vs outside the calls.',
                    [('HE calls', h), ('Detection power', read(f'{A}/he_power_legacy.tsv')),
                     ('Sequence evidence', read(f'{A}/he_sequence_evidence_legacy.tsv'))])
    guard(16, s16)

    guard(17, lambda: write_sheet(
        wb, 17, 'Whole-genome bisulphite sequencing (WGBS): alignment statistics and global methylation for all '
        'libraries (eye and liver, two individuals per species; Bismark, unique alignments only, deduplicated).',
        [(None, read(f'{B}/wgbs/wgbs_qc.tsv'))] + ([('Replicate concordance', read(f'{B}/wgbs/wgbs_repcor.tsv'))]
                                                  if os.path.exists(f'{B}/wgbs/wgbs_repcor.tsv') else [])))

    def s18():
        cat = lambda dm, fc: np.select(
            [(dm <= -T_METH) & (fc >= T_FC), (dm >= T_METH) & (fc <= -T_FC),
             ((dm <= -T_METH) & (fc <= -T_FC)) | ((dm >= T_METH) & (fc >= T_FC)),
             (dm.abs() >= T_METH) & (fc.abs() < T_FC), (fc.abs() >= T_FC) & (dm.abs() < T_METH)],
            ['A_silenced', 'B_silenced', 'Discordant', 'Meth_asym_only', 'Expr_asym_only'], 'Balanced')
        blocks = []
        for t in ('eye', 'liver'):
            dfs = []
            for sp in ('tl', 'cx'):
                gm = read(f'{B}/meth/{sp}_{t}.gene_meth.tsv').set_index('gene')
                mr = gm['rep1_prom_meth'] + gm['rep2_prom_meth']
                d = pairs[(pairs['species'] == sp) & (pairs['tissue'] == t) & (pairs['individual'] == 'pooled')]
                o = pd.DataFrame({'SG1(B)_gene': d['B_gene'].values, 'SG2(A)_gene': d['A_gene'].values,
                                  'B_Meth_Level': d['meth_B'].values, 'A_Meth_Level': d['meth_A'].values,
                                  'DeltaMeth_B_minus_A': d['dMeth'].values, f'B_TPM_{t}': d['tpm_B'].values,
                                  f'A_TPM_{t}': d['tpm_A'].values, 'Log2FC_TPM_B_over_A': d['log2FC'].values,
                                  'B_Meth_Reads': mr.reindex(d['B_gene']).values, 'B_Total_Reads': d['tot_B'].values,
                                  'A_Meth_Reads': mr.reindex(d['A_gene']).values, 'A_Total_Reads': d['tot_A'].values,
                                  'category': cat(d['dMeth'].reset_index(drop=True), d['log2FC'].reset_index(drop=True))})
                dfs.append((SPN[sp], o))
            blocks.append((f'{t.capitalize()} (WGBS rep1 + rep2 reads pooled; TPM = mean of three RNA-seq replicates)',
                           side(dfs)))
        write_sheet(wb, 18, 'Genome-wide classification of strict 1:1 homoeolog pairs by promoter methylation asymmetry '
                    'and expression bias in S. tianlinensis and S. longibarbatus. Promoter = 2 kb upstream of the TSS; '
                    'both copies >= 10 reads; max(TPM) >= 1. dMeth = B - A; log2FC = log2[(TPM_B + 1)/(TPM_A + 1)]. '
                    'A_silenced: dMeth <= -0.3 and log2FC >= 1; B_silenced: dMeth >= 0.3 and log2FC <= -1; Discordant: '
                    'the more methylated copy is the more expressed one; Meth_asym_only: |dMeth| >= 0.3, |log2FC| < 1; '
                    'Expr_asym_only: |log2FC| >= 1, |dMeth| < 0.3; Balanced: neither. SG1 = SubB, SG2 = SubA in both '
                    'species (the S. longibarbatus columns of the first-submission table were inverted; see Response).',
                    blocks)
    guard(18, s18)

    def s20():
        q = read(f'{B}/rna/rna_qc.tsv')
        excl = {l.strip() for l in open(f'{B}/rna/exclude.txt') if l.strip()} if os.path.exists(f'{B}/rna/exclude.txt') else set()
        if {'species', 'sample'} <= set(q.columns):
            key = q['species'].astype(str) + '_' + q['sample'].astype(str)
        else:
            key = q[q.columns[0]].astype(str)
        n0 = len(q)
        q = q[~key.isin(excl)]
        print(f'  S20: {n0 - len(q)} excluded libraries removed ({len(excl)} listed in rna/exclude.txt)')
        write_sheet(wb, 20, 'RNA-seq libraries used in this study: read numbers and alignment (HISAT2) with the fractions of '
                    'uniquely aligned, multi-mapped and assigned fragments (featureCounts, MAPQ >= 10; multi-mapping '
                    'fragments are not counted).', [(None, q)])
    guard(20, s20)
    guard(21, lambda: write_sheet(wb, 21, 'Liver ATAC-seq libraries: alignment (bowtie2 with a mitochondrial decoy, '
                                  'MAPQ >= 30), mitochondrial fraction, duplication, TSS enrichment, FRiP and replicate '
                                  'agreement.', [(None, read(f'{B}/atac/atac_qc.tsv'))]))

    def s22():
        rows = {}
        for sp in ('tl', 'cx'):
            p = next((x for x in (f'{B}/{sp}QC_table.txt', f'{B}/te_tad/{sp}/{sp}QC_table.txt') if os.path.exists(x)), None)
            if p is None:
                raise FileNotFoundError(f'{B}/{sp}QC_table.txt (hicBuildMatrix QC table)')
            d = read(p).iloc[0]
            rows[SPN[sp]] = d
        t = pd.DataFrame(rows)
        t = t.drop(index='File')
        num = t.apply(pd.to_numeric, errors='coerce')
        groups = [('Read pairs (% of sequenced read pairs)', ['Sequenced reads', 'Pairs mappable, unique and high quality',
                   'Hi-C contacts', 'One mate unmapped', 'One mate not unique', 'Low mapping quality'], 'Sequenced reads'),
                  ('Filtered pairs (% of mappable, unique and high-quality pairs)',
                   [i for i in t.index if i.startswith(('dangling', 'self ligation', 'One mate not close', 'same fragment',
                                                        'self circle', 'duplicated'))], 'Pairs mappable, unique and high quality'),
                  ('Contacts used (% of Hi-C contacts)', [i for i in t.index if i.startswith(('inter', 'Intra', 'Read pair type'))],
                   'Hi-C contacts')]
        blocks = []
        for lab, rows_, den in groups:
            out = pd.DataFrame({'metric': rows_})
            for c in t.columns:
                out[f'{c} count'] = num.loc[rows_, c].values
                out[f'{c} %'] = (num.loc[rows_, c] / num.loc[den, c] * 100).round(2).values
            blocks.append((lab, out))
        blocks.append(('Parameters', pd.DataFrame({'metric': ['Min rest. site distance', 'Max library insert size'],
                                                   **{c: num.loc[['Min rest. site distance', 'Max library insert size'], c].values
                                                      for c in t.columns}})))
        write_sheet(wb, 22, 'Hi-C (muscle) library statistics from hicBuildMatrix (BWA-MEM per mate with -A1 -B4 -E50 -L0). '
                    'Read pairs with an unmapped mate, a non-unique mate or low mapping quality were discarded; only '
                    'uniquely and confidently aligned pairs were used to build the contact matrices.', blocks)
    guard(22, s22)
    guard(23, lambda: write_sheet(wb, 23, 'Correspondence of subgenome names across CS4R species.', [(None, pd.DataFrame(
        [dict(this_study='SubA', Cyprinus_carpio='A', Carassius_auratus='S',
              note='less dominant subgenome; no extant diploid relative of its progenitor is known'),
         dict(this_study='SubB', Cyprinus_carpio='B', Carassius_auratus='L',
              note='dominant subgenome; closest diploid relatives Onychostoma macrolepis, Poropuntius huangchuchieni')]))]))

    def s24():
        out = []
        for sp in ('tl', 'cx'):
            d = strict[sp].copy(); d.insert(0, 'species', sp); out.append(d)
        write_sheet(wb, 24, 'Strict 1:1 syntenic SubA-SubB homoeolog pairs (JCVI, C-score 0.99, homoeologous chromosome '
                    'pair, Ks QC passed) with coordinates, YN00 Ka/Ks and homoeologous-exchange annotation '
                    '(HE_published, HE_recal, HE = union; pairs with HE != none are excluded in all noHE analyses).',
                    [(None, pd.concat(out, ignore_index=True))])
    guard(24, s24)
    guard(25, lambda: write_sheet(wb, 25, 'Biased fractionation: retention status of zebrafish genes projected onto each '
                                  'subgenome with TOGA2 in ten genomes (carp subgenome B and goldfish L scored as SubB), '
                                  'per homoeologous chromosome pair, and lineage-specific losses (genes retained in that '
                                  'subgenome in every other called genome).',
                                  [('Genome-wide', read(f'{A}/fractionation_genomes.tsv')),
                                   ('Per chromosome pair', read(f'{A}/fractionation_chrpairs.tsv')),
                                   ('Lineage-specific losses', read(f'{A}/fractionation_lineage_specific.tsv'))]))
    def s26():
        blocks = [('Bias classes', read(f'{A}/bias_classes.tsv')),
                  ('Clustering along the genome', read(f'{A}/bias_clustering.tsv')),
                  ('Tissue consistency', read(f'{A}/bias_tissue_consistency.tsv'))]
        if os.path.exists(f'{A}/extra_immune.tsv'):
            blocks.append(('Expression balance (|log2FC| < 1) of immune-system pairs (zebrafish orthologue annotated to '
                           'GO:0002376 or a descendant) vs other pairs; Woolf 95% CI, Fisher exact test',
                           read(f'{A}/extra_immune.tsv')))
        write_sheet(wb, 26, 'Homoeolog expression bias: classes per tissue, clustering along the genome '
                    '(permutation within chromosomes), consistency of the lower copy across tissues and balance of '
                    'immune-system pairs.', blocks)
    guard(26, s26)

    def s27():
        blocks = [('Per individual and pooled', read(f'{A}/methexpr_summary.tsv')),
                  ('Threshold grid (pooled)', read(f'{A}/methexpr_grid.tsv')),
                  ('Ortholog quartets', read(f'{A}/quartet_summary.tsv'))]
        p = f'{FG}/fig6/source_data/fig6f_pair_categories.tsv'
        if os.path.exists(p):
            blocks.append(('Pair categories (pooled)', read(p)))
        if os.path.exists(f'{A}/bridge_temeth.tsv'):
            blocks.append(('TE-body methylation by subgenome, per WGBS replicate', read(f'{A}/bridge_temeth.tsv')))
        write_sheet(wb, 27, 'Promoter methylation asymmetry and homoeolog expression bias. Permutation null: dMeth shuffled '
                    'among pairs with the expression-bias distribution of each species kept (10,000 permutations). '
                    'Quartets: lineage-specific change (tl - cx) in dMeth vs log2FC at orthologous homoeolog quartets; '
                    'flips = quartets whose candidate repressed copy is SubA in one species and SubB in the other.', blocks)
    guard(27, s27)
    guard(28, lambda: write_sheet(wb, 28, 'Dosage at ortholog quartets with a candidate repressed copy in one species only '
                                  '(species with the candidate minus the other, relative to quartets without a candidate; '
                                  '"indep": classified in individual 1, measured in RNA replicate 3), and absolute '
                                  'expression of both copies.',
                                  [('Quartets', read(f'{A}/dosage_quartets.tsv')),
                                   ('Absolute expression', read(f'{A}/dosage_absolute.tsv'))]))

    def s29():
        blocks = [('Tests', read(f'{A}/atac_summary.tsv'))]
        p = f'{FG}/fig7/source_data/fig7c_atac_repressed_copy.tsv'
        if os.path.exists(p):
            blocks.append(('Lower copy minus partner promoter accessibility', read(p)))
        write_sheet(wb, 29, 'Liver promoter accessibility (ATAC-seq, Tn5 cut sites within TSS +/- 500 bp, two replicates '
                    'pooled) and homoeolog expression bias / promoter methylation.', blocks)
    guard(29, s29)
    guard(30, lambda: write_sheet(wb, 30, 'TE polarisation by cross-species liftover of the flanks (lineage-specific = '
                                  'present in one species only; shared = present at the orthologous position in both; '
                                  'recent = lineage-specific with Kimura distance below the tl-cx ortholog Ks).',
                                  [('TE classes and ages', read(f'{A}/te_polar_summary.tsv')),
                                   ('Lower vs higher copy (presence)', read(f'{A}/te_polar_pairs.tsv')),
                                   ('Ortholog quartets', read(f'{A}/te_polar_quartets.tsv'))]))
    guard(31, lambda: write_sheet(wb, 31, 'Joint model of homoeolog expression bias: standardised regression of log2FC '
                                  '(signed) or |log2FC| (magnitude) on pair differences in TE cover, young-TE cover, '
                                  'compartment PC1, TAD-boundary distance, CDS length, promoter and gene-body methylation '
                                  '(M2: + promoter-TE methylation; M3: + liver promoter accessibility). LMG = Shapley '
                                  'share of R2; 95% CI from a bootstrap over chromosomes.',
                                  [('Model fit', read(f'{A}/joint_model_summary.tsv')),
                                   ('Relative importance', read(f'{A}/joint_model_lmg.tsv'))]))
    guard(32, lambda: write_sheet(wb, 32, 'Coding-sequence constraint along the tl-cx ortholog branch: aggregated dN/dS '
                                  '(omega) of SubB vs SubA over all quartets, and of the lower vs higher-expressed or '
                                  'candidate repressed vs partner copy; ratio CI from 2,000 bootstrap resamples of quartets.',
                                  [(None, read(f'{A}/orth_omega.tsv'))]))

    def s33():
        p = f'{FG}/fig7/source_data/fig7e_toga_loss.tsv'
        blocks = [('Mantel-Haenszel odds ratios with Robins-Breslow-Greenland 95% CI', read(p))] if os.path.exists(p) else []
        blocks.append(('Permutation tests (L and L+UL definitions)', read(f'{A}/toga_loss_tests.tsv')))
        write_sheet(wb, 33, 'Loss of the homoeologous copy in other genomes (six Sinocyclocheilus; carp and goldfish) by '
                    'expression class of the copy in S. tianlinensis / S. longibarbatus (TOGA2; stratified by subgenome).',
                    blocks)
    guard(33, s33)
    def s34():
        blocks = [('Expression bias: top terms', read(f'{A}/go_enrich_top.tsv'))]
        if os.path.exists(f'{A}/extra_gbm_go_top.tsv'):
            blocks.append(('Gene-body methylation asymmetry (|dMeth_body| >= 0.3 or 0.2, same sign in both WGBS '
                           'replicates): top terms', read(f'{A}/extra_gbm_go_top.tsv')))
        blocks.append(('Expression bias: all tests', read(f'{A}/go_enrich.tsv')))
        if os.path.exists(f'{A}/extra_gbm_go.tsv'):
            g = read(f'{A}/extra_gbm_go.tsv')
            blocks.append(('Gene-body methylation asymmetry: all tests (|dMeth_body| >= 0.3)', g[g['threshold'] == 0.3]))
        write_sheet(wb, 34, 'Gene Ontology (biological process) enrichment of SubA- and SubB-biased pairs and of pairs '
                    'with gene-body methylation asymmetry (all strict CS4R pairs; zebrafish orthologues via TOGA2; '
                    'hypergeometric test, terms with 10-500 genes; top terms: FDR < 0.05 and fold enrichment >= 1.5).',
                    blocks)
    guard(34, s34)

    key = lambda ws: int(re.search(r'(\d+)$', ws.title).group(1)) if re.search(r'(\d+)$', ws.title) else 999
    wb._sheets.sort(key=key)
    out = a.out or f'{B}/Supplemental_Tables_R2.xlsx'
    print('saving ...', flush=True)
    wb.save(out)
    print(f'-> {out}  ({len(wb.sheetnames)} sheets)')
    for w in WARN:
        print('WARNING', w)
    print('Keep as in the first submission: S1-S9, S15. Update by hand: S19 (add the rep2 Methyl-seq library rows).')


if __name__ == '__main__':
    main()
