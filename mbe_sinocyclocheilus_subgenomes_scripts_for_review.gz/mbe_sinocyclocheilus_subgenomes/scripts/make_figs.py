#!/usr/bin/env python3
import argparse, os, re, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import beta as beta_dist, binomtest, fisher_exact, mannwhitneyu, spearmanr, norm

MM = 1 / 25.4
INK, GREY, LIGHT, LIGHTER = '#1f1f1d', '#8a8985', '#cfcec9', '#e9e8e3'
SUB = {'A': '#2a78d6', 'B': '#eb6834'}
SP_NAME = {'tl': 'S. tianlinensis', 'cx': 'S. longibarbatus'}
TISSUE_MK = {'eye': 'o', 'liver': '^', 'muscle': 'D', 'all': 's'}
T_FC, T_METH, MIN_PROM = 1.0, 0.3, 10
GENOMES = [('tianlinensis', 'S. tianlinensis'), ('longibarbatus', 'S. longibarbatus'), ('jii', 'S. jii'),
           ('rhinocerous', 'S. rhinocerous'), ('anshuiensis', 'S. anshuiensis'), ('grahami', 'S. grahami'),
           ('maitianheensis', 'S. maitianheensis'), ('anophthalmus', 'S. anophthalmus'),
           ('Cyprinus_carpio', 'C. carpio'), ('Carassius_auratus', 'C. auratus')]

plt.rcParams.update({
    'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Helvetica', 'Liberation Sans', 'DejaVu Sans'],
    'font.size': 7, 'axes.titlesize': 7, 'axes.labelsize': 7, 'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5,
    'legend.fontsize': 6.5, 'legend.frameon': False, 'legend.handlelength': 1.2, 'legend.borderaxespad': 0.2,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
    'axes.linewidth': 0.6, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'xtick.minor.width': 0.4,
    'xtick.major.size': 2.5, 'ytick.major.size': 2.5, 'xtick.minor.size': 1.5,
    'axes.spines.top': False, 'axes.spines.right': False, 'axes.edgecolor': INK,
    'xtick.color': INK, 'ytick.color': INK, 'axes.labelcolor': INK, 'text.color': INK,
    'lines.linewidth': 0.8, 'savefig.transparent': False, 'figure.facecolor': 'white',
    'mathtext.fontset': 'custom', 'mathtext.rm': 'sans', 'mathtext.it': 'sans:italic', 'mathtext.default': 'regular', 'mathtext.cal': 'sans', 'mathtext.sf': 'sans',
})


def need(path):
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    return path


def read(path, **k):
    return pd.read_csv(need(path), sep='\t', **k)


def save(fig, out, name, src):
    os.makedirs(f'{out}/source_data', exist_ok=True)
    for ax in fig.axes:
        for art in ax.lines + ax.patches + ax.texts:
            art.set_clip_on(False)
    fig.savefig(f'{out}/{name}.pdf', bbox_inches='tight', pad_inches=0.03)
    fig.savefig(f'{out}/{name}.png', dpi=300, bbox_inches='tight', pad_inches=0.03)
    plt.close(fig)
    src.to_csv(f'{out}/source_data/{name}.tsv', sep='\t', index=False)
    print(f'  {name}.pdf  ({len(src)} rows of source data)')


def exact_ci(k, n):
    k, n = np.asarray(k, float), np.asarray(n, float)
    lo = np.where(k > 0, beta_dist.ppf(0.025, k, n - k + 1), 0.0)
    hi = np.where(k < n, beta_dist.ppf(0.975, k + 1, n - k), 1.0)
    return lo, hi


def paired_or_ci(b, c):
    lo, hi = exact_ci(b, np.asarray(b) + np.asarray(c))
    with np.errstate(divide='ignore', invalid='ignore'):
        return lo / (1 - lo), hi / (1 - hi)


def mh_or_ci(lost, grp, strat):
    R, S, PR, PSQR, QS = [], [], [], [], []
    for s in np.unique(strat):
        m = strat == s
        a = np.sum(lost[m] & grp[m]); b = np.sum(~lost[m] & grp[m])
        c = np.sum(lost[m] & ~grp[m]); d = np.sum(~lost[m] & ~grp[m])
        n = a + b + c + d
        if not n:
            continue
        r, s_, p, q = a * d / n, b * c / n, (a + d) / n, (b + c) / n
        R.append(r); S.append(s_); PR.append(p * r); PSQR.append(p * s_ + q * r); QS.append(q * s_)
    sR, sS = sum(R), sum(S)
    if not sR or not sS:
        return np.nan, np.nan, np.nan
    orr = sR / sS
    v = sum(PR) / (2 * sR ** 2) + sum(PSQR) / (2 * sR * sS) + sum(QS) / (2 * sS ** 2)
    z = norm.ppf(0.975) * np.sqrt(v)
    return orr, orr * np.exp(-z), orr * np.exp(z)


def species_marker(sp, tissue='eye', size=4.2):
    return dict(marker=TISSUE_MK.get(tissue, 'o'), ms=size, mec=INK, mew=0.7,
                mfc=INK if sp == 'tl' else 'white', ls='none', zorder=3)


def forest_point(ax, x, y, lo, hi, color=INK, horizontal=True, **mk):
    if horizontal:
        if np.isfinite(lo) and np.isfinite(hi):
            ax.plot([lo, hi], [y, y], color=color, lw=0.8, solid_capstyle='butt', zorder=2)
        ax.plot([x], [y], **mk)
    else:
        if np.isfinite(lo) and np.isfinite(hi):
            ax.plot([y, y], [lo, hi], color=color, lw=0.8, solid_capstyle='butt', zorder=2)
        ax.plot([y], [x], **mk)


def ref_line(ax, v, horizontal=True):
    (ax.axvline if horizontal else ax.axhline)(v, color=GREY, lw=0.6, ls=(0, (3, 2)), zorder=1)


def legend_species_tissue(ax, tissues=('eye', 'liver'), loc='lower right', extra=(), **k):
    h = [Line2D([], [], **species_marker('tl')), Line2D([], [], **species_marker('cx'))]
    lab = [SP_NAME['tl'], SP_NAME['cx']]
    for t in tissues:
        h.append(Line2D([], [], marker=TISSUE_MK[t], ms=4.2, mec=INK, mfc=LIGHT, mew=0.7, ls='none'))
        lab.append(t)
    for hh, ll in extra:
        h.append(hh); lab.append(ll)
    leg = ax.legend(h, lab, loc=loc, **k)
    for t in leg.get_texts()[:2]:
        t.set_fontstyle('italic')
    return leg


def italic_ticks(ax, axis='y'):
    for t in (ax.get_yticklabels() if axis == 'y' else ax.get_xticklabels()):
        t.set_fontstyle('italic')


def fmt_p(p):
    try:
        p = float(p)
    except (TypeError, ValueError):
        return 'NA'
    if not np.isfinite(p):
        return 'NA'
    if p >= 0.01:
        return f'{p:.2f}'
    if p < 1e-300:
        return '< 10$^{-300}$'
    m, e = f'{p:.1e}'.split('e')
    return f'{m} × 10$^{{{int(e)}}}$'


def log_axis(ax, lo, hi, cands=None):
    if cands is None:
        span = hi / lo
        cands = ((0.1, 0.25, 0.5, 1, 2, 4, 8, 16) if span > 8 else (0.25, 0.5, 1, 2, 3, 4, 6) if span > 3 else
                 (0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 2))
    ax.set_xscale('log')
    ax.set_xlim(lo, hi)
    ax.set_xticks([c for c in cands if lo <= c <= hi])
    ax.xaxis.set_major_formatter(matplotlib.ticker.FormatStrFormatter('%g'))
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())


def fig3a_genomes(B, out):
    t = read(f'{B}/analysis/fractionation_genomes.tsv')
    t = t.set_index('genome')
    rows = [(g, lab) for g, lab in GENOMES if g in t.index]
    d = t.loc[[g for g, _ in rows]].reset_index()
    d['label'] = [lab for _, lab in rows]
    d['n_single'] = d['A_only'] + d['B_only']
    d['B_share'] = d['B_only'] / d['n_single']
    d['lo95'], d['hi95'] = exact_ci(d['B_only'], d['n_single'])
    fig, ax = plt.subplots(figsize=(72 * MM, 52 * MM))
    y = np.arange(len(d))[::-1].astype(float)
    y[d['genome'].isin(['Cyprinus_carpio', 'Carassius_auratus']).values] -= 0.6
    for yi, r in zip(y, d.itertuples()):
        focal = r.genome in ('tianlinensis', 'longibarbatus')
        forest_point(ax, r.B_share, yi, r.lo95, r.hi95, marker='o', ms=4.2, mec=INK, mew=0.7,
                     mfc=INK if focal else 'white', ls='none', zorder=3)
        ax.text(1.02, yi, f'{r.B_only:,} / {r.A_only:,}', transform=ax.get_yaxis_transform(), va='center',
                ha='left', fontsize=6, color=INK)
    ref_line(ax, 0.5)
    ax.set_yticks(y, d['label']); italic_ticks(ax)
    ax.text(1.02, 1.0, 'B-only / A-only', transform=ax.transAxes, ha='left', va='bottom', fontsize=6, color=GREY)
    ax.set_xlabel('SubB share of single-copy retained genes')
    lo = min(0.45, np.floor(d['lo95'].min() * 50) / 50)
    hi = max(0.55, np.ceil(d['hi95'].max() * 50) / 50)
    ax.set_xlim(lo, hi)
    ax.set_xticks(np.round(np.arange(np.ceil(lo * 20) / 20, hi + 1e-9, 0.05), 2))
    ax.set_ylim(y.min() - 0.7, y.max() + 0.7)
    ax.tick_params(axis='y', length=0)
    fig.text(0.01, 0.005, 'Outgroups: carp subgenome B and goldfish subgenome L are scored as SubB.', fontsize=5.5,
             color=GREY, ha='left', va='bottom')
    fig.subplots_adjust(left=0.30, right=0.76, top=0.95, bottom=0.2)
    save(fig, out, 'fig3a_fractionation_genomes',
         d[['genome', 'label', 'called_both', 'both_retained', 'A_only', 'B_only', 'both_lost', 'n_single', 'B_share',
            'lo95', 'hi95', 'binom_p']])


def fig3a_chrpairs(B, out):
    t = read(f'{B}/analysis/fractionation_chrpairs.tsv', dtype={'chr_pair': str})
    t['n'] = t['A_only'] + t['B_only']
    t['B_share'] = t['B_only'] / t['n'].where(t['n'] > 0)
    t['lo95'], t['hi95'] = exact_ci(t['B_only'], t['n'].clip(lower=1))
    fig, ax = plt.subplots(figsize=(100 * MM, 42 * MM))
    pairs = sorted(t['chr_pair'].unique(), key=int)
    xi = {p: i for i, p in enumerate(pairs)}
    notes = []
    for sp, off in (('tl', -0.17), ('cx', 0.17)):
        d = t[t['species'] == sp]
        for r in d.itertuples():
            forest_point(ax, r.B_share, xi[r.chr_pair] + off, r.lo95, r.hi95, horizontal=False,
                         **species_marker(sp, size=3.6))
        mb, ma = int((d['B_only'] > d['A_only']).sum()), int((d['A_only'] > d['B_only']).sum())
        p = binomtest(mb, mb + ma, 0.5).pvalue if mb + ma else np.nan
        notes.append((SP_NAME[sp], f': {mb}/{len(d)} pairs SubB > SubA, sign test P = {fmt_p(p)}'))
        t.loc[t['species'] == sp, 'sign_test_p'] = p
    ref_line(ax, 0.5, horizontal=False)
    ax.set_xticks(range(len(pairs)), [str(int(p)) for p in pairs])
    ax.set_xlim(-0.7, len(pairs) - 0.3)
    ax.set_xlabel('Homoeologous chromosome pair')
    ax.set_ylabel('SubB share of\nsingle-copy retained genes')
    for k, (name, rest) in enumerate(notes):
        t1 = ax.text(0.0, 1.13 - 0.1 * k, name, transform=ax.transAxes, fontsize=6, va='bottom', ha='left',
                     fontstyle='italic')
        ax.annotate(rest, xy=(1, 0), xycoords=t1, va='bottom', ha='left', fontsize=6)
    legend_species_tissue(ax, tissues=(), loc='lower right', bbox_to_anchor=(1.0, 1.02), ncol=1)
    lo, hi = np.nanmin(t['lo95']), np.nanmax(t['hi95'])
    ax.set_ylim(min(0.3, lo - 0.02), max(0.7, hi + 0.02))
    fig.subplots_adjust(left=0.12, right=0.99, top=0.80, bottom=0.2)
    save(fig, out, 'fig3a_fractionation_chrpairs', t)


def fig3b_bias(B, out):
    t = read(f'{B}/analysis/bias_classes.tsv')
    t = t[t['tissue'].isin(['eye', 'liver']) & (t['replicates'] >= 2)].copy()
    t['species'] = pd.Categorical(t['species'], ['tl', 'cx'])
    t['tissue'] = pd.Categorical(t['tissue'], ['eye', 'liver'])
    t = t.sort_values(['species', 'tissue']).reset_index(drop=True)
    seg = [('A_biased', 'SubA-biased (≥ 2-fold, FDR < 0.05)', SUB['A']),
           ('sig_lt2fold', 'FDR < 0.05, < 2-fold', LIGHT),
           ('not_sig', 'not significant', LIGHTER),
           ('B_biased', 'SubB-biased (≥ 2-fold, FDR < 0.05)', SUB['B'])]
    fig, ax = plt.subplots(figsize=(88 * MM, 38 * MM))
    y = np.arange(len(t))[::-1] + np.array([0.25 if s == 'tl' else 0 for s in t['species']])
    for yi, r in zip(y, t.itertuples()):
        left = 0.0
        for col, _, c in seg:
            w = getattr(r, col) / r.n_pairs
            ax.barh(yi, w, left=left, height=0.62, color=c, edgecolor='white', linewidth=0.6)
            if col in ('A_biased', 'B_biased') and w > 0.04:
                ax.text(left + w / 2, yi, f'{100 * w:.0f}%', ha='center', va='center', fontsize=6, color='white')
            left += w
        ax.text(1.02, yi, f'SubB {100 * r.B_share_of_biased:.0f}% of biased, P = {fmt_p(r.binom_p)}', va='center', ha='left',
                fontsize=5.8, transform=ax.get_yaxis_transform())
    ax.set_yticks(y, list(t['tissue']))
    for sp in ('tl', 'cx'):
        ys = y[(t['species'] == sp).values]
        if len(ys):
            ax.text(-0.13, ys.mean(), SP_NAME[sp], transform=ax.get_yaxis_transform(), ha='right', va='center',
                    fontstyle='italic', fontsize=7)
    ax.set_xlim(0, 1); ax.set_xticks([0, .25, .5, .75, 1], ['0', '25', '50', '75', '100'])
    ax.set_xlabel('Homoeolog pairs (%)')
    ax.tick_params(axis='y', length=0)
    ax.spines['left'].set_visible(False)
    h = [plt.Rectangle((0, 0), 1, 1, color=c) for _, _, c in seg]
    ax.legend(h, [l for _, l, _ in seg], ncol=2, loc='lower left', bbox_to_anchor=(-0.02, 1.02), fontsize=5.8,
              handlelength=0.9, columnspacing=0.8)
    ax.set_ylim(y.min() - 0.5, y.max() + 0.5)
    fig.subplots_adjust(left=0.30, right=0.78, top=0.70, bottom=0.2)
    save(fig, out, 'fig3b_bias_classes', t)


TE_METRIC = [('any', 'any TE'), ('shared', 'shared (pre-split)'), ('specific', 'lineage-specific'),
             ('recent', 'recent lineage-specific')]


def fig3d_te_pairs(B, out):
    t = read(f'{B}/analysis/te_polar_pairs.tsv')
    t = t[t['metric'].isin([m for m, _ in TE_METRIC])].copy()
    t['OR'] = t['lower_only'] / t['higher_only'].replace(0, np.nan)
    t['lo95'], t['hi95'] = paired_or_ci(t['lower_only'].values, t['higher_only'].values)
    fig, axes = plt.subplots(1, 2, figsize=(110 * MM, 48 * MM), sharey=True)
    offs = {('tl', 'eye'): 0.27, ('tl', 'liver'): 0.09, ('cx', 'eye'): -0.09, ('cx', 'liver'): -0.27}
    fin = t[['lo95', 'hi95', 'OR']].replace([np.inf, 0], np.nan)
    xmin, xmax = np.nanmin(fin.values), np.nanmax(fin.values)
    for ax, side, title in zip(axes, ('up', 'down'), ('2 kb upstream', '2 kb downstream')):
        for k, (m, _) in enumerate(TE_METRIC[::-1]):
            for r in t[(t['side'] == side) & (t['metric'] == m)].itertuples():
                forest_point(ax, r.OR, k + offs[(r.species, r.tissue)], r.lo95, r.hi95,
                             **species_marker(r.species, r.tissue, size=3.6))
        ref_line(ax, 1)
        log_axis(ax, min(0.5, xmin * 0.9), max(2.0, xmax * 1.1))
        ax.set_title(title, pad=3)
        ax.tick_params(axis='y', length=0)
        for k in range(len(TE_METRIC) - 1):
            ax.axhline(k + 0.5, color=LIGHTER, lw=0.5, zorder=0)
    axes[0].set_yticks(range(len(TE_METRIC)), [l for _, l in TE_METRIC[::-1]])
    fig.supxlabel('Paired odds ratio, TE at lower- vs higher-expressed copy (pairs ≥ 2-fold biased)', fontsize=7,
                  y=0.06)
    legend_species_tissue(axes[1], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.subplots_adjust(left=0.20, right=0.78, top=0.90, bottom=0.22, wspace=0.12)
    save(fig, out, 'figS12_te_presence_polarised', t)


def boot_mean_ci(x, n=2000, seed=13):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    rng = np.random.default_rng(seed)
    b = np.empty(n)
    for k in range(0, n, 250):
        m = min(250, n - k)
        b[k:k + m] = x[rng.integers(0, len(x), (m, len(x)))].mean(axis=1)
    return float(x.mean()), float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))


def fig3d_te_density(B, out):
    from scipy.stats import wilcoxon
    p = pooled_pairs(B)
    metrics = [('up_TE', 'TE cover, 2 kb upstream', 'cover'), ('down_TE', 'TE cover, 2 kb downstream', 'cover'),
               ('up_youngTE', 'young-TE cover, upstream', 'cover'), ('K_up', 'Kimura K, upstream TEs', 'K'),
               ('K_down', 'Kimura K, downstream TEs', 'K')]
    rows = []
    for sp in ('tl', 'cx'):
        f = read(f'{B}/analysis/joint_features_{sp}.tsv.gz').set_index('gene')
        ft = read(f'{B}/te_polar/{sp}.flank_te.tsv.gz')
        for side in ('up', 'down'):
            f[f'K_{side}'] = ft[ft['side'] == side].groupby('gene')['K'].median().reindex(f.index)
        for tissue in ('eye', 'liver'):
            d = p[(p['species'] == sp) & (p['tissue'] == tissue) & (p['log2FC'].abs() >= T_FC)]
            lo = np.where(d['log2FC'] > 0, d['A_gene'], d['B_gene'])
            hi = np.where(d['log2FC'] > 0, d['B_gene'], d['A_gene'])
            for col, lab, kind in metrics:
                x, y = f[col].reindex(lo).values, f[col].reindex(hi).values
                k = np.isfinite(x) & np.isfinite(y)
                dd = (x[k] - y[k]) * 100
                est, l95, h95 = boot_mean_ci(dd)
                rows.append(dict(species=sp, tissue=tissue, metric=col, label=lab, kind=kind, n_pairs=int(k.sum()),
                                 mean_diff_x100=est, lo95=l95, hi95=h95, frac_lower_gt=float((dd > 0).mean()),
                                 frac_lower_lt=float((dd < 0).mean()),
                                 p_paired_wilcoxon=wilcoxon(dd).pvalue if (dd != 0).any() else np.nan))
    t = pd.DataFrame(rows)
    offs = {('tl', 'eye'): 0.27, ('tl', 'liver'): 0.09, ('cx', 'eye'): -0.09, ('cx', 'liver'): -0.27}
    fig, axes = plt.subplots(1, 2, figsize=(120 * MM, 42 * MM), gridspec_kw=dict(width_ratios=[3, 2]))
    for ax, kind, xl in zip(axes, ('cover', 'K'), ('Δ TE cover, lower − higher copy\n(percentage points of the flank)',
                                                   'Δ Kimura K, lower − higher copy (× 100)')):
        ms = [m for m in metrics if m[2] == kind]
        for i, (col, lab, _) in enumerate(ms[::-1]):
            for r in t[t['metric'] == col].itertuples():
                forest_point(ax, r.mean_diff_x100, i + offs[(r.species, r.tissue)], r.lo95, r.hi95,
                             **species_marker(r.species, r.tissue, size=3.4))
        ref_line(ax, 0)
        ax.set_yticks(range(len(ms)), [lab for _, lab, _ in ms[::-1]])
        ax.tick_params(axis='y', length=0)
        ax.set_xlabel(xl)
        for k in range(len(ms) - 1):
            ax.axhline(k + 0.5, color=LIGHTER, lw=0.5, zorder=0)
    legend_species_tissue(axes[1], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.subplots_adjust(wspace=0.75)
    save(fig, out, 'fig3d_te_density_age', t)


TISSUE_ORDER = ('eye', 'liver', 'muscle', 'brain', 'gill', 'heart', 'kidney', 'skin', 'spleen', 'swimbladder')


def go_dot(t, out, name, n_per_set=4, note=''):
    t = t.copy()
    t['tissue'] = t['tissue'].astype(str)
    t['_sp'] = t['species'].map({'tl': 0, 'cx': 1})
    t['_ti'] = t['tissue'].map({x: i for i, x in enumerate(TISSUE_ORDER)}).fillna(99)
    t['_di'] = (~t['direction'].str.startswith('SubB')).astype(int)
    t = t.sort_values(['_sp', '_ti', '_di', 'fdr'])
    rows, src = [], []
    for (sp, tissue, direction), g in t.groupby(['species', 'tissue', 'direction'], sort=False):
        g = g.drop_duplicates(['K', 'k']).head(n_per_set)
        rep = str(g['classification'].iloc[0]) if 'classification' in g.columns else ''
        rep = ' (3 individuals, moderated t)' if 'moderated' in rep else ' (1 individual)' if 'one individual' in rep else ''
        rows.append(('h', f'$\\it{{{SP_NAME[sp].replace(" ", chr(92) + " ")}}}$ · {tissue} · {direction}{rep}', None))
        for r in g.itertuples():
            nm = r.name if len(str(r.name)) <= 52 else str(r.name)[:50] + '…'
            rows.append(('t', nm, r))
            src.append(r._asdict())
    n = len(rows)
    fig, ax = plt.subplots(figsize=(120 * MM, (10 + 3.4 * n) * MM))
    y = np.arange(n)[::-1].astype(float)
    kmax = max(r[2].k for r in rows if r[0] == 't')
    sz = lambda k: 6 + 50 * k / kmax
    xs = [r[2].fold for r in rows if r[0] == 't']
    for yi, (kind, lab, r) in zip(y, rows):
        if kind == 't':
            c = SUB['B'] if r.direction.startswith('SubB') else SUB['A']
            ax.scatter([r.fold], [yi], s=sz(r.k), color=c, edgecolor=INK, linewidth=0.4, zorder=3)
            ax.text(1.01, yi, fmt_p(r.fdr), transform=ax.get_yaxis_transform(), va='center', ha='left', fontsize=5.8)
    ax.set_yticks(y, [lab for _, lab, _ in rows])
    for tl_, (kind, _, _) in zip(ax.get_yticklabels(), rows):
        if kind == 'h':
            tl_.set_fontweight('bold')
            tl_.set_fontsize(6.2)
    ax.tick_params(axis='y', length=0)
    for yi, (kind, _, _) in zip(y, rows):
        if kind == 'h':
            ax.axhline(yi + 0.5, color=LIGHTER, lw=0.5, zorder=0)
    ax.set_xlim(1.0, max(xs) * 1.12)
    ax.set_ylim(-0.7, n - 0.3)
    ax.set_xlabel('Fold enrichment')
    ax.text(1.01, 1.0, 'FDR', transform=ax.transAxes, ha='left', va='bottom', fontsize=6, color=GREY)
    ks = sorted({int(round(v)) for v in np.quantile([r[2].k for r in rows if r[0] == 't'], [0.1, 0.5, 1.0])})
    h = [plt.scatter([], [], s=sz(k), color=LIGHT, edgecolor=INK, linewidth=0.4) for k in ks]
    h += [Line2D([], [], marker='o', ls='none', ms=4, mfc=SUB['B'], mec=INK, mew=0.4),
          Line2D([], [], marker='o', ls='none', ms=4, mfc=SUB['A'], mec=INK, mew=0.4)]
    ax.legend(h, [f'{k} genes' for k in ks] + ['SubB', 'SubA'], loc='upper left', bbox_to_anchor=(1.12, 1.0),
              handletextpad=0.4, labelspacing=0.6)
    if note:
        fig.text(0.01, 0.0, note, fontsize=5.5, color=GREY, ha='left', va='top')
    save(fig, out, name, pd.DataFrame(src).drop(columns=['Index', '_sp', '_ti', '_di'], errors='ignore'))


def fig3c_go(B, out):
    t = read(f'{B}/analysis/go_enrich_top.tsv')
    t = t[t['tissue'].isin(['eye', 'liver', 'muscle'])]
    if t.empty:
        raise RuntimeError('no GO term with FDR < 0.05 and fold >= 1.5 in eye, liver or muscle')
    go_dot(t, out, 'fig3c_go_enrichment',
           note='Hypergeometric test vs expressed pairs with a zebrafish orthologue; terms with FDR < 0.05 and '
                '≥ 1.5-fold; up to four non-redundant terms per set (all terms: Table S34).')


def figS12c_te_class(B, out):
    t = read(f'{B}/analysis/extra_teclass.tsv')
    classes = ['DNA', 'LTR', 'LINE', 'SINE', 'Unknown']
    t = t[t['te_class'].isin(classes) & t['side'].isin(['up', 'down'])]
    offs = {('tl', 'eye'): 0.27, ('tl', 'liver'): 0.09, ('cx', 'eye'): -0.09, ('cx', 'liver'): -0.27}
    fig, axes = plt.subplots(1, 2, figsize=(112 * MM, 46 * MM), sharey=True, sharex=True)
    for ax, side, title in zip(axes, ('up', 'down'), ('2 kb upstream', '2 kb downstream')):
        for k, c in enumerate(classes[::-1]):
            for r in t[(t['side'] == side) & (t['te_class'] == c)].itertuples():
                forest_point(ax, r.mean_dK_x100, k + offs[(r.species, r.tissue)], r.lo95, r.hi95,
                             **species_marker(r.species, r.tissue, size=3.4))
        ref_line(ax, 0)
        ax.set_title(title, pad=3)
        ax.tick_params(axis='y', length=0)
        for k in range(len(classes) - 1):
            ax.axhline(k + 0.5, color=LIGHTER, lw=0.5, zorder=0)
    axes[0].set_yticks(range(len(classes)), classes[::-1])
    fig.supxlabel('Δ Kimura K of flanking TEs, lower − higher copy (× 100); < 0 = younger at the lower copy',
                  fontsize=6.5, y=0.02)
    legend_species_tissue(axes[1], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.subplots_adjust(wspace=0.12, bottom=0.2)
    save(fig, out, 'figS12c_te_age_by_te_class', t)


def figS12d_te_distance(B, out):
    d = read(f'{B}/analysis/extra_tedist_density.tsv')
    s = read(f'{B}/analysis/extra_tedist.tsv')
    d, s = d[d['tissue'] == 'eye'], s[s['tissue'] == 'eye']
    fig, axes = plt.subplots(2, 2, figsize=(100 * MM, 58 * MM), sharex=True, sharey=True)
    for i, sp in enumerate(('tl', 'cx')):
        for j, (side, title) in enumerate((('up', 'upstream'), ('down', 'downstream'))):
            ax = axes[i, j]
            for copy, c, ls in (('lower', INK, '-'), ('higher', GREY, (0, (3, 1.5)))):
                g = d[(d['species'] == sp) & (d['side'] == side) & (d['copy'] == copy)].sort_values('bin_start')
                if len(g):
                    edges = np.append(g['bin_start'].values, g['bin_end'].values[-1]) / 1000
                    ax.stairs(g['density'].values * 1000, edges, color=c, lw=0.9, ls=ls,
                              label=f'{copy}-expressed copy')
            r = s[(s['species'] == sp) & (s['side'] == side)]
            if len(r):
                r = r.iloc[0]
                ax.text(0.97, 0.95, f'KS D = {r.ks_D:.3f}, P = {fmt_p(r.p_ks)}\nΔ median position = '
                        f'{r.mean_diff_bp:+.0f} bp ({r.lo95:+.0f}, {r.hi95:+.0f})', transform=ax.transAxes,
                        ha='right', va='top', fontsize=5.3)
            if i == 0:
                ax.set_title(title, pad=3)
            ax.set_xlim(0, 2)
            ax.set_xticks([0, 0.5, 1, 1.5, 2], ['0', '0.5', '1', '1.5', '2'])
        axes[i, 0].set_ylabel(f'{SP_NAME[sp]}\nTE density (per kb)', fontsize=6.5)
        axes[i, 0].yaxis.label.set_fontstyle('italic')
    top = max(ax.get_ylim()[1] for ax in axes.flat)
    for ax in axes.flat:
        ax.set_ylim(0, top * 1.45)
    axes[0, 1].legend(loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.supxlabel('Distance of TE midpoint from the gene boundary (kb); eye, pairs ≥ 2-fold biased', fontsize=6.5,
                  y=-0.04)
    fig.subplots_adjust(hspace=0.25, wspace=0.1)
    save(fig, out, 'figS12d_te_distance_to_gene', s)


def figS9c_immune(B, out):
    t = read(f'{B}/analysis/extra_immune.tsv')
    ts = sorted(t['tissue'].unique(), key=lambda x: TISSUE_ORDER.index(x) if x in TISSUE_ORDER else 99)
    fig, ax = plt.subplots(figsize=(78 * MM, (12 + 5 * len(ts)) * MM))
    for k, tis in enumerate(ts[::-1]):
        for sp, off in (('tl', 0.14), ('cx', -0.14)):
            r = t[(t['species'] == sp) & (t['tissue'] == tis)]
            if len(r):
                r = r.iloc[0]
                forest_point(ax, r.OR_balanced, k + off, r.lo95, r.hi95, **species_marker(sp, 'eye', size=3.6))
    ref_line(ax, 1)
    fin = t[['lo95', 'hi95']].replace([np.inf, 0], np.nan)
    log_axis(ax, min(0.5, np.nanmin(fin.values) * 0.9), max(2.0, np.nanmax(fin.values) * 1.1),
             cands=(0.1, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64, 128, 256))
    ax.set_yticks(range(len(ts)), [f'{x} ({int(t.loc[t.tissue == x, "individuals"].max())})' for x in ts[::-1]])
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('OR, balanced expression (|log2FC| < 1)\nimmune-system vs other pairs')
    ax.set_ylim(-0.6, len(ts) - 0.4)
    legend_species_tissue(ax, tissues=(), loc='upper left', bbox_to_anchor=(1.0, 1.0))
    save(fig, out, 'figS9c_immune_balance', t)


def figS20_gbm_go(B, out):
    t = read(f'{B}/analysis/extra_gbm_go_top.tsv')
    t = t[t['threshold'] == 0.3]
    if t.empty:
        print('  figS20_gbm_go: no GO term with FDR < 0.05 and fold >= 1.5 (|dMeth_body| >= 0.3); no panel drawn')
        return
    t = t.assign(classification='2 WGBS replicates, same sign')
    go_dot(t, out, 'figS20_gbm_go_enrichment',
           note='Pairs with |Δ gene-body methylation| ≥ 0.3 (pooled replicates, same sign in both) vs all covered '
                'pairs with a zebrafish orthologue; FDR < 0.05, ≥ 1.5-fold (all terms: Table S34).')


def fig3e_te_quartets(B, out):
    t = read(f'{B}/analysis/te_polar_quartets.tsv')
    if 'd_rel_diff' not in t.columns:
        raise RuntimeError('te_polar_quartets.tsv has no CI columns: rerun `python3 te_polar.py test` first')
    t = t[t['subgenome'] == 'pooled'].copy()
    rows = [('up', 'specific', 'upstream, specific'), ('up', 'recent', 'upstream, recent'),
            ('down', 'specific', 'downstream, specific'), ('down', 'recent', 'downstream, recent')]
    offs = {('tl_only', 'eye'): 0.27, ('tl_only', 'liver'): 0.09, ('cx_only', 'eye'): -0.09, ('cx_only', 'liver'): -0.27}
    fig, axes = plt.subplots(1, 2, figsize=(112 * MM, 48 * MM), sharey=True)
    fig.subplots_adjust(wspace=0.25)
    for ax, (est, lo, hi, lab) in zip(axes, (('d_rel_diff', 'd_rel_lo95', 'd_rel_hi95',
                                              'Δ relative expression (log2)\nwith − without insertion'),
                                             ('d_meth_diff', 'd_meth_lo95', 'd_meth_hi95',
                                              'Δ relative promoter methylation\nwith − without insertion'))):
        for k, (side, ins, _) in enumerate(rows[::-1]):
            for r in t[(t['side'] == side) & (t['insertion'] == ins)].itertuples():
                sp = 'tl' if r.group == 'tl_only' else 'cx'
                forest_point(ax, getattr(r, est), k + offs[(r.group, r.tissue)], getattr(r, lo), getattr(r, hi),
                             **species_marker(sp, r.tissue, size=3.6))
        ref_line(ax, 0)
        ax.set_xlabel(lab)
        ax.tick_params(axis='y', length=0)
        for k in range(len(rows) - 1):
            ax.axhline(k + 0.5, color=LIGHTER, lw=0.5, zorder=0)
    axes[0].set_yticks(range(len(rows)), [l for *_, l in rows[::-1]])
    axes[0].set_title('Insertion present in one species only (ortholog quartets)', loc='left', pad=3)
    legend_species_tissue(axes[1], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    axes[1].get_legend().set_title('species with insertion', prop={'size': 6})
    save(fig, out, 'fig3e_te_insertion_quartets', t)


def fig7a_dosage(B, out):
    t = read(f'{B}/analysis/dosage_quartets.tsv')
    if 'd_total_diff' not in t.columns:
        raise RuntimeError('dosage_quartets.tsv has no CI columns: rerun `python3 te_polar.py test` first')
    eff = [('d_total_diff', 'd_total_lo95', 'd_total_hi95', 'total (SubA + SubB)'),
           ('d_repressed_vs_none', 'd_repressed_lo95', 'd_repressed_hi95', 'repressed copy'),
           ('d_partner_vs_none', 'd_partner_lo95', 'd_partner_hi95', 'partner copy')]
    mode_mk = {'indep': 'o', 'pooled': 'D'}
    offs = {('tl_only', 'indep'): 0.27, ('tl_only', 'pooled'): 0.09, ('cx_only', 'indep'): -0.09,
            ('cx_only', 'pooled'): -0.27}
    labels, k = [], 0
    fig, ax = plt.subplots(figsize=(88 * MM, 62 * MM))
    ypos = {}
    for e in eff[::-1]:
        for tissue in ('liver', 'eye'):
            ypos[(e[0], tissue)] = k
            labels.append(f'{e[3]}, {tissue}')
            k += 1
        k += 0.4
    for r in t.itertuples():
        sp = 'tl' if r.group == 'tl_only' else 'cx'
        for est, lo, hi, _ in eff:
            mk = species_marker(sp, size=3.6)
            mk['marker'] = mode_mk.get(r.mode, 'o')
            if mk['marker'] == 'D':
                mk['ms'] = 3.0
            forest_point(ax, getattr(r, est), ypos[(est, r.tissue)] + offs[(r.group, r.mode)], getattr(r, lo),
                         getattr(r, hi), **mk)
    ref_line(ax, 0)
    ax.set_yticks(sorted(ypos.values()), [labels[i] for i in np.argsort(list(ypos.values()))])
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('Δ log2 expression, species with the candidate − other species\n(relative to quartets without a candidate)')
    h = [Line2D([], [], **species_marker('tl')), Line2D([], [], **species_marker('cx')),
         Line2D([], [], marker='o', ms=4, mec=INK, mfc=LIGHT, mew=0.7, ls='none'),
         Line2D([], [], marker='D', ms=3, mec=INK, mfc=LIGHT, mew=0.7, ls='none')]
    leg = ax.legend(h, [SP_NAME['tl'], SP_NAME['cx'], 'measured in an independent replicate',
                        'pooled replicates'], loc='upper left', bbox_to_anchor=(1.0, 1.0),
                    title='candidate repressed copy in', title_fontsize=6)
    leg._legend_box.align = 'left'
    for tt in leg.get_texts()[:2]:
        tt.set_fontstyle('italic')
    fig.subplots_adjust(left=0.30, right=0.66, top=0.97, bottom=0.2)
    save(fig, out, 'fig7a_dosage_quartets', t)


def fig7b_consistency(B, out):
    t = read(f'{B}/analysis/bias_tissue_consistency.tsv')
    tissues = [x for x in ('eye', 'liver') if x in set(t['other_tissue'])] + \
        sorted(x for x in set(t['other_tissue']) if x not in ('eye', 'liver'))
    xi = {x: i for i, x in enumerate(tissues)}
    col = {'candidate': INK, 'biased_no_meth_difference': GREY}
    offs = {('tl', 'candidate'): -0.24, ('tl', 'biased_no_meth_difference'): -0.08,
            ('cx', 'candidate'): 0.08, ('cx', 'biased_no_meth_difference'): 0.24}
    fig, axes = plt.subplots(2, 2, figsize=(130 * MM, 68 * MM), sharex=True, sharey='row',
                             gridspec_kw=dict(height_ratios=[1.6, 1]))
    for j, dt in enumerate(('eye', 'liver')):
        for i, (metric, lab) in enumerate((('frac_same_lower_copy', 'same lower copy'),
                                           ('frac_reversed_2fold', 'reversed ≥ 2-fold'))):
            ax = axes[i, j]
            d = t[t['defined_in'] == dt]
            for r in d.itertuples():
                k, n = getattr(r, metric) * r.n, r.n
                lo, hi = exact_ci(round(k), n) if n else (np.nan, np.nan)
                mk = species_marker(r.species, size=3.4)
                mk['mec'] = col[r.pairs]
                if r.species == 'tl':
                    mk['mfc'] = col[r.pairs]
                forest_point(ax, getattr(r, metric), xi[r.other_tissue] + offs[(r.species, r.pairs)], float(lo),
                             float(hi), color=col[r.pairs], horizontal=False, **mk)
            if i == 0:
                ax.set_title(f'pairs classified in {dt}', pad=3)
                ref_line(ax, 0.5, horizontal=False)
            if j == 0:
                ax.set_ylabel(f'{lab}\n(fraction of pairs)')
    axes[1, 0].set_xticks(range(len(tissues)), tissues, rotation=40, ha='right')
    axes[1, 1].set_xticks(range(len(tissues)), tissues, rotation=40, ha='right')
    axes[0, 0].set_ylim(0.4, 1.0)
    axes[1, 0].set_ylim(0, max(0.1, float(np.nanmax(exact_ci(np.round(t['frac_reversed_2fold'] * t['n']),
                                                                       t['n'].clip(lower=1))[1])) * 1.05))
    h = [Line2D([], [], **species_marker('tl')), Line2D([], [], **species_marker('cx')),
         Line2D([], [], color=INK, marker='s', ms=3.6, ls='-', lw=0.8),
         Line2D([], [], color=GREY, marker='s', ms=3.6, ls='-', lw=0.8)]
    leg = axes[0, 1].legend(h, [SP_NAME['tl'], SP_NAME['cx'], 'candidate repressed copy',
                                'biased, no methylation difference'], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    for tt in leg.get_texts()[:2]:
        tt.set_fontstyle('italic')
    fig.subplots_adjust(left=0.10, right=0.74, top=0.92, bottom=0.2, hspace=0.12, wspace=0.08)
    save(fig, out, 'fig7b_tissue_consistency', t)


def atac_pairs(B):
    pairs = read(f'{B}/analysis/methexpr_pairs.tsv.gz', dtype={'individual': str, 'HE': str})
    pairs = pairs[(pairs['individual'] == 'pooled') & (pairs['tissue'] == 'liver')]
    res = []
    for sp in ('tl', 'cx'):
        pc = read(f'{B}/atac/promoter_counts_{sp}.tsv').set_index('gene')
        nrep = len([c for c in pc.columns if c.startswith('liver_')])
        m = read(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', dtype={'HE': str})
        m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)][['A_gene', 'B_gene']].copy()
        nA, nB = pc['pooled'].reindex(m['A_gene']).values, pc['pooled'].reindex(m['B_gene']).values
        m['d_atac'] = np.where(nA + nB >= MIN_PROM * nrep, np.log2((nB + 1) / (nA + 1)), np.nan)
        x = m.merge(pairs[pairs['species'] == sp][['A_gene', 'B_gene', 'log2FC', 'dMeth']], on=['A_gene', 'B_gene'])
        x = x.dropna(subset=['d_atac', 'log2FC'])
        cand = ((x['dMeth'] <= -T_METH) & (x['log2FC'] >= T_FC)) | ((x['dMeth'] >= T_METH) & (x['log2FC'] <= -T_FC))
        biased = (x['log2FC'].abs() >= T_FC) & (x['dMeth'].abs() < T_METH)
        x['group'] = np.where(cand, 'candidate', np.where(biased, 'biased_no_meth_difference', 'other'))
        x['lower_minus_partner'] = -np.sign(x['log2FC']) * x['d_atac']
        x['species'] = sp
        res.append(x)
    return pd.concat(res, ignore_index=True)


def fig7c_atac(B, out):
    x = atac_pairs(B)
    rng = np.random.default_rng(7)
    groups = [('candidate', 'candidate', INK), ('biased_no_meth_difference', 'biased,\nno Δmeth', GREY)]
    fig, ax = plt.subplots(figsize=(62 * MM, 52 * MM))
    pos, ticks, src = 0, [], []
    v_all = x.loc[x['group'] != 'other', 'lower_minus_partner']
    YLO, YHI = np.floor(np.percentile(v_all, 1)), np.ceil(np.percentile(v_all, 99))
    for sp in ('tl', 'cx'):
        vals = {}
        for g, lab, c in groups:
            v = x.loc[(x['species'] == sp) & (x['group'] == g), 'lower_minus_partner'].values
            vals[g] = v
            if len(v):
                q1, med, q3 = np.percentile(v, [25, 50, 75])
                ax.add_patch(plt.Rectangle((pos - 0.3, q1), 0.6, q3 - q1, fc='white', ec=c, lw=0.8, zorder=2))
                ax.plot([pos - 0.3, pos + 0.3], [med, med], color=c, lw=1.4, zorder=3, solid_capstyle='butt')
                jit = rng.uniform(-0.22, 0.22, len(v))
                inside = (v >= YLO) & (v <= YHI)
                ax.scatter(pos + jit[inside], v[inside], s=1.6, color=c, alpha=0.25, lw=0, zorder=1,
                           rasterized=len(v) > 3000)
                for side, edge, mk in ((v > YHI, YHI, '^'), (v < YLO, YLO, 'v')):
                    if side.any():
                        ax.scatter(pos + jit[side], np.full(side.sum(), edge), s=4, marker=mk, facecolor='none',
                                   edgecolor=c, lw=0.4, zorder=1, clip_on=False)
                        ax.text(pos + 0.32, edge, str(int(side.sum())), fontsize=5, color=c, va='center')
                ax.text(pos, 1.05, f'n = {len(v):,}', transform=ax.get_xaxis_transform(), ha='center', va='bottom',
                        fontsize=5.5)
            ticks.append((pos, lab))
            pos += 1
        p = mannwhitneyu(vals['candidate'], vals['biased_no_meth_difference']).pvalue \
            if min(len(v) for v in vals.values()) > 4 else np.nan
        ax.text(pos - 1.5, -0.2, SP_NAME[sp], transform=ax.get_xaxis_transform(), ha='center', va='top',
                fontsize=6.5, fontstyle='italic')
        ax.text(pos - 1.5, -0.29, f'P = {fmt_p(p)}', transform=ax.get_xaxis_transform(), ha='center', va='top',
                fontsize=6)
        src.append(dict(species=sp, n_candidate=len(vals['candidate']), n_biased=len(vals['biased_no_meth_difference']),
                        median_candidate=np.median(vals['candidate']) if len(vals['candidate']) else np.nan,
                        median_biased=np.median(vals['biased_no_meth_difference'])
                        if len(vals['biased_no_meth_difference']) else np.nan,
                        frac_lower_less_accessible_candidate=np.mean(vals['candidate'] < 0),
                        frac_lower_less_accessible_biased=np.mean(vals['biased_no_meth_difference'] < 0),
                        p_mannwhitney=p, axis_lo=YLO, axis_hi=YHI,
                        n_beyond_axis=int(sum(((vv < YLO) | (vv > YHI)).sum() for vv in vals.values()))))
        pos += 0.6
    ref_line(ax, 0, horizontal=False)
    ax.set_xticks([p for p, _ in ticks], [l for _, l in ticks], fontsize=5.8)
    ax.tick_params(axis='x', length=0)
    ax.set_ylim(YLO, YHI)
    ax.set_xlim(-0.6, pos - 0.9)
    ax.set_ylabel('Liver promoter accessibility,\nlower − higher-expressed copy (log2)')
    ax.text(1.0, -0.42, 'triangles: points beyond the axis, drawn at the edge (count beside)', transform=ax.transAxes, ha='right',
            va='top', fontsize=5, color=GREY)
    fig.subplots_adjust(left=0.24, right=0.98, top=0.92, bottom=0.30)
    save(fig, out, 'fig7c_atac_repressed_copy', pd.DataFrame(src))
    fig, axes = plt.subplots(1, 2, figsize=(96 * MM, 44 * MM), sharex=True, sharey=True)
    cm = matplotlib.colors.LinearSegmentedColormap.from_list('blue', ['#cde2fb', '#3987e5', '#104281'])
    src2 = []
    ext = (x['d_atac'].min() - 0.1, x['d_atac'].max() + 0.1, x['log2FC'].min() - 0.1, x['log2FC'].max() + 0.1)
    for ax, sp in zip(axes, ('tl', 'cx')):
        d = x[x['species'] == sp]
        ax.hexbin(d['d_atac'], d['log2FC'], gridsize=28, cmap=cm, mincnt=1, bins='log', linewidths=0.1,
                  edgecolors='white', extent=ext)
        r, p = spearmanr(d['d_atac'], d['log2FC'])
        ax.text(0.03, 0.97, f'ρ = {r:.2f}\nn = {len(d):,}', transform=ax.transAxes, va='top', fontsize=6)
        ax.set_title(SP_NAME[sp], fontstyle='italic', pad=3)
        ref_line(ax, 0); ref_line(ax, 0, horizontal=False)
        src2.append(dict(species=sp, n=len(d), spearman_rho=r, p=p))
        ax.set_xlabel('promoter accessibility log2(B/A)')
    axes[0].set_ylabel('expression log2FC (B/A)')
    fig.subplots_adjust(left=0.12, right=0.98, top=0.88, bottom=0.24, wspace=0.1)
    save(fig, out, 'fig7c2_atac_vs_expression', pd.DataFrame(src2))
    x.to_csv(f'{out}/source_data/fig7c_atac_pairs.tsv.gz', sep='\t', index=False)


OMEGA_LAB = {'SubB vs SubA (all quartets)': 'SubB / SubA, all quartets',
             'submissive vs dominant copy (same bias in both species)': 'submissive / dominant copy',
             '  of which SubA submissive': '    SubA submissive',
             '  of which SubB submissive': '    SubB submissive',
             '  submissive copy: methylation candidate vs not (unpaired)': '    methylation candidate / not',
             'candidate repressed copy vs partner (either species)': 'repressed / partner copy',
             '  repressed in both species': '    repressed in both species',
             '  repressed in one species only': '    repressed in one species'}


def fig7d_omega(B, out):
    t = read(f'{B}/analysis/orth_omega.tsv')
    comps = [c for c in OMEGA_LAB if c in set(t['comparison'])] + \
        [c for c in dict.fromkeys(t['comparison']) if c not in OMEGA_LAB]
    yi = {c: len(comps) - 1 - i for i, c in enumerate(comps)}
    offs = {'all': 0.0, 'eye': 0.18, 'liver': -0.18}
    fig, ax = plt.subplots(figsize=(92 * MM, 62 * MM))
    for r in t.itertuples():
        mk = dict(marker=TISSUE_MK.get(r.tissue, 's'), ms=3.8, mec=INK, mfc=INK, mew=0.7, ls='none', zorder=3)
        forest_point(ax, r.ratio, yi[r.comparison] + offs.get(r.tissue, 0), r.ratio_lo95, r.ratio_hi95, **mk)
        ax.text(1.01, yi[r.comparison] + offs.get(r.tissue, 0), str(r.n_quartets), transform=ax.get_yaxis_transform(),
                va='center', fontsize=5, color=GREY)
    ref_line(ax, 1)
    lo, hi = t['ratio_lo95'].min(), t['ratio_hi95'].max()
    log_axis(ax, min(0.8, lo * 0.95), max(1.25, hi * 1.05), cands=(0.5, 0.6, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 2))
    ax.set_yticks([yi[c] for c in comps], [''] * len(comps))
    for c in comps:
        ax.text(-0.80, yi[c], OMEGA_LAB.get(c, c), transform=ax.get_yaxis_transform(), ha='left', va='center',
                fontsize=6.5)
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('ω ratio (aggregated dN/dS, tl–cx ortholog branch)')
    ax.text(1.01, 1.0, 'n', transform=ax.transAxes, fontsize=5.5, color=GREY, va='bottom')
    h = [Line2D([], [], marker=TISSUE_MK[k], ms=3.8, mec=INK, mfc=INK, ls='none') for k in ('all', 'eye', 'liver')]
    ax.legend(h, ['genome-wide', 'classified in eye', 'classified in liver'], loc='upper center',
              bbox_to_anchor=(0.5, -0.2), ncol=3)
    ax.set_ylim(-0.6, len(comps) - 0.4)
    fig.subplots_adjust(left=0.38, right=0.90, top=0.95, bottom=0.2)
    save(fig, out, 'fig7d_omega', t)


def fig7e_toga(B, out, loss_def='L'):
    cp = read(f'{B}/analysis/toga_copies.tsv.gz')
    tests = read(f'{B}/analysis/toga_loss_tests.tsv')
    min_called = {'sino': 3, 'outgroup': 1}
    contrasts = [('repressed', 'balanced'), ('lower_only', 'balanced'), ('repressed', 'lower_only')]
    rows = []
    for (sp, tissue), d in cp.groupby(['species', 'tissue'], sort=False):
        for s in ('sino', 'outgroup'):
            called, lost = (f'{s}_called', f'{s}_lost') if loss_def == 'L' else (f'{s}_called_ul', f'{s}_lost_ul')
            dd = d[d[called] >= min_called[s]]
            for g1, g2 in contrasts:
                x = dd[dd['cls'].isin([g1, g2])]
                orr, lo, hi = mh_or_ci((x[lost] > 0).values, (x['cls'] == g1).values, x['sub'].values)
                rows.append(dict(species=sp, tissue=tissue, genomes=s, loss_def=loss_def, contrast=f'{g1}_vs_{g2}',
                                 n1=int((x['cls'] == g1).sum()), n2=int((x['cls'] == g2).sum()),
                                 MH_OR=orr, lo95=lo, hi95=hi))
    t = pd.DataFrame(rows).merge(tests[['species', 'tissue', 'genomes', 'loss_def', 'contrast', 'perm_p']],
                                 on=['species', 'tissue', 'genomes', 'loss_def', 'contrast'], how='left')
    lab = {'repressed_vs_balanced': 'repressed vs balanced', 'lower_only_vs_balanced': 'lower, no Δmeth vs balanced',
           'repressed_vs_lower_only': 'repressed vs lower, no Δmeth'}
    gl = {'sino': 'other Sinocyclocheilus', 'outgroup': 'carp / goldfish'}
    order = [(c, g) for g in ('sino', 'outgroup') for c in lab][::-1]
    yi = {k: i + (0.5 if k[1] == 'sino' else 0) for i, k in enumerate(order)}
    offs = {('tl', 'eye'): 0.27, ('tl', 'liver'): 0.09, ('cx', 'eye'): -0.09, ('cx', 'liver'): -0.27}
    fig, ax = plt.subplots(figsize=(100 * MM, 56 * MM))
    for r in t.itertuples():
        forest_point(ax, r.MH_OR, yi[(r.contrast, r.genomes)] + offs[(r.species, r.tissue)], r.lo95, r.hi95,
                     **species_marker(r.species, r.tissue, size=3.6))
    ref_line(ax, 1)
    log_axis(ax, min(0.8, np.nanmin(t['lo95']) * 0.9), max(1.25, np.nanmax(t['hi95']) * 1.1))
    ax.set_yticks([yi[k] for k in order], [lab[c] for c, _ in order])
    for g in ('sino', 'outgroup'):
        ys = [yi[k] for k in order if k[1] == g]
        ax.text(-0.02, max(ys) + 0.55, f'loss in {gl[g]}', transform=ax.get_yaxis_transform(), ha='right',
                va='bottom', fontsize=6, fontweight='bold')
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('Odds ratio of gene loss in other genomes\n(Mantel–Haenszel, stratified by subgenome)')
    legend_species_tissue(ax, loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.subplots_adjust(left=0.30, right=0.76, top=0.92, bottom=0.17)
    save(fig, out, 'fig7e_toga_loss', t)


def boot_median_ci(x, n=2000, seed=11):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) < 3:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    b = np.empty(n)
    for k in range(0, n, 250):
        m = min(250, n - k)
        b[k:k + m] = np.median(x[rng.integers(0, len(x), (m, len(x)))], axis=1)
    return float(np.median(x)), float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))


def strict_pairs(B, sp, cols=('A_gene', 'B_gene', 'A_chr', 'HE')):
    m = read(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', dtype={'HE': str, 'A_chr': str, 'B_chr': str})
    m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)]
    return m[list(cols)].reset_index(drop=True) if cols else m.reset_index(drop=True)


def stacked_bars(ax, t, seg, label_col):
    y = np.arange(len(t))[::-1] + np.array([0.25 if s == 'tl' else 0 for s in t['species']])
    for yi, (_, r) in zip(y, t.iterrows()):
        tot = sum(r[c] for c, _, _ in seg)
        left = 0.0
        for col, _, c in seg:
            w = r[col] / tot
            ax.barh(yi, w, left=left, height=0.62, color=c, edgecolor='white', linewidth=0.6)
            if w > 0.045:
                ax.text(left + w / 2, yi, f'{100 * w:.0f}%', ha='center', va='center', fontsize=5.8,
                        color='white' if c in (SUB['A'], SUB['B'], GREY) else INK)
            left += w
    ax.set_yticks(y, list(t[label_col]))
    for sp in ('tl', 'cx'):
        ys = y[(t['species'] == sp).values]
        if len(ys):
            ax.text(-0.13, ys.mean(), SP_NAME[sp], transform=ax.get_yaxis_transform(), ha='right', va='center',
                    fontstyle='italic', fontsize=7)
    ax.set_xlim(0, 1); ax.set_xticks([0, .25, .5, .75, 1], ['0', '25', '50', '75', '100'])
    ax.tick_params(axis='y', length=0)
    ax.spines['left'].set_visible(False)
    ax.set_ylim(y.min() - 0.5, y.max() + 0.5)
    h = [plt.Rectangle((0, 0), 1, 1, color=c) for _, _, c in seg]
    ax.legend(h, [l for _, l, _ in seg], ncol=2, loc='lower left', bbox_to_anchor=(-0.02, 1.02), fontsize=5.8,
              handlelength=0.9, columnspacing=0.8)
    return y


def fig2b_ks(B, out):
    def ok(d):
        for c in ('Ks_YN00', 'cov', 'aln_codons'):
            d[c] = pd.to_numeric(d[c], errors='coerce')
        return d[(d['status'] == 'ok') & (d['cov'] >= 0.5) & (d['aln_codons'] >= 50) & (d['Ks_YN00'] >= 0) &
                 (d['Ks_YN00'] < 3)]['Ks_YN00'].values
    series = []
    for sp, c, ls in (('tl', INK, '-'), ('cx', GREY, '-')):
        m = strict_pairs(B, sp, cols=None)
        series.append((f'{SP_NAME[sp]} SubA–SubB', pd.to_numeric(m['Ks_YN00'], errors='coerce').dropna().values, c, ls,
                       True))
    for s in 'AB':
        series.append((f'tl–cx orthologs, Sub{s}', ok(read(f'{B}/te_polar/orth_{s}.ks.tsv')), SUB[s], '-', False))
    lo, hi = 1e-3, 3.0
    edges = np.logspace(np.log10(lo), np.log10(hi), 61)
    fig, ax = plt.subplots(figsize=(88 * MM, 50 * MM))
    src = []
    for k, (lab, v, c, ls, ital) in enumerate(series):
        h, _ = np.histogram(np.clip(v, lo, hi * 0.999), edges)
        f = h / h.sum()
        ax.stairs(f, edges, color=c, lw=1.0, ls=ls, label=lab)
        med = np.median(v)
        ax.plot([med], [1.0], marker='v', ms=4, color=c, transform=ax.get_xaxis_transform(), clip_on=False)
        src.append(dict(series=lab, n=len(v), median=med, q25=np.percentile(v, 25), q75=np.percentile(v, 75),
                        mode_bin_center=float(np.sqrt(edges[np.argmax(h)] * edges[np.argmax(h) + 1])),
                        frac_below_0_05=float(np.mean(v < 0.05))))
    log_axis(ax, lo, hi, cands=(0.001, 0.01, 0.025, 0.05, 0.1, 0.2, 0.5, 1, 2))
    ax.set_xticklabels(['≤ 0.001'] + [t.get_text() for t in ax.get_xticklabels()[1:]])
    ax.set_xlabel('Ks (YN00)')
    ax.set_ylabel('Fraction of gene pairs')
    ax.set_ylim(0, None)
    leg = ax.legend(loc='upper left', bbox_to_anchor=(1.0, 1.0))
    for t in leg.get_texts()[:2]:
        t.set_fontstyle('italic')
    ax.text(1.0, 1.02, '▼ median', transform=ax.transAxes, ha='right', va='bottom', fontsize=5.5, color=GREY)
    save(fig, out, 'fig2b_ks', pd.DataFrame(src))


def muscle_pairs(B, sp):
    f = read(f'{B}/analysis/joint_features_{sp}.tsv.gz').set_index('gene')
    tp = read(f'{B}/rna/counts/{sp}.tpm.tsv').set_index('gene')
    cols = [c for c in tp.columns if c.startswith('muscle_')]
    tpm = tp[cols].mean(axis=1)
    d = strict_pairs(B, sp)
    for s in 'AB':
        d[f'tpm_{s}'] = tpm.reindex(d[f'{s}_gene']).values
        d[f'PC1_{s}'] = f['PC1'].reindex(d[f'{s}_gene']).values
    d = d[(np.maximum(d['tpm_A'], d['tpm_B']) >= 1)].dropna(subset=['tpm_A', 'tpm_B', 'PC1_A', 'PC1_B']).copy()
    d['log2FC'] = np.log2((d['tpm_B'] + 1) / (d['tpm_A'] + 1))
    d['config'] = np.where((d['PC1_A'] > 0) & (d['PC1_B'] > 0), 'both A',
                           np.where((d['PC1_A'] < 0) & (d['PC1_B'] < 0), 'both B', 'split'))
    d['oriented'] = np.where(d['PC1_B'] > d['PC1_A'], d['log2FC'], -d['log2FC'])
    d['species'], d['muscle_samples'] = sp, len(cols)
    return d, f


def fig4a_occupancy(B, out):
    rows = []
    for sp in ('tl', 'cx'):
        f = read(f'{B}/analysis/joint_features_{sp}.tsv.gz')
        f = f.dropna(subset=['PC1'])
        pc = pd.read_csv(need(f'{B}/te_tad/{sp}/renamed/{sp}.PC1_100k.bedgraph'), sep='\t', header=None,
                         names=['chr', 'start', 'end', 'PC1'], na_values='NA').dropna()
        pc['sub'] = pc['chr'].str.extract(r'^chr([AB])\d+$', expand=False)
        for metric, d in (('genes', f), ('100-kb bins', pc[pc['sub'].notna()])):
            k = {s: int(((d['sub'] == s) & (d['PC1'] > 0)).sum()) for s in 'AB'}
            n = {s: int((d['sub'] == s).sum()) for s in 'AB'}
            orr, p = fisher_exact([[k['B'], n['B'] - k['B']], [k['A'], n['A'] - k['A']]])
            for s in 'AB':
                lo, hi = exact_ci(k[s], n[s])
                rows.append(dict(species=sp, metric=metric, sub=s, n=n[s], in_A=k[s], frac_A=k[s] / n[s],
                                 lo95=float(lo), hi95=float(hi), OR_B_vs_A=orr, fisher_p=p))
    t = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(80 * MM, 40 * MM))
    keys = [(sp, m) for sp in ('tl', 'cx') for m in ('genes', '100-kb bins')]
    for k, (sp, metric) in enumerate(keys):
        yy = len(keys) - 1 - k - (0.4 if sp == 'cx' else 0)
        d = t[(t['species'] == sp) & (t['metric'] == metric)]
        for r in d.itertuples():
            forest_point(ax, r.frac_A, yy + (0.12 if r.sub == 'A' else -0.12), r.lo95, r.hi95, color=SUB[r.sub],
                         marker='o', ms=3.8, mfc=SUB[r.sub], mec='white', mew=0.5, ls='none', zorder=3)
        r = d.iloc[0]
        ax.text(1.02, yy, f'OR {r.OR_B_vs_A:.2f}, P = {fmt_p(r.fisher_p)}', transform=ax.get_yaxis_transform(),
                va='center', fontsize=5.8)
        ax.text(-0.02, yy, metric, transform=ax.get_yaxis_transform(), ha='right', va='center', fontsize=6.5)
    for sp, yy in (('tl', 2.5), ('cx', 0.1)):
        ax.text(-0.32, yy, SP_NAME[sp], transform=ax.get_yaxis_transform(), ha='right', va='center',
                fontstyle='italic', fontsize=7)
    ax.set_yticks([])
    ax.spines['left'].set_visible(False)
    ref_line(ax, 0.5)
    ax.set_xlabel('Fraction in the A (active) compartment')
    h = [Line2D([], [], marker='o', ms=3.8, mfc=SUB[s], mec='white', color=SUB[s], lw=0.8) for s in 'AB']
    ax.legend(h, ['SubA', 'SubB'], loc='lower left', bbox_to_anchor=(0, 1.0), ncol=2)
    ax.set_ylim(-0.8, 3.5)
    save(fig, out, 'fig4a_compartment_occupancy', t)


def fig4c_pairs(B, out):
    rows, allp = [], []
    for sp in ('tl', 'cx'):
        d, _ = muscle_pairs(B, sp)
        allp.append(d)
        for cfg in ('both A', 'both B', 'split'):
            v = d.loc[d['config'] == cfg, 'log2FC'].abs()
            med, lo, hi = boot_median_ci(v)
            rows.append(dict(species=sp, measure='|log2FC|', group=cfg, n=len(v), median=med, lo95=lo, hi95=hi))
        x, y = d.loc[d['config'] == 'split', 'log2FC'].abs(), d.loc[d['config'] != 'split', 'log2FC'].abs()
        rows[-1]['p_split_vs_same'] = mannwhitneyu(x, y).pvalue
        v = d.loc[d['config'] == 'split', 'oriented']
        med, lo, hi = boot_median_ci(v)
        npos, nneg = int((v > 0).sum()), int((v < 0).sum())
        rows.append(dict(species=sp, measure='oriented', group='split: copy in A − copy in B', n=len(v), median=med,
                         lo95=lo, hi95=hi, frac_A_copy_higher=npos / max(npos + nneg, 1),
                         p_sign=binomtest(npos, npos + nneg).pvalue if npos + nneg else np.nan))
    t = pd.DataFrame(rows)
    fig, axes = plt.subplots(1, 2, figsize=(110 * MM, 36 * MM), gridspec_kw=dict(width_ratios=[1.5, 1]))
    ax = axes[0]
    for k, cfg in enumerate(('split', 'both B', 'both A')):
        for r in t[(t['measure'] == '|log2FC|') & (t['group'] == cfg)].itertuples():
            forest_point(ax, r.median, k + (0.12 if r.species == 'tl' else -0.12), r.lo95, r.hi95,
                         **species_marker(r.species, size=3.6))
    ax.set_yticks(range(3), ['different compartments', 'both in B', 'both in A'])
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('median |log2FC| in muscle (95% CI)')
    ax = axes[1]
    for r in t[t['measure'] == 'oriented'].itertuples():
        forest_point(ax, r.median, 0.12 if r.species == 'tl' else -0.12, r.lo95, r.hi95,
                     **species_marker(r.species, size=3.6))
        ax.text(1.02, 0.12 if r.species == 'tl' else -0.12, f'{100 * r.frac_A_copy_higher:.0f}% higher in A, '
                f'P = {fmt_p(r.p_sign)}', transform=ax.get_yaxis_transform(), va='center', fontsize=5.5)
    ref_line(ax, 0)
    ax.set_yticks([0], ['split pairs'])
    ax.set_ylim(-0.6, 0.6)
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('median log2FC, copy in A −\ncopy in B compartment')
    legend_species_tissue(axes[0], tissues=(), loc='lower left', bbox_to_anchor=(0, 1.0), ncol=2)
    fig.subplots_adjust(wspace=0.6)
    save(fig, out, 'fig4c_compartment_pairs_muscle', t)
    fig, axes = plt.subplots(1, 2, figsize=(96 * MM, 44 * MM), sharex=True, sharey=True)
    cm = matplotlib.colors.LinearSegmentedColormap.from_list('blue', ['#cde2fb', '#3987e5', '#104281'])
    x = pd.concat(allp, ignore_index=True)
    x['dPC1'] = x['PC1_B'] - x['PC1_A']
    ext = (x['dPC1'].min(), x['dPC1'].max(), x['log2FC'].min(), x['log2FC'].max())
    src = []
    for ax, sp in zip(axes, ('tl', 'cx')):
        d = x[x['species'] == sp]
        ax.hexbin(d['dPC1'], d['log2FC'], gridsize=28, cmap=cm, mincnt=1, bins='log', linewidths=0.1,
                  edgecolors='white', extent=ext)
        r, p = spearmanr(d['dPC1'], d['log2FC'])
        ax.text(0.03, 0.97, f'ρ = {r:.2f}\nn = {len(d):,}', transform=ax.transAxes, va='top', fontsize=6)
        ax.set_title(SP_NAME[sp], fontstyle='italic', pad=3)
        ref_line(ax, 0); ref_line(ax, 0, horizontal=False)
        ax.set_xlabel('ΔPC1 (SubB − SubA)')
        src.append(dict(species=sp, n=len(d), spearman_rho=r, p=p, muscle_samples=int(d['muscle_samples'].iloc[0])))
    axes[0].set_ylabel('muscle log2FC (B/A)')
    fig.subplots_adjust(wspace=0.1)
    save(fig, out, 'fig4c2_dPC1_vs_expression', pd.DataFrame(src))


PRED_LAB = {'up_TE': 'TE cover, 2 kb upstream', 'down_TE': 'TE cover, 2 kb downstream',
            'up_youngTE': 'young TE cover, upstream', 'PC1': 'compartment PC1', 'log_tad': 'TAD-boundary distance',
            'log_len': 'CDS length', 'prom_meth': 'promoter methylation', 'body_meth': 'gene-body methylation',
            'teprom_meth': 'promoter-TE methylation', 'atac': 'promoter accessibility (ATAC)'}
MODEL_USE = {'eye': 'M1', 'liver': 'M3', 'muscle': 'M1'}


def fig4g_joint(B, out, model_use=None, name='fig4g_joint_model'):
    mu = dict(model_use or MODEL_USE)
    L = read(f'{B}/analysis/joint_model_lmg.tsv')
    S = read(f'{B}/analysis/joint_model_summary.tsv')
    L, S = L[L['pair_set'] == 'all'].copy(), S[S['pair_set'] == 'all'].copy()
    for d in (L, S):
        d['kind'] = np.where(d['model'].str.startswith('signed'), 'signed', 'magnitude')
        d['version'] = d['model'].str.extract(r'_(M\d)$', expand=False).fillna('M1')
    if mu.get('liver') == 'M3' and not (L['version'] == 'M3').any():
        mu['liver'] = 'M1'
    sel = lambda d: d[[mu.get(t) == v for t, v in zip(d['tissue'], d['version'])]]
    L, S1 = sel(L).copy(), sel(S).copy()
    L['short'] = L['predictor'].str.replace(r'^a?d_', '', regex=True)
    preds = [p for p in PRED_LAB if p in set(L['short'])]
    tissues = [t for t in ('eye', 'liver', 'muscle') if t in set(L['tissue'])]
    off = {}
    combos = [(sp, t) for t in tissues for sp in ('tl', 'cx')]
    for i, c in enumerate(combos):
        off[c] = 0.33 - 0.66 * i / max(len(combos) - 1, 1)
    fig, axes = plt.subplots(1, 2, figsize=(130 * MM, 62 * MM), sharey=True)
    for ax, kind, title in zip(axes, ('signed', 'magnitude'), ('signed bias: log2FC ~ Δ features',
                                                              'magnitude: |log2FC| ~ |Δ features|')):
        d = L[L['kind'] == kind]
        for r in d.itertuples():
            k = len(preds) - 1 - preds.index(r.short)
            mk = species_marker(r.species, r.tissue, size=3.4)
            forest_point(ax, 100 * r.LMG, k + off[(r.species, r.tissue)], 100 * r.LMG_lo, 100 * r.LMG_hi, **mk)
        ax.set_title(title, pad=3)
        ax.set_xlabel('variance explained (LMG, %)')
        ax.set_xlim(0, None)
        for k in range(len(preds) - 1):
            ax.axhline(k + 0.5, color=LIGHTER, lw=0.5, zorder=0)
        ax.tick_params(axis='y', length=0)
    axes[0].set_yticks(range(len(preds)), [PRED_LAB[p] for p in preds[::-1]])
    lab = {'M1': '', 'M2': ', with promoter-TE methylation', 'M3': ', with ATAC'}
    legend_species_tissue(axes[1], tissues=tuple(tissues), loc='upper left', bbox_to_anchor=(1.0, 1.0))
    txt = 'R² (95% CI)\n' + '\n'.join(
        f"{r.species} {r.tissue}{lab.get(r.version, '')}, {r.kind}: {100 * r.R2:.1f}% [{100 * r.R2_lo:.1f}–{100 * r.R2_hi:.1f}]"
        for r in S1.sort_values(['kind', 'tissue', 'species'], ascending=[False, True, False]).itertuples())
    axes[1].text(1.03, 0.0, txt, transform=axes[1].transAxes, fontsize=5, va='bottom', ha='left')
    fig.subplots_adjust(wspace=0.08)
    save(fig, out, name, L.merge(S1[['species', 'tissue', 'model', 'n', 'R2', 'R2_lo', 'R2_hi']],
                                 on=['species', 'tissue', 'model'], how='left'))


def chrom_sizes(B, sp):
    fai = f'{B}/{sp}_AB.fa.fai'
    if os.path.exists(fai):
        d = pd.read_csv(fai, sep='\t', header=None, usecols=[0, 1], names=['chr', 'len'], dtype={'chr': str})
        return dict(zip(d['chr'], d['len']))
    sizes, cur = {}, None
    with open(need(f'{B}/{sp}_AB.fa')) as f:
        for line in f:
            if line.startswith('>'):
                cur = line[1:].split()[0]; sizes[cur] = 0
            else:
                sizes[cur] += len(line.strip())
    return sizes


def fig5c_he_ring(B, out, he_set='recalibrated'):
    from matplotlib.patches import Wedge
    R = read(f'{B}/analysis/he_calls_legacy.tsv', dtype={'A_chr': str, 'B_chr': str})
    R = R[R['set'] == he_set]
    col = {'B_to_A': SUB['B'], 'A_to_B': SUB['A'], 'reciprocal': GREY}
    fig, axes = plt.subplots(1, 2, figsize=(150 * MM, 75 * MM))
    src = []
    for ax, sp in zip(axes, ('tl', 'cx')):
        L = chrom_sizes(B, sp)
        nums = sorted({int(c[4:]) for c in L if re.fullmatch(r'chr[AB]\d+', c)})
        if not nums:
            raise RuntimeError(f'no chrA../chrB.. chromosomes in {B}/{sp}_AB.fa(.fai)')
        span = [max(L.get(f'chrA{n:02d}', 0), L.get(f'chrB{n:02d}', 0)) for n in nums]
        gap = 1.2
        scale = (360 - gap * len(nums)) / sum(span)
        start, th = {}, 90.0
        for n, sz in zip(nums, span):
            start[n] = th
            th -= sz * scale + gap
        ang = lambda n, pos: start[n] - pos * scale
        tracks = {'A': (1.0, 0.09), 'B': (0.86, 0.09)}
        for n in nums:
            for s in 'AB':
                c = f'chr{s}{n:02d}'
                if c not in L:
                    continue
                r0, w = tracks[s]
                ax.add_patch(Wedge((0, 0), r0, ang(n, L[c]), ang(n, 0), width=w, fc=LIGHTER, ec=LIGHT, lw=0.3))
            mid = np.deg2rad(ang(n, span[nums.index(n)] / 2))
            ax.text(1.07 * np.cos(mid), 1.07 * np.sin(mid), str(n), ha='center', va='center', fontsize=5.5)
        d = R[R['species'] == sp]
        for r in d.itertuples():
            sides = {'B_to_A': ['A'], 'A_to_B': ['B'], 'reciprocal': ['A', 'B']}[r.type]
            for s in sides:
                c, a0, a1 = (r.A_chr, r.A_start, r.A_end) if s == 'A' else (r.B_chr, r.B_start, r.B_end)
                if not isinstance(c, str) or c == 'NA' or a1 <= a0:
                    continue
                n = int(c[4:])
                t1, t0 = ang(n, a1), ang(n, a0)
                if t0 - t1 < 0.35:
                    t1 = (t0 + t1) / 2 - 0.175; t0 = t1 + 0.35
                r0, w = tracks[s]
                ax.add_patch(Wedge((0, 0), r0, t1, t0, width=w, fc=col[r.type], ec='none', lw=0))
        cnt = d['type'].value_counts()
        mb = d.groupby('type')['Mb'].sum()
        ax.text(0, 0.2, SP_NAME[sp], ha='center', va='center', fontsize=7, fontstyle='italic')
        ax.text(0, 0.06, '\n'.join(f"{lab} {int(cnt.get(t, 0))} ({mb.get(t, 0):.1f} Mb)" for t, lab in
                                   (('B_to_A', 'B→A'), ('A_to_B', 'A→B'), ('reciprocal', 'reciprocal'))
                                   if cnt.get(t, 0)), ha='center', va='top', fontsize=6, linespacing=1.4)
        for t in ('B_to_A', 'A_to_B', 'reciprocal'):
            src.append(dict(species=sp, set=he_set, type=t, n=int(cnt.get(t, 0)), Mb=float(mb.get(t, 0))))
        ax.set_xlim(-1.15, 1.15); ax.set_ylim(-1.15, 1.15); ax.set_aspect('equal'); ax.axis('off')
    items = [(SUB['B'], 'B→A (SubA track)'), (SUB['A'], 'A→B (SubB track)')]
    if (R['type'] == 'reciprocal').any():
        items.append((GREY, 'reciprocal'))
    items.append((LIGHTER, 'outer SubA, inner SubB'))
    axes[1].legend([plt.Rectangle((0, 0), 1, 1, color=c) for c, _ in items], [l for _, l in items],
                   loc='upper left', bbox_to_anchor=(0.95, 1.0))
    save(fig, out, 'fig5c_he_ring', pd.DataFrame(src))


def fig6ab_profiles(B, out):
    t = read(f'{B}/analysis/meth_profiles.tsv')
    for feat, name, ticks in (('gene', 'fig6a_gene_meth_profile', ('−2 kb', 'TSS', 'TES', '+2 kb')),
                              ('TE_2kb', 'fig6b_te_near_gene_meth_profile', ('−1 kb', '5′', '3′', '+1 kb')),
                              ('TE', 'fig6b2_te_all_meth_profile', ('−1 kb', '5′', '3′', '+1 kb'))):
        d = t[t['feature'] == feat]
        if d.empty:
            print(f'  ({feat} not in meth_profiles.tsv: rerun meth_profile.py)')
            continue
        nb = d['bin'].max() + 1
        nf = int((d[(d['species'] == 'tl') & (d['tissue'] == 'eye') & (d['sub'] == 'A')]['region'] == 'upstream').sum())
        fig, axes = plt.subplots(1, 4, figsize=(165 * MM, 36 * MM), sharey=True)
        for ax, (sp, tissue) in zip(axes, [(s, ti) for s in ('tl', 'cx') for ti in ('eye', 'liver')]):
            for s in 'AB':
                x = d[(d['species'] == sp) & (d['tissue'] == tissue) & (d['sub'] == s)].sort_values('bin')
                xs = x['bin'] + 0.5
                ax.fill_between(xs, x['lo95'], x['hi95'], color=SUB[s], alpha=0.25, lw=0)
                ax.plot(xs, x['level'], color=SUB[s], lw=1.0, label=f'Sub{s}')
            for b in (nf, nb - nf):
                ax.axvline(b, color=LIGHT, lw=0.5, zorder=0)
            ax.set_xticks([0, nf, nb - nf, nb], ticks)
            labs = ax.get_xticklabels()
            labs[0].set_ha('left'); labs[-1].set_ha('right')
            ax.set_xlim(0, nb)
            ax.set_title(f'{SP_NAME[sp]}, {tissue}', fontsize=6.5, pad=3)
        for ax in axes:
            ax.title.set_fontstyle('normal')
        axes[0].set_ylabel('CpG methylation')
        axes[-1].legend(loc='upper left', bbox_to_anchor=(1.0, 1.0))
        fig.subplots_adjust(wspace=0.15)
        save(fig, out, name, d)


def pooled_pairs(B):
    p = read(f'{B}/analysis/methexpr_pairs.tsv.gz', dtype={'individual': str, 'HE': str})
    return p[p['individual'] == 'pooled'].copy()


def fig6c_scatter(B, out):
    p = pooled_pairs(B)
    cm = matplotlib.colors.LinearSegmentedColormap.from_list('blue', ['#cde2fb', '#3987e5', '#104281'])
    fig, axes = plt.subplots(1, 4, figsize=(150 * MM, 40 * MM), sharex=True, sharey=True)
    ext = (p['dMeth'].min(), p['dMeth'].max(), p['log2FC'].min(), p['log2FC'].max())
    src = []
    for ax, (sp, tissue) in zip(axes, [(s, ti) for s in ('tl', 'cx') for ti in ('eye', 'liver')]):
        d = p[(p['species'] == sp) & (p['tissue'] == tissue)]
        ax.hexbin(d['dMeth'], d['log2FC'], gridsize=30, cmap=cm, mincnt=1, bins='log', linewidths=0.1,
                  edgecolors='white', extent=ext)
        for v in (-T_METH, T_METH):
            ax.axvline(v, color=GREY, lw=0.5, ls=(0, (2, 2)))
        for v in (-T_FC, T_FC):
            ax.axhline(v, color=GREY, lw=0.5, ls=(0, (2, 2)))
        a = int(((d['dMeth'] <= -T_METH) & (d['log2FC'] >= T_FC)).sum())
        b = int(((d['dMeth'] >= T_METH) & (d['log2FC'] <= -T_FC)).sum())
        r, pr = spearmanr(d['dMeth'], d['log2FC'])
        ax.text(0.02, 0.98, f'SubA repressed\nn = {a}', transform=ax.transAxes, va='top', fontsize=5.5, color=SUB['A'])
        ax.text(0.98, 0.02, f'SubB repressed\nn = {b}', transform=ax.transAxes, va='bottom', ha='right', fontsize=5.5,
                color=SUB['B'])
        ax.text(0.98, 0.98, f'ρ = {r:.2f}', transform=ax.transAxes, va='top', ha='right', fontsize=6)
        ax.set_title(f'{SP_NAME[sp]}, {tissue}', fontsize=6.5, pad=3)
        ax.set_xlabel('ΔMeth (SubB − SubA)')
        src.append(dict(species=sp, tissue=tissue, n=len(d), spearman_rho=r, p=pr, n_A_repressed=a, n_B_repressed=b))
    axes[0].set_ylabel('log2FC (B/A)')
    fig.subplots_adjust(wspace=0.08)
    save(fig, out, 'fig6c_dmeth_vs_log2fc', pd.DataFrame(src))


def fig6d_share(B, out):
    t = read(f'{B}/analysis/methexpr_summary.tsv', dtype={'individual': str})
    t = t[t['pair_set'] == 'all'].copy()
    t['n'] = t['n_A_silenced'] + t['n_B_silenced']
    t['lo95'], t['hi95'] = exact_ci(t['n_A_silenced'], t['n'])
    rows = [(sp, ti) for sp in ('tl', 'cx') for ti in ('eye', 'liver')]
    off = {'1': 0.22, '2': 0.0, 'pooled': -0.22}
    mk_ind = {'1': 'o', '2': 's', 'pooled': 'D'}
    fig, ax = plt.subplots(figsize=(90 * MM, 50 * MM))
    for k, (sp, ti) in enumerate(rows):
        y0 = len(rows) - 1 - k
        for r in t[(t['species'] == sp) & (t['tissue'] == ti)].itertuples():
            y = y0 + off.get(r.individual, 0)
            ax.plot([r.perm_lo95, r.perm_hi95], [y, y], color=LIGHT, lw=3.2, solid_capstyle='butt', zorder=1)
            mk = species_marker(sp, size=3.4 if r.individual != 'pooled' else 3.0)
            mk['marker'] = mk_ind.get(r.individual, 'o')
            forest_point(ax, r.share_A, y, float(r.lo95), float(r.hi95), **mk)
            ax.text(1.02, y, f'{r.n_A_silenced}:{r.n_B_silenced}, P = {fmt_p(r.perm_p)}',
                    transform=ax.get_yaxis_transform(), va='center', fontsize=5.3)
    ref_line(ax, 0.5)
    ax.set_yticks(range(len(rows))[::-1], [f'{ti}' for _, ti in rows])
    for sp, yy in (('tl', 2.5), ('cx', 0.5)):
        ax.text(-0.12, yy, SP_NAME[sp], transform=ax.get_yaxis_transform(), ha='right', va='center',
                fontstyle='italic', fontsize=7)
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('SubA share of methylation-associated repressed copies')
    h = [Line2D([], [], marker=mk_ind[i], ms=3.4, mec=INK, mfc=LIGHT, ls='none') for i in ('1', '2', 'pooled')] + \
        [Line2D([], [], color=LIGHT, lw=3.2)]
    ax.legend(h, ['individual 1', 'individual 2', 'pooled', 'permutation null (95%)'], loc='upper left',
              bbox_to_anchor=(1.32, 1.0))
    ax.text(1.02, 1.0, 'A:B repressed', transform=ax.transAxes, fontsize=5.3, color=GREY, va='bottom')
    save(fig, out, 'fig6d_share_vs_null', t)


def fig6e_quartets(B, out):
    t = read(f'{B}/analysis/quartet_summary.tsv', dtype={'individual': str})
    t = t[t['pair_set'] == 'all'].copy()
    t['n'] = t['n_concordant'] + t['n_discordant']
    t['conc_share'] = t['n_concordant'] / t['n']
    t['lo95'], t['hi95'] = exact_ci(t['n_concordant'], t['n'])
    t['p_conc'] = [binomtest(int(a), int(n)).pvalue for a, n in zip(t['n_concordant'], t['n'])]
    mk_ind = {'1': 'o', '2': 's', 'pooled': 'D'}
    off = {'1': 0.2, '2': 0.0, 'pooled': -0.2}
    fig, axes = plt.subplots(1, 2, figsize=(120 * MM, 34 * MM), sharey=True)
    for k, ti in enumerate(('eye', 'liver')):
        y0 = 1 - k
        for r in t[t['tissue'] == ti].itertuples():
            y = y0 + off.get(r.individual, 0)
            mk = dict(marker=mk_ind.get(r.individual, 'o'), ms=3.4, mec=INK, mfc=INK, ls='none', zorder=3)
            forest_point(axes[0], r.conc_share, y, float(r.lo95), float(r.hi95), **mk)
            axes[1].plot([r.null_flip_lo95, r.null_flip_hi95], [y, y], color=LIGHT, lw=3.2, solid_capstyle='butt')
            axes[1].plot([r.n_flip], [y], **mk)
    ref_line(axes[0], 0.5)
    axes[0].set_xlabel('concordant share of lineage-specific\nchanges (ΔΔMeth vs Δlog2FC)')
    axes[1].set_xlabel('quartets with opposite repressed copy\n(observed vs permutation null)')
    axes[0].set_yticks([1, 0], ['eye', 'liver'])
    for ax in axes:
        ax.tick_params(axis='y', length=0)
    h = [Line2D([], [], marker=mk_ind[i], ms=3.4, mec=INK, mfc=INK, ls='none') for i in ('1', '2', 'pooled')] + \
        [Line2D([], [], color=LIGHT, lw=3.2)]
    axes[1].legend(h, ['individual 1', 'individual 2', 'pooled', 'null (95%)'], loc='upper left',
                   bbox_to_anchor=(1.0, 1.0))
    fig.subplots_adjust(wspace=0.12)
    save(fig, out, 'fig6e_quartets', t)


def fig6f_categories(B, out):
    p = pooled_pairs(B)
    dm, fc = p['dMeth'], p['log2FC']
    cats = [('A_rep', 'SubA repressed (more methylated, lower)', SUB['A'],
             (dm <= -T_METH) & (fc >= T_FC)),
            ('B_rep', 'SubB repressed (more methylated, lower)', SUB['B'], (dm >= T_METH) & (fc <= -T_FC)),
            ('opp', 'more methylated copy higher', GREY,
             ((dm <= -T_METH) & (fc <= -T_FC)) | ((dm >= T_METH) & (fc >= T_FC))),
            ('fc_only', '≥ 2-fold, ΔMeth < 0.3', LIGHT, (fc.abs() >= T_FC) & (dm.abs() < T_METH)),
            ('meth_only', 'ΔMeth ≥ 0.3, < 2-fold', '#b3b1ab', (dm.abs() >= T_METH) & (fc.abs() < T_FC)),
            ('neither', 'neither', LIGHTER, (dm.abs() < T_METH) & (fc.abs() < T_FC))]
    for c, _, _, sel in cats:
        p[c] = sel.astype(int)
    t = p.groupby(['species', 'tissue'])[[c for c, *_ in cats]].sum().reset_index()
    t['n_pairs'] = t[[c for c, *_ in cats]].sum(axis=1)
    t['species'] = pd.Categorical(t['species'], ['tl', 'cx'])
    t = t.sort_values(['species', 'tissue']).reset_index(drop=True)
    t['species'] = t['species'].astype(str)
    fig, ax = plt.subplots(figsize=(100 * MM, 38 * MM))
    stacked_bars(ax, t, [(c, l, col) for c, l, col, _ in cats], 'tissue')
    ax.set_xlabel('Homoeolog pairs (%)')
    save(fig, out, 'fig6f_pair_categories', t)


def woolf_ci(a, b, c, d):
    a, b, c, d = [np.asarray(x, float) + 0.5 for x in (a, b, c, d)]
    lor = np.log(a * d / (b * c))
    se = np.sqrt(1 / a + 1 / b + 1 / c + 1 / d)
    return np.exp(lor), np.exp(lor - 1.96 * se), np.exp(lor + 1.96 * se)


def figS6_fractionation(B, out):
    t = read(f'{B}/analysis/fractionation_genomes.tsv').set_index('genome')
    rows = [(g, lab) for g, lab in GENOMES if g in t.index]
    d = t.loc[[g for g, _ in rows]].reset_index()
    d['label'], d['species'] = [lab for _, lab in rows], 'x'
    seg = [('A_only', 'retained in SubA only', SUB['A']), ('both_retained', 'retained in both', LIGHT),
           ('both_lost', 'lost in both', LIGHTER), ('B_only', 'retained in SubB only', SUB['B'])]
    fig, ax = plt.subplots(figsize=(100 * MM, 52 * MM))
    y = np.arange(len(d))[::-1]
    for yi, (_, r) in zip(y, d.iterrows()):
        tot, left = sum(r[c] for c, _, _ in seg), 0.0
        for col, _, c in seg:
            w = r[col] / tot
            ax.barh(yi, w, left=left, height=0.62, color=c, edgecolor='white', linewidth=0.6)
            if w > 0.06:
                ax.text(left + w / 2, yi, f'{100 * w:.0f}%', ha='center', va='center', fontsize=5.5,
                        color='white' if c in (SUB['A'], SUB['B']) else INK)
            left += w
    ax.set_yticks(y, d['label']); italic_ticks(ax)
    ax.set_xlim(0, 1); ax.set_xticks([0, .25, .5, .75, 1], ['0', '25', '50', '75', '100'])
    ax.set_xlabel('Genes called in both subgenomes (%)')
    ax.tick_params(axis='y', length=0); ax.spines['left'].set_visible(False)
    ax.legend([plt.Rectangle((0, 0), 1, 1, color=c) for _, _, c in seg], [l for _, l, _ in seg], ncol=2,
              loc='lower left', bbox_to_anchor=(-0.02, 1.02), fontsize=5.8)
    save(fig, out, 'figS6a_retention_status', d)
    L = read(f'{B}/analysis/fractionation_lineage_specific.tsv').set_index('focal')
    rows = [(g, lab) for g, lab in GENOMES if g in L.index]
    d = L.loc[[g for g, _ in rows]].reset_index()
    d['label'] = [lab for _, lab in rows]
    d['OR'], d['lo95'], d['hi95'] = woolf_ci(d['lost_A'], d['at_risk_A'] - d['lost_A'], d['lost_B'], d['at_risk_B'] - d['lost_B'])
    fig, ax = plt.subplots(figsize=(80 * MM, 50 * MM))
    y = np.arange(len(d))[::-1]
    for yi, r in zip(y, d.itertuples()):
        forest_point(ax, r.OR, yi, r.lo95, r.hi95, marker='o', ms=3.8, mec=INK, mfc=INK if r.focal in FOCAL_G else 'white',
                     mew=0.7, ls='none', zorder=3)
        ax.text(1.02, yi, f'{100 * r.rate_A:.1f}% vs {100 * r.rate_B:.1f}%', transform=ax.get_yaxis_transform(),
                va='center', fontsize=5.5)
    ref_line(ax, 1)
    log_axis(ax, min(0.5, d['lo95'].min() * 0.9), max(2, d['hi95'].max() * 1.1))
    ax.set_yticks(y, d['label']); italic_ticks(ax); ax.tick_params(axis='y', length=0)
    ax.set_xlabel('Odds ratio of lineage-specific loss, SubA vs SubB')
    ax.text(1.02, 1.0, 'loss rate A vs B', transform=ax.transAxes, fontsize=5.5, color=GREY, va='bottom')
    save(fig, out, 'figS6b_lineage_specific_loss', d)


FOCAL_G = ('tianlinensis', 'longibarbatus')


def figS9_heb(B, out):
    src, tissues_sp = [], {}
    for sp in ('tl', 'cx'):
        tp = read(f'{B}/rna/counts/{sp}.tpm.tsv').set_index('gene')
        m = strict_pairs(B, sp)
        ts = sorted({c.rsplit('_', 1)[0] for c in tp.columns if re.fullmatch(r'.+_\d+', c)},
                    key=lambda x: (x not in ('eye', 'liver'), x))
        tissues_sp[sp] = ts
        for t in ts:
            cols = [c for c in tp.columns if re.fullmatch(rf'{t}_\d+', c)]
            A, Bm = tp[cols].reindex(m['A_gene']).mean(axis=1).values, tp[cols].reindex(m['B_gene']).mean(axis=1).values
            ok = np.isfinite(A) & np.isfinite(Bm) & (np.maximum(A, Bm) >= 1)
            fc = np.log2((Bm[ok] + 1) / (A[ok] + 1))
            src.append(dict(species=sp, tissue=t, samples=len(cols), n_pairs=int(ok.sum()), median_log2FC=float(np.median(fc)),
                            frac_B_2fold=float((fc >= 1).mean()), frac_A_2fold=float((fc <= -1).mean()), fc=fc))
    nmax = max(len(v) for v in tissues_sp.values())
    fig, axes = plt.subplots(2, nmax, figsize=(min(180, 22 * nmax) * MM, 50 * MM), sharex=True, sharey=True)
    edges = np.linspace(-6, 6, 49)
    for i, sp in enumerate(('tl', 'cx')):
        for j in range(nmax):
            ax = axes[i, j]
            if j >= len(tissues_sp[sp]):
                ax.axis('off'); continue
            r = next(x for x in src if x['species'] == sp and x['tissue'] == tissues_sp[sp][j])
            h, _ = np.histogram(np.clip(r['fc'], -6, 6), edges)
            ax.stairs(h / h.sum(), edges, color=INK, lw=0.8)
            ax.axvline(0, color=GREY, lw=0.5, ls=(0, (3, 2)))
            ax.set_title(f"{r['tissue']} ({r['samples']})", fontsize=6, pad=2)
            ax.text(0.03, 0.97, f"A {100 * r['frac_A_2fold']:.0f}%", transform=ax.transAxes, fontsize=5, va='top',
                    color=SUB['A'])
            ax.text(0.97, 0.97, f"B {100 * r['frac_B_2fold']:.0f}%", transform=ax.transAxes, fontsize=5, va='top',
                    ha='right', color=SUB['B'])
        axes[i, 0].set_ylabel(SP_NAME[sp], fontstyle='italic', fontsize=6.5)
    fig.supxlabel('log2FC (B/A); ≥ 2-fold shares shown (number of samples in brackets)', fontsize=6.5, y=-0.06)
    fig.subplots_adjust(wspace=0.1, hspace=0.35)
    save(fig, out, 'figS9a_heb_tissues', pd.DataFrame([{k: v for k, v in x.items() if k != 'fc'} for x in src]))
    k = read(f'{B}/analysis/bias_clustering.tsv')
    k = k[k['pair_set'] == 'all']
    stats = [('lag1_rho', 'neighbour ρ, lag 1'), ('lag2_rho', 'lag 2'), ('lag3_rho', 'lag 3'),
             ('var_1Mb_mean', 'variance of 1-Mb window means')]
    fig, ax = plt.subplots(figsize=(90 * MM, 50 * MM))
    keys = [(sp, t) for sp in ('tl', 'cx') for t in tissues_sp[sp]]
    for yi, (sp, t) in enumerate(keys[::-1]):
        d = k[(k['species'] == sp) & (k['tissue'] == t)]
        for si, (st, _) in enumerate(stats):
            r = d[d['statistic'] == st]
            if len(r):
                ax.plot([r['z'].iloc[0]], [yi + 0.15 - 0.1 * si], marker='osD^'[si], ms=3.2, mec=INK,
                        mfc=INK if sp == 'tl' else 'white', ls='none')
    ref_line(ax, 0); ax.axvline(1.96, color=LIGHT, lw=0.5)
    ax.set_yticks(range(len(keys)), [f'{sp} {t}' for sp, t in keys[::-1]])
    ax.tick_params(axis='y', length=0)
    ax.set_xlabel('z score vs within-chromosome permutation null')
    ax.legend([Line2D([], [], marker='osD^'[i], ms=3.2, mec=INK, mfc=LIGHT, ls='none') for i in range(4)],
              [l for _, l in stats], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    save(fig, out, 'figS9b_bias_clustering', k)


def figS12_te_age(B, out):
    ks = []
    for s in 'AB':
        d = read(f'{B}/te_polar/orth_{s}.ks.tsv')
        for c in ('Ks_YN00', 'cov', 'aln_codons'):
            d[c] = pd.to_numeric(d[c], errors='coerce')
        ks.append(d[(d['status'] == 'ok') & (d['cov'] >= 0.5) & (d['aln_codons'] >= 50) & (d['Ks_YN00'] >= 0) &
                    (d['Ks_YN00'] < 3)]['Ks_YN00'])
    ks_split = float(np.median(pd.concat(ks)))
    fig, axes = plt.subplots(1, 2, figsize=(120 * MM, 40 * MM), sharey=True)
    edges = np.linspace(0, 0.45, 46)
    src = []
    for ax, sp in zip(axes, ('tl', 'cx')):
        ft = read(f'{B}/te_polar/{sp}.flank_te.tsv.gz').drop_duplicates('te')
        for st, c in (('specific', INK), ('shared', GREY)):
            k = ft.loc[ft['status'] == st, 'K'].dropna()
            h, _ = np.histogram(np.clip(k, 0, 0.449), edges)
            ax.stairs(h / h.sum(), edges, color=c, lw=1.0, label='lineage-specific' if st == 'specific' else 'shared (pre-split)')
            src.append(dict(species=sp, status=st, n=len(k), K_median=k.median(), frac_K_below_Ks_split=(k < ks_split).mean()))
        ax.set_ylim(0, None)
        ax.axvline(ks_split, color=SUB['B'], lw=0.8, ls=(0, (3, 2)))
        ax.set_title(SP_NAME[sp], fontstyle='italic', pad=3)
        ax.set_xlabel('Kimura distance K of the TE copy')
    axes[1].legend(loc='upper left', bbox_to_anchor=(1.0, 1.0), fontsize=5.8)
    axes[0].set_ylabel('Fraction of TE copies')
    for ax in axes:
        ax.text(ks_split, 0.97, f' tl–cx ortholog Ks {ks_split:.3f}', transform=ax.get_xaxis_transform(),
                fontsize=5.3, color=SUB['B'], va='top')
    save(fig, out, 'figS12b_te_age_by_class', pd.DataFrame(src).assign(Ks_split=ks_split))


def figS14_compartments(B, out):
    q = []
    for sp in ('tl', 'cx'):
        d = read(f'{B}/te_tad/{sp}/renamed/{sp}.PC1_100k.qc.tsv')
        d['species'] = sp
        q.append(d)
    q = pd.concat(q)
    fig, ax = plt.subplots(figsize=(110 * MM, 34 * MM))
    for sp, off in (('tl', -0.15), ('cx', 0.15)):
        d = q[q['species'] == sp].sort_values('chrom')
        x = np.arange(len(d)) + off
        ax.plot(x, d['r_gene_density'], **species_marker(sp, size=3.2))
    ax.set_xticks(np.arange(len(q[q['species'] == 'tl'])), q[q['species'] == 'tl'].sort_values('chrom')['chrom'],
                  rotation=90, fontsize=5)
    ax.set_ylabel('r(PC, gene density)')
    ax.set_ylim(0, 1)
    legend_species_tissue(ax, tissues=(), loc='lower right', ncol=2)
    cov = []
    for sp in ('tl', 'cx'):
        lg = f'{B}/te_tad/{sp}/renamed/{sp}.PC1_100k.log'
        if os.path.exists(lg):
            cov += [f'{sp} ' + l.strip() for l in open(lg) if 'median cis contacts per bin' in l]
    if cov:
        ax.text(0.0, 1.03, '\n'.join(cov), transform=ax.transAxes, fontsize=5.3, va='bottom')
    save(fig, out, 'figS14a_pc1_orientation', q)
    cm = matplotlib.colors.LinearSegmentedColormap.from_list('blue', ['#cde2fb', '#3987e5', '#104281'])
    fig, axes = plt.subplots(2, 3, figsize=(150 * MM, 80 * MM))
    src = []
    for i, sp in enumerate(('tl', 'cx')):
        f = read(f'{B}/analysis/joint_features_{sp}.tsv.gz').set_index('gene')
        tp = read(f'{B}/rna/counts/{sp}.tpm.tsv').set_index('gene')
        mc = [c for c in tp.columns if c.startswith('muscle_')]
        f['logtpm'] = np.log2(tp[mc].mean(axis=1) + 1).reindex(f.index)
        f['TE'] = (f['up_TE'] + f['down_TE']) / 2
        d, _ = muscle_pairs(B, sp)
        d['ad_tad'] = (np.log10(f['tad_dist'].reindex(d['B_gene']).values + 1000) -
                       np.log10(f['tad_dist'].reindex(d['A_gene']).values + 1000))
        d['ad_tad'] = d['ad_tad'].abs()
        d['abs_fc'] = d['log2FC'].abs()
        for j, (x, y, xl, yl, data) in enumerate((('PC1', 'logtpm', 'PC1 (100 kb)', 'muscle log2(TPM + 1)', f),
                                                  ('PC1', 'TE', 'PC1 (100 kb)', 'TE cover, ±2 kb', f),
                                                  ('ad_tad', 'abs_fc', '|Δ log10 distance to TAD boundary|',
                                                   'muscle |log2FC|', d))):
            ax = axes[i, j]
            dd = data[[x, y]].dropna()
            ax.hexbin(dd[x], dd[y], gridsize=30, cmap=cm, mincnt=1, bins='log', linewidths=0.1, edgecolors='white')
            r, p = spearmanr(dd[x], dd[y])
            ax.text(0.03, 0.97, f'ρ = {r:.2f}\nn = {len(dd):,}', transform=ax.transAxes, va='top', fontsize=5.5)
            ax.set_xlabel(xl, fontsize=6); ax.set_ylabel(yl, fontsize=6)
            src.append(dict(species=sp, x=x, y=y, n=len(dd), spearman_rho=r, p=p))
        axes[i, 0].set_title(SP_NAME[sp], fontstyle='italic', loc='left', pad=3)
    fig.subplots_adjust(wspace=0.35, hspace=0.5)
    save(fig, out, 'figS14b_compartment_expression_te_tad', pd.DataFrame(src))


def figS16_he(B, out):
    t = read(f'{B}/analysis/he_power_legacy.tsv')
    sets = [s_ for s_ in ('published', 'symmetric_partnered') if s_ in set(t['thresholds'])]
    lab = {'published': 'published thresholds', 'symmetric_partnered': 'recalibrated (symmetric)'}
    fig, axes = plt.subplots(1, len(sets), figsize=(60 * len(sets) * MM, 40 * MM), sharey=True, squeeze=False)
    for ax, st in zip(axes[0], sets):
        for sp in ('tl', 'cx'):
            r = t[(t['species'] == sp) & (t['thresholds'] == st)].iloc[0]
            for d_, c in (('B_to_A', SUB['B']), ('A_to_B', SUB['A'])):
                y = [r[f'power_{d_}_{L}w'] for L in (5, 10, 20)]
                ax.plot([5, 10, 20], y, color=c, lw=1.0, ls='-' if sp == 'tl' else (0, (3, 1.5)),
                        marker='o', ms=3, mfc=c if sp == 'tl' else 'white', mec=c)
        ax.set_xscale('log'); ax.set_xticks([5, 10, 20], ['5', '10', '20'])
        ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
        ax.set_ylim(0, 1.02); ax.set_xlabel('exchange length (10-kb windows)')
        ax.set_title(lab[st], pad=3)
    axes[0, 0].set_ylabel('detection power (simulation)')
    h = [Line2D([], [], color=SUB['B'], lw=1), Line2D([], [], color=SUB['A'], lw=1),
         Line2D([], [], color=INK, lw=1), Line2D([], [], color=INK, lw=1, ls=(0, (3, 1.5)))]
    leg = axes[0, -1].legend(h, ['B→A', 'A→B', SP_NAME['tl'], SP_NAME['cx']], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    for tt in leg.get_texts()[2:]:
        tt.set_fontstyle('italic')
    save(fig, out, 'figS16a_he_power', t)
    e = read(f'{B}/analysis/he_sequence_evidence_legacy.tsv')
    e = e[e['thresholds'].isin(sets)]
    keys = list(dict.fromkeys(zip(e['evidence'], e['group'])))
    fig, axes = plt.subplots(1, len(sets), figsize=(60 * len(sets) * MM, (14 + 7 * len(keys)) * MM), sharey=True, squeeze=False)
    for ax, st in zip(axes[0], sets):
        for yi, (ev, g) in enumerate(keys[::-1]):
            for sp, off in (('tl', 0.12), ('cx', -0.12)):
                r = e[(e['thresholds'] == st) & (e['species'] == sp) & (e['evidence'] == ev) & (e['group'] == g)]
                if r.empty:
                    continue
                r = r.iloc[0]
                ax.plot([r['frac_extreme_outside'], r['frac_extreme']], [yi + off] * 2, color=LIGHT, lw=1.5, zorder=1)
                ax.plot([r['frac_extreme_outside']], [yi + off], marker='|', ms=5, color=GREY, ls='none')
                ax.plot([r['frac_extreme']], [yi + off], **species_marker(sp, size=3.4))
        ax.set_title(lab[st], pad=3)
        ax.set_xlabel('fraction of windows / genes beyond threshold\n(| = outside the calls)')
    axes[0, 0].set_yticks(range(len(keys)), [f'{ev}, {g.replace("_to_", "→")}' for ev, g in keys[::-1]])
    axes[0, 0].tick_params(axis='y', length=0)
    legend_species_tissue(axes[0, -1], tissues=(), loc='upper left', bbox_to_anchor=(1.0, 1.0))
    save(fig, out, 'figS16b_he_sequence_evidence', e)


def figS_abs_expression(B, out):
    p = pooled_pairs(B)
    fig, axes = plt.subplots(1, 4, figsize=(150 * MM, 38 * MM), sharex=True, sharey=True)
    src = []
    for ax, (sp, t) in zip(axes, [(s_, ti) for s_ in ('tl', 'cx') for ti in ('eye', 'liver')]):
        d = p[(p['species'] == sp) & (p['tissue'] == t)]
        cand = ((d['dMeth'] <= -T_METH) & (d['log2FC'] >= T_FC)) | ((d['dMeth'] >= T_METH) & (d['log2FC'] <= -T_FC))
        biased = (d['log2FC'].abs() >= T_FC) & ~cand
        for name, sel, c in (('candidate', cand, INK), ('biased, not candidate', biased, GREY)):
            lo = np.minimum(d.loc[sel, 'tpm_A'], d.loc[sel, 'tpm_B'])
            hi = np.maximum(d.loc[sel, 'tpm_A'], d.loc[sel, 'tpm_B'])
            for v, ls in ((lo, '-'), (hi, (0, (3, 1.5)))):
                x = np.sort(np.log10(v + 0.01))
                ax.plot(x, np.arange(1, len(x) + 1) / len(x), color=c, lw=0.9, ls=ls)
            src.append(dict(species=sp, tissue=t, pairs=name, n=int(sel.sum()), lower_TPM_median=lo.median(),
                            higher_TPM_median=hi.median(), frac_lower_below_1TPM=(lo < 1).mean(),
                            frac_lower_below_0_1TPM=(lo < 0.1).mean()))
        ax.axvline(0, color=LIGHT, lw=0.6)
        ax.set_title(f'{SP_NAME[sp]}, {t}', fontsize=6.5, pad=3)
        ax.set_xlabel('log10(TPM + 0.01)')
    axes[0].set_ylabel('cumulative fraction of pairs')
    h = [Line2D([], [], color=INK, lw=0.9), Line2D([], [], color=GREY, lw=0.9), Line2D([], [], color=INK, lw=0.9),
         Line2D([], [], color=INK, lw=0.9, ls=(0, (3, 1.5)))]
    axes[-1].legend(h, ['candidate repressed', 'biased, not candidate', 'lower copy', 'higher copy'],
                    loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.subplots_adjust(wspace=0.1)
    save(fig, out, 'figS_absolute_expression', pd.DataFrame(src))


def figS_robustness(B, out):
    g = read(f'{B}/analysis/methexpr_grid.tsv')
    fig, axes = plt.subplots(1, 4, figsize=(150 * MM, 46 * MM), sharex=True, sharey=True)
    for ax, (sp, t) in zip(axes, [(s_, ti) for s_ in ('tl', 'cx') for ti in ('eye', 'liver')]):
        d = g[(g['species'] == sp) & (g['tissue'] == t)].reset_index(drop=True)
        for i, r in d.iterrows():
            n = r['n_A_silenced'] + r['n_B_silenced']
            lo, hi = exact_ci(r['n_A_silenced'], n)
            yy = len(d) - 1 - i
            forest_point(ax, r['share_A'], yy, float(lo), float(hi), **species_marker(sp, size=3.2))
            ax.plot([r['perm_null_share_A']], [yy], marker='|', ms=6, color=SUB['B'], ls='none', zorder=4)
        ax.set_yticks(range(len(d)), [f'|ΔMeth| ≥ {r.t_meth}, |log2FC| ≥ {r.t_log2FC}' for r in d.itertuples()][::-1],
                      fontsize=5.5)
        ref_line(ax, 0.5)
        ax.set_title(f'{SP_NAME[sp]}, {t}', fontsize=6.5, pad=3)
        ax.tick_params(axis='y', length=0)
    fig.supxlabel('SubA share of methylation-associated repressed copies (| = permutation null)', fontsize=6.5, y=-0.04)
    save(fig, out, 'figS_threshold_grid', g)
    S = read(f'{B}/analysis/methexpr_summary.tsv', dtype={'individual': str})
    Q = read(f'{B}/analysis/quartet_summary.tsv', dtype={'individual': str})
    J = read(f'{B}/analysis/joint_model_summary.tsv')
    rows = []
    for r in S.itertuples():
        rows.append(dict(stat='ρ(ΔMeth, log2FC)', key=f'{r.species} {r.tissue} ind {r.individual}', pair_set=r.pair_set,
                         value=r.rho))
        rows.append(dict(stat='SubA share of candidates', key=f'{r.species} {r.tissue} ind {r.individual}',
                         pair_set=r.pair_set, value=r.share_A))
    for r in Q.itertuples():
        rows.append(dict(stat='quartets: ρ(ΔΔMeth, Δlog2FC)', key=f'{r.tissue} ind {r.individual}', pair_set=r.pair_set,
                         value=r.rho_delta))
    for r in J[J['model'].isin(['signed', 'signed_M3'])].itertuples():
        rows.append(dict(stat='joint model R² (signed)', key=f'{r.species} {r.tissue} {r.model}', pair_set=r.pair_set,
                         value=r.R2))
    t = pd.DataFrame(rows)
    w = t.pivot_table(index=['stat', 'key'], columns='pair_set', values='value', aggfunc='first').reset_index()
    stats = list(dict.fromkeys(t['stat']))
    fig, axes = plt.subplots(1, len(stats), figsize=(170 * MM, 70 * MM))
    for ax, st in zip(axes, stats):
        d = w[w['stat'] == st]
        y = np.arange(len(d))[::-1]
        for yi, r in zip(y, d.itertuples()):
            ax.plot([r.all, r.noHE], [yi, yi], color=LIGHT, lw=1.2, zorder=1)
            ax.plot([r.all], [yi], marker='o', ms=3.2, color=INK, ls='none', zorder=3)
            ax.plot([r.noHE], [yi], marker='o', ms=3.2, mfc='white', mec=INK, ls='none', zorder=3)
        ax.set_yticks(y, d['key'], fontsize=5)
        ax.set_title(st, fontsize=6, pad=3)
        ax.tick_params(axis='y', length=0)
    axes[-1].legend([Line2D([], [], marker='o', ms=3.2, color=INK, ls='none'),
                     Line2D([], [], marker='o', ms=3.2, mfc='white', mec=INK, ls='none')],
                    ['all pairs', 'pairs outside HE regions'], loc='upper left', bbox_to_anchor=(1.0, 1.0))
    fig.subplots_adjust(wspace=0.9)
    save(fig, out, 'figS_noHE_robustness', w)


def figS_joint_m2(B, out):
    fig4g_joint(B, out, model_use={'eye': 'M2', 'liver': 'M2'}, name='figS_joint_model_M2')


def figS17_meth_expression(B, out):
    fig, axes = plt.subplots(1, 4, figsize=(150 * MM, 40 * MM), sharey=True)
    src = []
    for ax, (sp, t) in zip(axes, [(s_, ti) for s_ in ('tl', 'cx') for ti in ('eye', 'liver')]):
        gm = read(f'{B}/meth/{sp}_{t}.gene_meth.tsv').set_index('gene')
        tp = read(f'{B}/rna/counts/{sp}.tpm.tsv').set_index('gene')
        reps = [c for c in tp.columns if re.fullmatch(rf'{t}_\d+', c)]
        tot = gm['rep1_prom_total'] + gm['rep2_prom_total']
        lev = ((gm['rep1_prom_meth'] + gm['rep2_prom_meth']) / tot)[tot >= 10]
        y = np.log2(tp[reps].mean(axis=1) + 1).reindex(lev.index)
        d = pd.DataFrame({'meth': lev, 'expr': y}).dropna()
        d['bin'] = pd.qcut(d['meth'].rank(method='first'), 10, labels=False)
        g = d.groupby('bin').agg(meth=('meth', 'median'), med=('expr', 'median'), q1=('expr', lambda v: v.quantile(.25)),
                                 q3=('expr', lambda v: v.quantile(.75)), n=('expr', 'size')).reset_index()
        for r in g.itertuples():
            forest_point(ax, r.med, r.meth, r.q1, r.q3, horizontal=False, marker='o', ms=3.4, mec=INK, mfc=INK, ls='none')
        ax.plot(g['meth'], g['med'], color=INK, lw=0.6)
        r_, p_ = spearmanr(d['meth'], d['expr'])
        per = []
        for k in (1, 2):
            col = f'{t}_{k}'
            if col in tp.columns:
                lk = (gm[f'rep{k}_prom_meth'] / gm[f'rep{k}_prom_total'])[gm[f'rep{k}_prom_total'] >= 10]
                yk = np.log2(tp[col] + 1).reindex(lk.index)
                ok = yk.notna()
                per.append(spearmanr(lk[ok], yk[ok])[0])
        ax.text(0.97, 0.97, f'ρ = {r_:.2f}\nn = {len(d):,}', transform=ax.transAxes, ha='right', va='top', fontsize=5.8)
        ax.set_title(f'{SP_NAME[sp]}, {t}', fontsize=6.5, pad=3)
        ax.set_xlabel('promoter CpG methylation\n(decile medians)')
        src.append(dict(species=sp, tissue=t, n_genes=len(d), spearman_rho_pooled=r_, p=p_,
                        rho_individual_1=per[0] if per else np.nan, rho_individual_2=per[1] if len(per) > 1 else np.nan))
    axes[0].set_ylabel('log2(TPM + 1), median and IQR')
    fig.subplots_adjust(wspace=0.1)
    save(fig, out, 'figS17_promoter_meth_vs_expression', pd.DataFrame(src))


FIGS = {'fig2': [fig2b_ks],
        'fig3': [fig3a_genomes, fig3a_chrpairs, fig3b_bias, fig3c_go, fig3d_te_density, fig3e_te_quartets],
        'supp': [fig3d_te_pairs, figS6_fractionation, figS9_heb, figS12_te_age, figS14_compartments, figS16_he,
                 figS_abs_expression, figS_robustness, figS_joint_m2, figS17_meth_expression],
        'extra': [figS9c_immune, figS12c_te_class, figS12d_te_distance, figS20_gbm_go],
        'fig4': [fig4a_occupancy, fig4c_pairs, fig4g_joint],
        'fig5': [fig5c_he_ring],
        'fig6': [fig6ab_profiles, fig6c_scatter, fig6d_share, fig6e_quartets, fig6f_categories],
        'fig7': [fig7a_dosage, fig7b_consistency, fig7c_atac, fig7d_omega, fig7e_toga]}


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    ap.add_argument('figs', nargs='+', choices=list(FIGS) + ['all'])
    a = ap.parse_args()
    todo = list(FIGS) if 'all' in a.figs else a.figs
    failed = 0
    for f in todo:
        out = f'{a.base}/figs/{f}'
        os.makedirs(out, exist_ok=True)
        print(f'[{f}] -> {out}')
        for fn in FIGS[f]:
            try:
                fn(a.base, out)
            except Exception as e:
                failed += 1
                print(f'  FAILED {fn.__name__}: {type(e).__name__}: {e}')
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
