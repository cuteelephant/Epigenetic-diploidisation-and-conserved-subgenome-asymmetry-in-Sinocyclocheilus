#!/usr/bin/env bash
set -euo pipefail

export BASE=$HOME/mbe_review
export RAW=$BASE/wgbs_data
export OUT=$BASE/wgbs
SAMPLES=(TL_eye_rep1 TL_eye_rep2 TL_liver_rep1 TL_liver_rep2
         CX_eye_rep1 CX_eye_rep2 CX_liver_rep1 CX_liver_rep2)

export CLIP="--clip_R1 10 --clip_R2 15 --three_prime_clip_R1 10 --three_prime_clip_R2 10"

gdir() { local sp=${1%%_*}; echo "$OUT/genome/${sp,,}"; }

trim_one() {
  local s=$1
  trim_galore --paired $CLIP -q 20 --length 36 --cores 4 --gzip \
    -o "$OUT/trimmed" "$RAW/${s}_1.fq.gz" "$RAW/${s}_2.fq.gz" \
    > "$OUT/trimmed/$s.log" 2>&1
}

align_one() {
  local s=$1
  mkdir -p "$OUT/tmp/$s"
  bismark --genome "$(gdir "$s")" --parallel 10 --basename "$s" \
    --temp_dir "$OUT/tmp/$s" -o "$OUT/bam" \
    -1 "$OUT/trimmed/${s}_1_val_1.fq.gz" -2 "$OUT/trimmed/${s}_2_val_2.fq.gz" \
    > "$OUT/bam/$s.log" 2>&1
}

extract_one() {
  local s=$1
  deduplicate_bismark --paired --bam --output_dir "$OUT/dedup" "$OUT/bam/${s}_pe.bam" \
    > "$OUT/dedup/$s.log" 2>&1
  bismark_methylation_extractor --paired-end --no_overlap --comprehensive --merge_non_CpG \
    --gzip --bedGraph --buffer_size 20G --parallel 8 -o "$OUT/meth" \
    "$OUT/dedup/${s}_pe.deduplicated.bam" > "$OUT/meth/$s.log" 2>&1
}

export -f gdir trim_one align_one extract_one

case ${1:-} in
check)
  for t in trim_galore bismark bismark_genome_preparation bowtie2 samtools pigz \
           deduplicate_bismark bismark_methylation_extractor parallel; do
    printf '%-32s %s\n' "$t" "$(command -v "$t" || echo MISSING)"
  done
  for t in bismark trim_galore bowtie2 samtools; do
    printf '%-32s %s\n' "$t version" "$($t --version 2>&1 | grep -m1 -Eo 'v?[0-9]+\.[0-9]+(\.[0-9]+)?' || echo '?')"
  done
  for s in "${SAMPLES[@]}"; do ls -lh "$RAW/${s}"_[12].fq.gz || true; done
  df -h "$BASE"
  ;;

prep)
  for sp in tl cx; do
    mkdir -p "$OUT/genome/$sp"
    ln -sf "$BASE/${sp}_AB.fa" "$OUT/genome/$sp/${sp}_AB.fa"
  done
  parallel -j 2 'bismark_genome_preparation --parallel 8 {} > {}/prep.log 2>&1' \
    ::: "$OUT/genome/tl" "$OUT/genome/cx"
  ;;

trim)
  mkdir -p "$OUT/trimmed"
  parallel -j 4 trim_one ::: "${SAMPLES[@]}"
  echo "R1 outputs: $(ls "$OUT"/trimmed/*_1_val_1.fq.gz 2>/dev/null | wc -l) / 8"
  echo "R2 outputs: $(ls "$OUT"/trimmed/*_2_val_2.fq.gz 2>/dev/null | wc -l) / 8"
  ;;

align)
  mkdir -p "$OUT/bam" "$OUT/tmp"
  parallel -j 2 align_one ::: "${SAMPLES[@]}"
  ;;

extract)
  mkdir -p "$OUT/dedup" "$OUT/meth"
  parallel -j 2 extract_one ::: "${SAMPLES[@]}"
  ;;

qc)
  {
    printf 'sample\tpairs\tmap_eff\tnot_unique_pct\tCpG_meth\tCHG_meth\tCHH_meth\tdup_removed\tCpG_ge5x\tmean_CpG_depth\n'
    for s in "${SAMPLES[@]}"; do
      r=$OUT/bam/${s}_PE_report.txt
      d=$(ls "$OUT"/dedup/"${s}"_pe*deduplication_report.txt)
      cov=$OUT/meth/${s}_pe.deduplicated.bismark.cov.gz
      tot=$(awk -F'\t' '/^Sequence pairs analysed in total/{print $2}' "$r")
      amb=$(awk -F'\t' '/^Sequence pairs did not map uniquely/{print $2}' "$r")
      eff=$(awk -F'\t' '/^Mapping efficiency/{gsub(/ /,"",$2); print $2}' "$r")
      cg=$(awk -F'\t' '/^C methylated in CpG context/{print $2}' "$r")
      chg=$(awk -F'\t' '/^C methylated in CHG context/{print $2}' "$r")
      chh=$(awk -F'\t' '/^C methylated in CHH context/{print $2}' "$r")
      dup=$(grep -m1 'Total number duplicated alignments removed' "$d" | grep -o '[0-9.]*%')
      ambp=$(awk -v a="$amb" -v t="$tot" 'BEGIN{printf "%.2f%%", a/t*100}')
      read -r n5 dep < <(zcat "$cov" | awk '{c=$5+$6; s+=c; if(c>=5) n++} END{printf "%d %.1f\n", n, s/NR}')
      printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$s" "$tot" "$eff" "$ambp" "$cg" "$chg" "$chh" "$dup" "$n5" "$dep"
    done
  } | tee "$OUT/wgbs_qc.tsv"

  echo
  for s in "${SAMPLES[@]}"; do
    f=$OUT/meth/${s}_pe.deduplicated.M-bias.txt
    for R in R1 R2; do
      awk -F'\t' -v R="$R" -v s="$s" '
        $0 ~ "^CpG context \\(" R "\\)" {on=1; next}
        on && /^[0-9]/ {p[++n]=$4}
        on && /^$/ && n {exit}
        END{
          printf "%s\t%s\tfirst5:", s, R; for(i=1;i<=5;i++) printf " %.1f", p[i]
          printf "\tmid: %.1f\tlast5:", p[int(n/2)]; for(i=n-4;i<=n;i++) printf " %.1f", p[i]
          print ""
        }' "$f"
    done
  done | tee "$OUT/wgbs_mbias.tsv"

  echo
  {
    printf 'species_tissue\tn_CpG_ge10x_both\tpearson_r\n'
    for st in TL_eye TL_liver CX_eye CX_liver; do
      a=$OUT/meth/${st}_rep1_pe.deduplicated.bismark.cov.gz
      b=$OUT/meth/${st}_rep2_pe.deduplicated.bismark.cov.gz
      awk -F'\t' -v st="$st" '
        NR==FNR { if ($5+$6>=10) m[$1":"$2]=$4; next }
        ($5+$6>=10) && (($1":"$2) in m) {
          x=m[$1":"$2]; y=$4; n++; sx+=x; sy+=y; sxx+=x*x; syy+=y*y; sxy+=x*y }
        END {
          d=(n*sxx-sx*sx)*(n*syy-sy*sy)
          printf "%s\t%d\t%s\n", st, n, (n>2 && d>0) ? sprintf("%.3f",(n*sxy-sx*sy)/sqrt(d)) : "NA" }
      ' <(zcat "$a") <(zcat "$b")
    done
  } | tee "$OUT/wgbs_repcor.tsv"
  ;;

*)
  echo "Usage: bash $0 {check|prep|trim|align|extract|qc}"; exit 1 ;;
esac
