#!/usr/bin/env bash
set -euo pipefail

export BASE=$HOME/mbe_review
export RNA=$BASE/rna_data
export OUT=$BASE/rna
TOOLS=$(dirname "$(readlink -f "$0")")/rna_tools.py
SHEET=$OUT/samples.tsv
STRAND=${STRAND:-0}
export HTHREADS=${HTHREADS:-16}
JOBS=${JOBS:-4}
SPECIES=(tl cx)

align_one() {
  set -o pipefail
  local sp=$1 id=$2 r1=$3 r2=$4 pre=$OUT/bam/${1}_${2}
  [ -s "$pre.bam.bai" ] && return 0
  hisat2 -p "$HTHREADS" --new-summary --summary-file "$pre.summary.txt" --no-unal \
    -x "$OUT/index/$sp/${sp}_AB" -1 "$r1" -2 "$r2" 2> "$pre.log" \
    | samtools sort -@ 4 -m 2G -T "$OUT/tmp/${sp}_${id}" -o "$pre.bam" - 2>> "$pre.log"
  samtools index "$pre.bam"
}
export -f align_one

pe_flags() {
  local h; h=$(featureCounts 2>&1 || true)
  if [[ $h == *countReadPairs* ]]; then echo "-p --countReadPairs -B -C"; else echo "-p -B -C"; fi
}

bams_of() { awk -F'\t' -v sp="$1" -v o="$OUT/bam" 'NR>1 && $1==sp {print o"/"sp"_"$2".bam"}' "$SHEET"; }
bams_count() { bams_of "$1" | awk -v ex="$OUT/exclude.txt" 'BEGIN{while ((getline l < ex) > 0) x[l".bam"] = 1}
                {n = split($0, p, "/"); if (!(p[n] in x)) print}'; }

case ${1:-} in
check)
  for t in hisat2 hisat2-build samtools featureCounts parallel python3; do
    printf '%-14s %s\n' "$t" "$(command -v "$t" || echo MISSING)"
  done
  printf '%-14s %s\n' "hisat2" "$(hisat2 --version 2>&1 | head -1)"
  printf '%-14s %s\n' "featureCounts" "$(featureCounts -v 2>&1 | grep -m1 -i 'featureCounts')"
  printf '%-14s %s\n' "samtools" "$(samtools --version | head -1)"
  mkdir -p "$OUT"
  {
    printf 'species\tsample\ttissue\tR1\tR2\n'
    for d in "$RNA"/*_RNA; do
      tissue=$(basename "$d" _RNA)
      for sp in "${SPECIES[@]}"; do
        for r1 in "$d"/${sp}_*_clean_1.fq.gz; do
          [ -e "$r1" ] || continue
          tok=$(basename "$r1" _clean_1.fq.gz); tok=${tok#${sp}_}
          id=${tissue}_$tok; [ "$tok" = "$tissue" ] && id=${tissue}_1
          r2=${r1%_1.fq.gz}_2.fq.gz
          [ -e "$r2" ] || { echo "missing R2 for $r1" >&2; continue; }
          printf '%s\t%s\t%s\t%s\t%s\n' "$sp" "$id" "$tissue" "$r1" "$r2"
        done
      done
    done
  } > "$SHEET"
  echo; echo "Sample sheet: $SHEET"
  awk -F'\t' 'NR>1{n[$1]++; t[$1]=t[$1]" "$2} END{for(s in n) printf "%s (%d):%s\n", s, n[s], t[s]}' "$SHEET"
  df -h "$BASE" | tail -1
  ;;

index)
  for sp in "${SPECIES[@]}"; do mkdir -p "$OUT/index/$sp"; done
  parallel -j 2 'hisat2-build -p 16 '"$BASE"'/{}_AB.fa '"$OUT"'/index/{}/{}_AB > '"$OUT"'/index/{}/build.log 2>&1' ::: "${SPECIES[@]}"
  ls -lh "$OUT"/index/*/*.ht2* | wc -l
  ;;

align)
  mkdir -p "$OUT/bam" "$OUT/tmp"
  tail -n +2 "$SHEET" | parallel -j "$JOBS" --colsep '\t' align_one {1} {2} {4} {5} \
    || echo "some samples failed; see $OUT/bam/*.log"
  echo "BAMs: $(ls "$OUT"/bam/*.bam | wc -l) / $(($(wc -l < "$SHEET") - 1))"
  ;;

strand)
  mkdir -p "$OUT/annot" "$OUT/strand"
  [ -s "$OUT/annot/tl.saf" ] || python3 "$TOOLS" saf --gff "$BASE/tl_AB.gff" --out "$OUT/annot/tl.saf"
  b=$OUT/bam/tl_liver_1.bam
  for s in 0 1 2; do
    featureCounts -T 8 $(pe_flags) -Q 10 -s $s -F SAF -a "$OUT/annot/tl.saf" -o "$OUT/strand/s$s.txt" "$b" > /dev/null 2>&1
    awk -v s=$s 'NR==1{next} {t+=$2} $1=="Assigned"{a=$2} END{printf "-s %d  Assigned %.1f%%\n", s, 100*a/t}' "$OUT/strand/s$s.txt.summary"
  done
  echo "unstranded: -s1 ~ -s2 ~ half of -s0 | forward: -s1 ~ -s0 | reverse: -s2 ~ -s0"
  ;;

count)
  mkdir -p "$OUT/annot" "$OUT/counts"
  for sp in "${SPECIES[@]}"; do
    [ -s "$OUT/annot/$sp.saf" ] || python3 "$TOOLS" saf --gff "$BASE/${sp}_AB.gff" --out "$OUT/annot/$sp.saf"
    mapfile -t B < <(bams_count "$sp")
    [ -s "$OUT/exclude.txt" ] && echo "[$sp] excluded: $(grep "^${sp}_" "$OUT/exclude.txt" | tr '\n' ' ')"
    featureCounts -T 32 $(pe_flags) -Q 10 -s "$STRAND" -F SAF -a "$OUT/annot/$sp.saf" \
      -o "$OUT/counts/$sp.featureCounts.txt" "${B[@]}" > "$OUT/counts/$sp.featureCounts.log" 2>&1
    python3 "$TOOLS" tpm --sp "$sp" --fc "$OUT/counts/$sp.featureCounts.txt" --samples "$SHEET" \
      --out-prefix "$OUT/counts/$sp" | tee "$OUT/counts/$sp.tpm_report.txt"
    echo
  done
  ;;

qc)
  {
    printf 'sample\tpairs\tconc_unique\tconc_multi\toverall_aln\tfc_assigned\tfc_multimapping\n'
    for sp in "${SPECIES[@]}"; do
      s=$OUT/counts/$sp.featureCounts.txt.summary
      while read -r b; do
        id=$(basename "$b" .bam); f=$OUT/bam/$id.summary.txt
        pairs=$(grep -m1 'Total pairs' "$f" | grep -o '[0-9]*' | head -1 || true)
        u=$(grep -m1 'Aligned concordantly 1 time' "$f" | grep -o '[0-9.]*%' || true)
        m=$(grep -m1 'Aligned concordantly >1 times' "$f" | grep -o '[0-9.]*%' || true)
        o=$(grep -m1 'Overall alignment rate' "$f" | grep -o '[0-9.]*%' || true)
        fc=$(awk -F'\t' -v b="$b" 'NR==1{for(i=2;i<=NF;i++) if($i==b) c=i; next}
              {t+=$c} $1=="Assigned"{a=$c} $1=="Unassigned_MultiMapping"{mm=$c}
              END{printf "%.1f%%\t%.1f%%", 100*a/t, 100*mm/t}' "$s")
        printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$id" "$pairs" "$u" "$m" "$o" "$fc"
      done < <(bams_of "$sp")
    done
  } | tee "$OUT/rna_qc.tsv"
  ;;

*)
  echo "Usage: bash $0 {check|index|align|strand|count|qc}"; exit 1 ;;
esac
