#!/usr/bin/env python3
import argparse, os, sys
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact, ks_2samp, mannwhitneyu, norm, wilcoxon

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

T_FC, MIN_READS, N_BOOT, MAX_D = 1.0, 10, 2000, 2000
CLASSES = ('DNA', 'LTR', 'LINE', 'SINE', 'Unknown')
IMMUNE = 'GO:0002376'
GENOME = {'tl': 'tianlinensis', 'cx': 'longibarbatus'}


def boot_mean(x, seed):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) < 2:
        return (float(x.mean()) if len(x) else np.nan), np.nan, np.nan
    rng = np.random.default_rng(seed)
    b = np.empty(N_BOOT)
    for k in range(0, N_BOOT, 250):
        m = min(250, N_BOOT - k)
        b[k:k + m] = x[rng.integers(0, len(x), (m, len(x)))].mean(axis=1)
    return float(x.mean()), float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))


def wil(d):
    d = np.asarray(d, float)
    return wilcoxon(d).pvalue if len(d) > 1 and (d != 0).any() else np.nan


def mwu(x, y):
    return mannwhitneyu(x, y).pvalue if len(x) and len(y) else np.nan


def biased_pairs(B):
    p = pd.read_csv(f'{B}/analysis/methexpr_pairs.tsv.gz', sep='\t', dtype={'individual': str, 'HE': str})
    p = p[(p['individual'] == 'pooled') & (p['log2FC'].abs() >= T_FC)]
    out = {}
    for (sp, tissue), d in p.groupby(['species', 'tissue']):
        lo = np.where(d['log2FC'] > 0, d['A_gene'], d['B_gene'])
        hi = np.where(d['log2FC'] > 0, d['B_gene'], d['A_gene'])
        out[(sp, tissue)] = (lo, hi)
    return out


def te_class(top):
    t = top.fillna('Unknown').astype(str)
    t = t.where(~t.str.lower().isin(['unknown', 'unspecified', 'unclassified']), 'Unknown')
    return t.where(t.isin(CLASSES), 'other')


def cmd_teclass(B):
    P = biased_pairs(B)
    rows = []
    for sp in ('tl', 'cx'):
        ft = pd.read_csv(f'{B}/te_polar/{sp}.flank_te.tsv.gz', sep='\t')
        ft['klass'] = te_class(ft['top'] if 'top' in ft.columns else ft['cls'].str.split('/').str[0])
        ft = ft.dropna(subset=['K'])
        for tissue in ('eye', 'liver'):
            if (sp, tissue) not in P:
                continue
            lo, hi = P[(sp, tissue)]
            for klass in CLASSES + ('other', 'all'):
                f = ft if klass == 'all' else ft[ft['klass'] == klass]
                for side in ('up', 'down', 'both'):
                    g = f if side == 'both' else f[f['side'] == side]
                    med = g.groupby('gene')['K'].median()
                    x, y = med.reindex(lo).values, med.reindex(hi).values
                    k = np.isfinite(x) & np.isfinite(y)
                    dd = (x[k] - y[k]) * 100
                    est, l95, h95 = boot_mean(dd, seed=len(rows) + 1)
                    kl = g.loc[g['gene'].isin(set(lo)), 'K'].values
                    kh = g.loc[g['gene'].isin(set(hi)), 'K'].values
                    rows.append(dict(species=sp, tissue=tissue, te_class=klass, side=side, n_pairs=int(k.sum()),
                                     mean_dK_x100=est, lo95=l95, hi95=h95,
                                     frac_lower_younger=float((dd < 0).mean()) if len(dd) else np.nan,
                                     p_paired_wilcoxon=wil(dd), n_TE_lower=len(kl), n_TE_higher=len(kh),
                                     K_median_lower=np.median(kl) if len(kl) else np.nan,
                                     K_median_higher=np.median(kh) if len(kh) else np.nan,
                                     dK_median_TE=(np.median(kl) - np.median(kh)) if len(kl) and len(kh) else np.nan,
                                     p_mannwhitney_TE=mwu(kl, kh)))
    t = pd.DataFrame(rows)
    t.to_csv(f'{B}/analysis/extra_teclass.tsv', sep='\t', index=False)
    show = t[t['side'] == 'both'][['species', 'tissue', 'te_class', 'n_pairs', 'mean_dK_x100', 'lo95', 'hi95',
                                   'p_paired_wilcoxon', 'dK_median_TE', 'p_mannwhitney_TE']]
    print('TE age by class, lower - higher copy (both flanks; K x 100 for the pair-level estimate)')
    print(show.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
    print(f'-> {B}/analysis/extra_teclass.tsv')


def cmd_tedist(B):
    P = biased_pairs(B)
    rows, dens = [], []
    edges = np.arange(0, MAX_D + 50, 50)
    for sp in ('tl', 'cx'):
        ft = pd.read_csv(f'{B}/te_polar/{sp}.flank_te.tsv.gz', sep='\t')
        g = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.genes.tsv', sep='\t', dtype={'chr': str}).set_index('gene')
        mid = (ft['s0'].values + 1 + ft['e'].values) / 2
        s, e = g['start'].reindex(ft['gene']).values, g['end'].reindex(ft['gene']).values
        d = np.where(mid < s, s - mid, np.where(mid > e, mid - e, np.nan))
        ft = ft.assign(dist=d)
        ft = ft[(ft['dist'] >= 0) & (ft['dist'] <= MAX_D)]
        for tissue in ('eye', 'liver'):
            if (sp, tissue) not in P:
                continue
            lo, hi = P[(sp, tissue)]
            for side in ('up', 'down', 'both'):
                f = ft if side == 'both' else ft[ft['side'] == side]
                med = f.groupby('gene')['dist'].median()
                x, y = med.reindex(lo).values, med.reindex(hi).values
                k = np.isfinite(x) & np.isfinite(y)
                dd = x[k] - y[k]
                est, l95, h95 = boot_mean(dd, seed=100 + len(rows))
                dl = f.loc[f['gene'].isin(set(lo)), 'dist'].values
                dh = f.loc[f['gene'].isin(set(hi)), 'dist'].values
                ks = ks_2samp(dl, dh) if len(dl) and len(dh) else None
                rows.append(dict(species=sp, tissue=tissue, side=side, n_pairs=int(k.sum()), mean_diff_bp=est,
                                 lo95=l95, hi95=h95, p_paired_wilcoxon=wil(dd), n_TE_lower=len(dl), n_TE_higher=len(dh),
                                 median_dist_lower=np.median(dl) if len(dl) else np.nan,
                                 median_dist_higher=np.median(dh) if len(dh) else np.nan,
                                 ks_D=ks.statistic if ks else np.nan, p_ks=ks.pvalue if ks else np.nan,
                                 p_mannwhitney_TE=mwu(dl, dh)))
                if side != 'both':
                    for copy, v in (('lower', dl), ('higher', dh)):
                        h, _ = np.histogram(v, edges)
                        dens.append(pd.DataFrame(dict(species=sp, tissue=tissue, side=side, copy=copy,
                                                      bin_start=edges[:-1], bin_end=edges[1:], n=h,
                                                      density=h / max(h.sum(), 1) / 50)))
    t = pd.DataFrame(rows)
    t.to_csv(f'{B}/analysis/extra_tedist.tsv', sep='\t', index=False)
    pd.concat(dens).to_csv(f'{B}/analysis/extra_tedist_density.tsv', sep='\t', index=False)
    print('Distance of flanking TE midpoints to the gene boundary, lower vs higher copy')
    print(t.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
    print(f'-> {B}/analysis/extra_tedist.tsv, extra_tedist_density.tsv')


def woolf(a, b, c, d):
    if min(a, b, c, d) == 0:
        a, b, c, d = a + .5, b + .5, c + .5, d + .5
    o = a * d / (b * c)
    se = np.sqrt(1 / a + 1 / b + 1 / c + 1 / d)
    z = norm.ppf(0.975)
    return o, o * np.exp(-z * se), o * np.exp(z * se)


def pair_zf(B, sp, toga):
    from go_enrich import zf_map
    genes = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.genes.tsv', sep='\t', dtype={'chr': str})
    zf = zf_map(toga, GENOME[sp], genes)
    m = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
    m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)].copy()
    m['zf'] = [zf.get(x) or zf.get(y) for x, y in zip(m['A_gene'], m['B_gene'])]
    return m[m['zf'].notna()].reset_index(drop=True)


def cmd_immune(B, toga):
    from go_enrich import load_go
    ann, names, _ = load_go(f'{B}/go')
    imm = {z for z, ts in ann.items() if IMMUNE in ts}
    print(f'zebrafish genes annotated to {IMMUNE} ({names.get(IMMUNE)}) or a descendant: {len(imm)}')
    rows = []
    for sp in ('tl', 'cx'):
        m = pair_zf(B, sp, toga)
        m['immune'] = m['zf'].isin(imm)
        tp = pd.read_csv(f'{B}/rna/counts/{sp}.tpm.tsv', sep='\t').set_index('gene')
        samples = [c for c in tp.columns if c != 'length']
        for tissue in sorted({c.rsplit('_', 1)[0] for c in samples}):
            reps = [c for c in samples if c.rsplit('_', 1)[0] == tissue]
            A = tp.reindex(m['A_gene'])[reps].mean(axis=1).values
            Bv = tp.reindex(m['B_gene'])[reps].mean(axis=1).values
            ok = np.isfinite(A) & np.isfinite(Bv) & (np.maximum(A, Bv) >= 1)
            l = np.abs(np.log2((Bv[ok] + 1) / (A[ok] + 1)))
            im = m['immune'].values[ok]
            bal = l < T_FC
            a, b = int((bal & im).sum()), int((~bal & im).sum())
            c, d = int((bal & ~im).sum()), int((~bal & ~im).sum())
            o, lo, hi = woolf(a, b, c, d)
            rows.append(dict(species=sp, tissue=tissue, individuals=len(reps), n_immune=a + b, n_other=c + d,
                             frac_balanced_immune=a / max(a + b, 1), frac_balanced_other=c / max(c + d, 1),
                             OR_balanced=o, lo95=lo, hi95=hi, p_fisher=fisher_exact([[a, b], [c, d]])[1],
                             median_abs_log2FC_immune=np.median(l[im]) if im.any() else np.nan,
                             median_abs_log2FC_other=np.median(l[~im]) if (~im).any() else np.nan,
                             p_mannwhitney=mwu(l[im], l[~im])))
    t = pd.DataFrame(rows)
    t.to_csv(f'{B}/analysis/extra_immune.tsv', sep='\t', index=False)
    print(t.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
    print(f'-> {B}/analysis/extra_immune.tsv')


def cmd_gbm(B, toga):
    from go_enrich import load_go, enrich
    ann, names, _ = load_go(f'{B}/go')
    terms = sorted({t for v in ann.values() for t in v})
    rows = []
    for sp in ('tl', 'cx'):
        m = pair_zf(B, sp, toga)
        for tissue in ('eye', 'liver'):
            gm = pd.read_csv(f'{B}/meth/{sp}_{tissue}.gene_meth.tsv', sep='\t').set_index('gene')
            v = {}
            for s in 'AB':
                g = gm.reindex(m[f'{s}_gene'])
                for r in ('rep1', 'rep2'):
                    v[(s, r, 'm')] = g[f'{r}_body_meth'].values.astype(float)
                    v[(s, r, 't')] = g[f'{r}_body_total'].values.astype(float)
            ok = np.ones(len(m), bool)
            for s in 'AB':
                for r in ('rep1', 'rep2'):
                    ok &= np.nan_to_num(v[(s, r, 't')]) >= MIN_READS
            lev = {(s, r): v[(s, r, 'm')] / np.maximum(v[(s, r, 't')], 1) for s in 'AB' for r in ('rep1', 'rep2')}
            pool = {s: (v[(s, 'rep1', 'm')] + v[(s, 'rep2', 'm')]) / np.maximum(v[(s, 'rep1', 't')] + v[(s, 'rep2', 't')], 1)
                    for s in 'AB'}
            dm = pool['B'] - pool['A']
            d1, d2 = lev[('B', 'rep1')] - lev[('A', 'rep1')], lev[('B', 'rep2')] - lev[('A', 'rep2')]
            z = m['zf'].values[ok]
            univ = set(z)
            for thr in (0.3, 0.2):
                for direction, sel in (('SubB-hypermethylated', (dm >= thr) & (d1 > 0) & (d2 > 0)),
                                       ('SubA-hypermethylated', (dm <= -thr) & (d1 < 0) & (d2 < 0))):
                    sel = sel[ok]
                    e = enrich(set(z[sel]), univ, ann, terms)
                    e.insert(0, 'threshold', thr); e.insert(0, 'direction', direction)
                    e.insert(0, 'tissue', tissue); e.insert(0, 'species', sp)
                    e['n_selected'], e['n_universe'] = int(sel.sum()), len(univ)
                    rows.append(e)
                    print(f'[{sp} {tissue}] |dMeth_body| >= {thr}: {direction} {int(sel.sum())} of {len(univ)} pairs',
                          flush=True)
    t = pd.concat(rows, ignore_index=True)
    t['name'] = t['term'].map(names)
    t.to_csv(f'{B}/analysis/extra_gbm_go.tsv', sep='\t', index=False)
    top = (t[(t['fdr'] < 0.05) & (t['fold'] >= 1.5)].sort_values('fdr')
           .groupby(['species', 'tissue', 'direction', 'threshold']).head(10))
    top.to_csv(f'{B}/analysis/extra_gbm_go_top.tsv', sep='\t', index=False)
    s = (t[(t['fdr'] < 0.05) & (t['fold'] >= 1.5)].groupby(['threshold', 'species', 'tissue', 'direction']).size())
    print('\nGO BP terms with FDR < 0.05 and fold >= 1.5\n' + (s.to_string() if len(s) else 'none'))
    with pd.option_context('display.width', 200, 'display.max_colwidth', 60):
        print(top[top['threshold'] == 0.3][['species', 'tissue', 'direction', 'k', 'fold', 'fdr', 'name']]
              .to_string(index=False) if len(top) else '')
    print(f'-> {B}/analysis/extra_gbm_go.tsv, extra_gbm_go_top.tsv')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('cmd', nargs='+', choices=['teclass', 'tedist', 'immune', 'gbm', 'all'])
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    ap.add_argument('--toga', default=os.environ.get('TOGA2_DIR', '/ifs1/User/zhoushipeng/sino_cavefish_evolution/pseudogenes/toga2'))
    a = ap.parse_args()
    todo = ['teclass', 'tedist', 'immune', 'gbm'] if 'all' in a.cmd else a.cmd
    for c in todo:
        print(f'\n===== {c}', flush=True)
        if c == 'teclass':
            cmd_teclass(a.base)
        elif c == 'tedist':
            cmd_tedist(a.base)
        elif c == 'immune':
            cmd_immune(a.base, a.toga)
        else:
            cmd_gbm(a.base, a.toga)


if __name__ == '__main__':
    main()
