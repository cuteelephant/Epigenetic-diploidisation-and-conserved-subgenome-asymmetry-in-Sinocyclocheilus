#!/usr/bin/env bash
set -euo pipefail
BASE=$HOME/mbe_review
RAWDIR=$BASE/ATAC
OUT=$BASE/atac
TOOLS=$(dirname "$(readlink -f "$0")")
THREADS=${THREADS:-24}
SHEET=$OUT/samples.tsv
MAP="tl	liver_1	TLAgan8
tl	liver_2	TLAgan9
cx	liver_1	CXA4
cx	liver_2	CXB4"
NEXTERA=CTGTCTCTTATACACATCT
macs_bin() { command -v macs3 || command -v macs2; }

case ${1:-} in
check)
  for t in fastp bowtie2 bowtie2-build samtools python3; do printf '%-14s %s\n' "$t" "$(command -v "$t" || echo MISSING)"; done
  printf '%-14s %s\n' macs "$(macs_bin || echo 'MISSING (pip install macs3)')"
  mkdir -p "$OUT"
  { printf 'species\tsample\traw\tR1\tR2\n'
    while IFS=$'\t' read -r sp id raw; do
      r1=$(find "$RAWDIR" -name "${raw}_R1.fq.gz" | head -1); r2=${r1%_R1.fq.gz}_R2.fq.gz
      [ -s "$r1" ] && [ -s "$r2" ] || { echo "missing reads for $raw" >&2; continue; }
      printf '%s\t%s\t%s\t%s\t%s\n' "$sp" "$id" "$raw" "$r1" "$r2"
    done <<< "$MAP"; } > "$SHEET"
  column -t "$SHEET"
  for sp in tl cx; do
    fai=$BASE/${sp}_AB.fa.fai
    [ -s "$fai" ] || samtools faidx "$BASE/${sp}_AB.fa"
    awk -v sp="$sp" '{L += $2} $1 ~ /^(chr)?(M|MT|mito)/ || tolower($1) ~ /mito/ {m = m" "$1}
      END {printf "[%s] %d sequences, %.1f Mb; mitochondrial sequence: %s\n", sp, NR, L / 1e6, (m ? m : "none")}' "$fai"
  done
  ;;
md5)
  find "$RAWDIR" -name md5.txt | while read -r f; do echo "== $(dirname "$f")"; (cd "$(dirname "$f")" && md5sum -c md5.txt 2>&1 | grep -v ': OK$' || echo "all OK"); done
  ;;
mito)
  mkdir -p "$OUT/ref"
  declare -A NAME=([tl]="Sinocyclocheilus tianlinensis" [cx]="Sinocyclocheilus longibarbatus")
  E=https://eutils.ncbi.nlm.nih.gov/entrez/eutils
  for sp in tl cx; do
    mt=$OUT/ref/${sp}_mt.fa
    if [ ! -s "$mt" ]; then
      for org in "${NAME[$sp]}" Sinocyclocheilus; do
        term=$(printf '%s[Organism] AND mitochondrion[filter] AND complete genome[Title]' "$org" | sed 's/ /+/g; s/\[/%5B/g; s/\]/%5D/g')
        id=$(curl -s "$E/esearch.fcgi?db=nuccore&retmode=json&retmax=5&term=$term" | python3 -c 'import sys, json; print(" ".join(json.load(sys.stdin)["esearchresult"]["idlist"]))' || true)
        [ -n "$id" ] && break
        echo "[$sp] no complete mitogenome for $org in NCBI"
      done
      [ -n "$id" ] || { echo "[$sp] put a mitogenome FASTA at $mt and rerun"; continue; }
      curl -s "$E/efetch.fcgi?db=nuccore&rettype=fasta&retmode=text&id=${id%% *}" > "$mt.raw"
      echo "[$sp] NCBI hits: $id; using $(head -1 "$mt.raw")"
      awk 'NR == 1 {print ">chrM"; next} {print}' "$mt.raw" > "$mt"; rm -f "$mt.raw"
    fi
    printf '[%s] chrM %d bp\n' "$sp" "$(grep -v '>' "$mt" | tr -d '\n' | wc -c)"
    cat "$BASE/${sp}_AB.fa" "$mt" > "$OUT/ref/${sp}_AB_mt.fa"
  done
  ;;
index)
  for sp in tl cx; do
    mkdir -p "$OUT/index/$sp"
    [ -s "$OUT/ref/${sp}_AB_mt.fa" ] || { echo "[$sp] run the mito stage first"; exit 1; }
    [ -s "$OUT/index/$sp/${sp}_AB.1.bt2" ] || [ -s "$OUT/index/$sp/${sp}_AB.1.bt2l" ] || \
      bowtie2-build --threads "$THREADS" "$OUT/ref/${sp}_AB_mt.fa" "$OUT/index/$sp/${sp}_AB" > "$OUT/index/$sp/build.log" 2>&1 &
  done
  wait; ls "$OUT"/index/*/ | head -20
  ;;
trim)
  mkdir -p "$OUT/clean"
  while IFS=$'\t' read -r sp id raw r1 r2; do
    o=$OUT/clean/${sp}_${id}
    [ -s "${o}_2.fq.gz" ] && { echo "[$sp $id] trimmed, skipped"; continue; }
    ( fastp -i "$r1" -I "$r2" -o "${o}_1.fq.gz" -O "${o}_2.fq.gz" --adapter_sequence "$NEXTERA" \
        --adapter_sequence_r2 "$NEXTERA" -l 25 -w 16 -j "$o.fastp.json" -h "$o.fastp.html" 2> "$o.fastp.log"
      echo "[$sp $id] $(grep -m1 'reads passed filter' "$o.fastp.log")" ) &
  done < <(tail -n +2 "$SHEET")
  wait
  ;;
align)
  mkdir -p "$OUT/bam" "$OUT/frag"
  align_one() {
    local sp=$1 id=$2 p=$OUT/bam/${1}_${2} c=$OUT/clean/${1}_${2}
    [ -s "$p.final.bam.bai" ] && { echo "[$sp $id] aligned, skipped"; return 0; }
    bowtie2 --very-sensitive -X 2000 --no-mixed --no-discordant -p "$THREADS" -x "$OUT/index/$sp/${sp}_AB" \
        -1 "${c}_1.fq.gz" -2 "${c}_2.fq.gz" 2> "$p.bowtie2.log" \
      | samtools fixmate -m -@ 4 - - | samtools sort -@ 8 -m 2G -T "$p.tmp" - \
      | samtools markdup -r -s -@ 4 - "$p.dedup.bam" 2> "$p.markdup.txt"
    samtools index "$p.dedup.bam"
    samtools idxstats "$p.dedup.bam" > "$p.idxstats.txt"
    samtools view -@ 8 -b -q 30 -f 2 -F 1804 "$p.dedup.bam" $(cut -f1 "$BASE/${sp}_AB.fa.fai") > "$p.final.bam"
    samtools index "$p.final.bam"
    samtools view -@ 4 -f 2 "$p.final.bam" \
      | awk -v OFS='\t' '$9 > 0 {s = $4 - 1 + 4; e = $4 - 1 + $9 - 5; if (e > s) print $3, s, e}' \
      | gzip > "$OUT/frag/${sp}_${id}.frag.bed.gz"
    rm -f "$p.dedup.bam" "$p.dedup.bam.bai"
    echo "[$sp $id] $(grep 'overall alignment rate' "$p.bowtie2.log"); fragments $(zcat "$OUT/frag/${sp}_${id}.frag.bed.gz" | wc -l)"
  }
  while IFS=$'\t' read -r sp id raw r1 r2; do align_one "$sp" "$id" & done < <(tail -n +2 "$SHEET")
  wait
  ;;
peaks)
  M=$(macs_bin); mkdir -p "$OUT/peaks"
  for sp in tl cx; do
    g=$(awk '{L += $2} END {printf "%d", 0.85 * L}' "$BASE/${sp}_AB.fa.fai")
    for id in liver_1 liver_2; do
      "$M" callpeak -t "$OUT/bam/${sp}_${id}.final.bam" -f BAMPE -g "$g" -n "${sp}_${id}" --keep-dup all -q 0.01 \
        --outdir "$OUT/peaks" > "$OUT/peaks/${sp}_${id}.macs.log" 2>&1 &
    done
    "$M" callpeak -t "$OUT/bam/${sp}_liver_1.final.bam" "$OUT/bam/${sp}_liver_2.final.bam" -f BAMPE -g "$g" \
      -n "${sp}_liver_pooled" --keep-dup all -q 0.01 --outdir "$OUT/peaks" > "$OUT/peaks/${sp}_liver_pooled.macs.log" 2>&1 &
  done
  wait
  for f in "$OUT"/peaks/*_peaks.narrowPeak; do printf '%s %d\n' "$(basename "$f" _peaks.narrowPeak)" "$(wc -l < "$f")"; done
  ;;
qc)
  python3 "$TOOLS/atac_tools.py" --base "$BASE" qc | tee "$OUT/atac_qc.log"
  ;;
*)
  echo "Usage: bash $0 {check|md5|mito|index|trim|align|peaks|qc}"; exit 1 ;;
esac
