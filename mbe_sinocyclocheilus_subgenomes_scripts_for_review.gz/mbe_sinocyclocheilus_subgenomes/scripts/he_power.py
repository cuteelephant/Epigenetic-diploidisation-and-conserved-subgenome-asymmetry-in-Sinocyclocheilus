#!/usr/bin/env python3
import argparse, os
from collections import defaultdict
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact, mannwhitneyu

N_SIM, LENS, SEED, STRICT = 1000, (5, 10, 20), 1, 1.38
ID_HI, KS_LO, TE_FLANK, TE_MIN_BP = 0.95, 0.05, 1, 1000


def params(path):
    d = pd.read_csv(path, sep='\t', dtype=str)
    return dict(zip(d['parameter'], d['value']))


def load_cov(path):
    d = pd.read_csv(path, sep='\t', header=None, usecols=[0, 1, 3], names=['chr', 's', 'dep'])
    return {c: (g['s'].values, g['dep'].values.astype(float)) for c, g in d.groupby('chr', sort=False)}


def partner_windows(blocks_path, win):
    best, pw = {}, {}
    with open(blocks_path) as f:
        for ln in f:
            p = ln.split()
            if len(p) < 6:
                continue
            ac, As, Ae, bc, Bs, Be = p[0], int(p[1]), int(p[2]), p[3], int(p[4]), int(p[5])
            st = p[6] if len(p) > 6 else '+'
            if Ae <= As:
                continue
            for wi in range(As // win, (Ae - 1) // win + 1):
                ws, we = wi * win, (wi + 1) * win
                ov = min(Ae, we) - max(As, ws)
                if ov <= 0:
                    continue
                if ov > best.get((ac, wi), 0):
                    m = (max(As, ws) + min(Ae, we)) / 2
                    fr = (m - As) / (Ae - As)
                    bpos = Bs + fr * (Be - Bs) if st == '+' else Be - fr * (Be - Bs)
                    best[(ac, wi)] = ov
                    pw[(ac, wi)] = (bc, int(bpos) // win)
    return pw


def partners(pw, covA, covB, win):
    bidx = {}
    for c, (s, dep) in covB.items():
        for x, y in zip(s // win, dep):
            bidx[(c, int(x))] = y
    out = {}
    for c, (s, _) in covA.items():
        v = [bidx.get(pw.get((c, int(x)))) for x in s // win]
        out[c] = np.array([np.nan if y is None else y for y in v], dtype=float)
    return out


def classify(a, b, medA, medB, hi, lo, floor):
    rA, rB = a / medA, b / medB
    ok = np.isfinite(b) & (a > floor) & (b > floor)
    lab = np.full(len(a), '', dtype=object)
    lab[ok & (rA >= hi) & (rB < hi)] = 'B_to_A'
    lab[ok & (rB <= lo) & (rA > lo)] = 'A_to_B'
    lab[ok & (rA >= hi) & (rB <= lo)] = 'reciprocal'
    return lab


def runs(starts, lab, win, gap, minw):
    out, cur, cl = [], [], None
    for s, l in zip(starts, lab):
        if not l:
            continue
        if cur and l == cl and (s - cur[-1]) // win <= gap + 1:
            cur.append(s)
        else:
            if len(cur) >= minw:
                out.append((cl, cur[0], cur[-1] + win, len(cur)))
            cur, cl = [s], l
    if len(cur) >= minw:
        out.append((cl, cur[0], cur[-1] + win, len(cur)))
    return out


def call_all(covA, part, medA, medB, hi, lo, P):
    win, gap, minw, floor = int(P['WIN']), int(P['MAX_GAP_WIN']), int(P['MIN_CAND_WIN']), float(P['T_B_FLOOR'])
    rec = []
    for c, (s, dep) in covA.items():
        o = np.argsort(s)
        lab = classify(dep[o], part[c][o], medA, medB, hi, lo, floor)
        rec += [(t, c, a, b, n) for t, a, b, n in runs(s[o], lab, win, gap, minw)]
    return rec


def simulate(covA, part, called, medA, medB, hi, lo, P, rng):
    win, gap, minw, floor = int(P['WIN']), int(P['MAX_GAP_WIN']), int(P['MIN_CAND_WIN']), float(P['T_B_FLOOR'])
    he = defaultdict(list)
    for t, c, a, b, n in called:
        he[c].append((a, b))
    cand = []
    for c, (s, dep) in covA.items():
        o = np.argsort(s)
        s, a, b = s[o], dep[o], part[c][o]
        valid = np.isfinite(b) & (a > floor) & (b > floor)
        for x, y in he.get(c, []):
            valid &= ~((s >= x) & (s < y))
        cand.append((c, s, a, b, valid))
    res = {}
    for L in LENS:
        starts = [(k, i) for k, (_, s, _, _, v) in enumerate(cand)
                  for i in range(len(s) - L + 1)
                  if v[i:i + L].all() and s[i + L - 1] - s[i] == (L - 1) * win]
        if not starts:
            res.update({('B_to_A', L): np.nan, ('A_to_B', L): np.nan})
            continue
        pick = rng.choice(len(starts), min(N_SIM, len(starts)), replace=False)
        for direction in ('B_to_A', 'A_to_B'):
            hit = 0
            for j in pick:
                k, i = starts[j]
                _, s, a, b, _ = cand[k]
                aa, bb = a[i:i + L].copy(), b[i:i + L].copy()
                if direction == 'B_to_A':
                    aa = bb.copy()
                else:
                    bb = aa.copy()
                lab = classify(aa, bb, medA, medB, hi, lo, floor)
                hit += any(t == direction and n >= minw and (e - st) >= 0.5 * L * win
                           for t, st, e, n in runs(s[i:i + L], lab, win, gap, minw))
            res[(direction, L)] = hit / len(pick)
    return res


def paf_identity(paf, covA, win):
    m, l = defaultdict(float), defaultdict(float)
    with open(paf) as f:
        for ln in f:
            p = ln.split('\t')
            if len(p) < 11:
                continue
            q, qs, qe, nm, al = p[0], int(p[2]), int(p[3]), int(p[9]), int(p[10])
            if not q.startswith('chrA') or qe <= qs:
                continue
            for wi in range(qs // win, (qe - 1) // win + 1):
                ov = min(qe, (wi + 1) * win) - max(qs, wi * win)
                if ov > 0:
                    fr = ov / (qe - qs)
                    m[(q, wi)] += nm * fr
                    l[(q, wi)] += al * fr
    return {k: m[k] / l[k] for k in l if l[k] > 0}


NON_TE = ('Simple_repeat', 'Low_complexity', 'Satellite', 'rRNA', 'snRNA', 'tRNA', 'scRNA', 'srpRNA')


def te_windows(gff, win):
    te = pd.read_csv(gff, sep='\t', header=None, usecols=[0, 2, 3, 4, 8], names=['chr', 'cls', 's', 'e', 'att'],
                     dtype={'chr': str, 'cls': str, 's': np.int64, 'e': np.int64, 'att': str})
    te = te[~te['cls'].str.startswith(NON_TE)]
    te['fam'] = te['att'].str.extract(r'ID=([^;]+)', expand=False).fillna(te['cls'])
    s0, e = te['s'].values - 1, te['e'].values
    w0, w1 = s0 // win, (e - 1) // win
    one = w0 == w1
    parts = [pd.DataFrame({'chr': te['chr'].values[one], 'wi': w0[one], 'fam': te['fam'].values[one],
                           'bp': (e - s0)[one]})]
    rows = []
    for c, f, a, b, x, y in zip(te['chr'].values[~one], te['fam'].values[~one], s0[~one], e[~one], w0[~one], w1[~one]):
        for wi in range(x, y + 1):
            rows.append((c, wi, f, min(b, (wi + 1) * win) - max(a, wi * win)))
    parts.append(pd.DataFrame(rows, columns=['chr', 'wi', 'fam', 'bp']))
    d = pd.concat(parts).groupby(['chr', 'wi', 'fam'], sort=False)['bp'].sum()
    out = defaultdict(dict)
    for (c, wi, f), bp in d.items():
        out[(c, int(wi))][f] = int(bp)
    return out, len(te)


def _pool(tw, c, wi, flank):
    agg = defaultdict(int)
    for k in range(wi - flank, wi + flank + 1):
        for f, bp in tw.get((c, k), {}).items():
            agg[f] += bp
    return agg


def bray_curtis(x, y):
    tot = sum(x.values()) + sum(y.values())
    return 2 * sum(min(v, y[f]) for f, v in x.items() if f in y) / tot if tot else np.nan


def te_similarity(tw, pw, covA, win, flank, min_bp, rng):
    bmax = defaultdict(int)
    for (c, wi) in tw:
        bmax[c] = max(bmax[c], wi)
    sim, rnd = {}, {}
    for c, (s, _) in covA.items():
        for x in s // win:
            k = (c, int(x))
            if k not in pw:
                continue
            bc, bwi = pw[k]
            A, B = _pool(tw, c, int(x), flank), _pool(tw, bc, bwi, flank)
            if sum(A.values()) < min_bp or sum(B.values()) < min_bp:
                continue
            sim[k] = bray_curtis(A, B)
            if bmax.get(bc):
                R = _pool(tw, bc, int(rng.integers(0, bmax[bc] + 1)), flank)
                if sum(R.values()) >= min_bp:
                    rnd[k] = bray_curtis(A, R)
    return sim, rnd


def mad_log2(x):
    x = np.log2(x[x > 0])
    return float(np.median(np.abs(x - np.median(x))))


def region_index(rec):
    idx = defaultdict(list)
    for t, c, x, y, n in rec:
        if t in ('B_to_A', 'A_to_B'):
            idx[c].append((x, y, t))
    return {c: (np.array([v[0] for v in L]), np.array([v[1] for v in L]), np.array([v[2] for v in L]))
            for c, L in idx.items()}


def evidence(sp, name, rec, wmet, m, win):
    tag = {}
    for t, c, x, y, n in rec:
        if t in ('B_to_A', 'A_to_B'):
            for wi in range(x // win, y // win):
                tag[(c, wi)] = t
    ri = region_index(rec)
    gtag = []
    for c, s0, e0 in zip(m['A_chr'], m['A_start'], m['A_end']):
        if c not in ri:
            gtag.append('none')
            continue
        xs, ys, ts = ri[c]
        h = set(ts[(xs < e0) & (ys > s0)])
        gtag.append('none' if not h else (h.pop() if len(h) == 1 else 'both'))
    gtag = np.array(gtag)
    ks = m['Ks_YN00'].values
    tests = []
    for lab, vals, thr, how, classes in wmet:
        out_v = np.array([v for k, v in vals.items() if k not in tag and np.isfinite(v)])
        for t in classes:
            tests.append((lab, t, np.array([v for k, v in vals.items() if tag.get(k) == t and np.isfinite(v)]),
                          out_v, thr, how))
    for t in ('B_to_A', 'A_to_B'):
        tests.append(('homoeolog Ks', t, ks[gtag == t], ks[gtag == 'none'], KS_LO, 'lt'))
    out = []
    for lab, t, x, o, thr, how in tests:
        if len(x) < 5 or len(o) < 5:
            continue
        ex, eo = ((x >= thr), (o >= thr)) if how == 'ge' else ((x < thr), (o < thr))
        orr, fp = fisher_exact([[int(ex.sum()), int((~ex).sum())], [int(eo.sum()), int((~eo).sum())]])
        out.append(dict(species=sp, thresholds=name, evidence=lab, group=t, n=len(x),
                        median=round(float(np.median(x)), 4), median_outside=round(float(np.median(o)), 4),
                        mw_p=mannwhitneyu(x, o).pvalue,
                        extreme=f'>={thr:.3g}' if how == 'ge' else f'<{thr:.3g}',
                        frac_extreme=round(float(ex.mean()), 4), frac_extreme_outside=round(float(eo.mean()), 4),
                        OR=round(orr, 2), fisher_p=fp))
    return out

def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--he', default=os.path.expanduser('~/mbe_review/he'))
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    ap.add_argument('--run', default='legacy', choices=['legacy', 'primary'])
    a = ap.parse_args()
    rng = np.random.default_rng(SEED)
    runs_dir = {('tl', 'legacy'): 'tl/legacy_tianlinensis', ('cx', 'legacy'): 'cx/legacy_longibarbatus',
                ('tl', 'primary'): 'tl/primary_tianlinensis_new', ('cx', 'primary'): 'cx/primary_longibarbatus_new'}
    rows, idrows = [], []
    for sp in ('tl', 'cx'):
        D = f'{a.he}/{runs_dir[(sp, a.run)]}/HE_analysis'
        P = params(f'{D}/05_HE/TableS3_parameters.tsv')
        win = int(P['WIN'])
        covA, covB = load_cov(f'{D}/02_cov/omac_to_A.win.bed'), load_cov(f'{D}/02_cov/omac_to_B.win.bed')
        medA = float(np.median(np.concatenate([d[d > 0] for _, d in covA.values()])))
        medB = float(np.median(np.concatenate([d[d > 0] for _, d in covB.values()])))
        base = medB / medA
        pw = partner_windows(f'{D}/04_homoeolog_map/homoeolog_blocks.bed', win)
        part = partners(pw, covA, covB, win)
        npart = sum(int(np.isfinite(v).sum()) for v in part.values())
        print(f'[{sp} {a.run}] medA {medA:.2f} medB {medB:.2f} (B/A {base:.3f}); A windows with a partner {npart}')

        fl = float(P['T_B_FLOOR'])
        pa = np.concatenate([d[np.isfinite(part[c]) & (d > fl) & (part[c] > fl)] for c, (_, d) in covA.items()])
        pb = np.concatenate([part[c][np.isfinite(part[c]) & (d > fl) & (part[c] > fl)] for c, (_, d) in covA.items()])
        mA_p, mB_p = float(np.median(pa)), float(np.median(pb))
        bp = mB_p / mA_p
        print(f'  partnered windows: medA {mA_p:.2f} ({mA_p / medA:.2f} x genome-wide) medB {mB_p:.2f} '
              f'({mB_p / medB:.2f} x genome-wide); dispersion (MAD of log2 depth) A {mad_log2(pa):.3f} '
              f'B {mad_log2(pb):.3f}')
        sets = [('published', float(P['RATIO_HI']), float(P['RATIO_LO']), medA, medB),
                ('symmetric_expected', base, 1 / base, medA, medB),
                ('symmetric_partnered', bp, 1 / bp, mA_p, mB_p),
                ('symmetric_strict', base * STRICT, 1 / (base * STRICT), medA, medB),
                ('strict_HI_only', base * STRICT, 1 / base, medA, medB)]
        if abs(float(P['RATIO_HI']) - 1.5) > 1e-9 or abs(float(P['RATIO_LO']) - 0.6) > 1e-9:
            sets.append(('methods_text', 1.5, 0.6, medA, medB))
        idt = paf_identity(f'{D}/04_homoeolog_map/A_vs_B.paf', covA, win)
        wmet = [('A-B identity', idt, ID_HI, 'ge', ('B_to_A', 'A_to_B'))]
        fai = f'{a.base}/{sp}_AB.fa.fai'
        if os.path.exists(fai):
            L = dict(pd.read_csv(fai, sep='\t', header=None, usecols=[0, 1], dtype={0: str}).values)
            ok = [c for c, (s_, _) in covA.items() if c in L and abs(L[c] - (s_.max() + win)) <= win]
            print(f'  {len(ok)}/{len(covA)} A chromosomes match {sp}_AB.fa by name and length')
        te_gff = f'{a.base}/te_tad/{sp}/renamed/{sp}.TE.gff'
        if os.path.exists(te_gff):
            tw, nte = te_windows(te_gff, win)
            named = len({c for c, _ in tw} & set(covA)) / len(covA)
            sim, rnd = te_similarity(tw, pw, covA, win, TE_FLANK, TE_MIN_BP, np.random.default_rng(SEED + 1))
            if sim:
                q = float(np.quantile(list(sim.values()), 0.9))
                print(f'  TE: {nte} copies; {named:.0%} of A chromosomes named as in the TE GFF; composition '
                      f'similarity A vs partner B (Bray-Curtis, {2 * TE_FLANK + 1} windows) median '
                      f'{np.median(list(sim.values())):.3f} (random B window {np.median(list(rnd.values())):.3f}; '
                      f'n = {len(sim)})')
                wmet.append(('TE composition similarity', sim, q, 'ge', ('B_to_A', 'A_to_B')))
            else:
                print('  TE: no window pairs with TE content; chromosome names may not match')
        else:
            print(f'  TE: {te_gff} not found, skipped')
        pha, phb = f'{D}/02_cov/phua_to_A.win.bed', f'{D}/02_cov/phua_to_B.win.bed'
        if os.path.exists(pha) and os.path.exists(phb):
            hA, hB = load_cov(pha), load_cov(phb)
            hpart = partners(pw, hA, hB, win)
            xa = np.concatenate([d[np.isfinite(hpart[c]) & (d > fl) & (hpart[c] > fl)] for c, (_, d) in hA.items()])
            xb = np.concatenate([hpart[c][np.isfinite(hpart[c]) & (d > fl) & (hpart[c] > fl)]
                                 for c, (_, d) in hA.items()])
            hmA, hmB = float(np.median(xa)), float(np.median(xb))
            hrA, hrB = {}, {}
            for c, (s_, d) in hA.items():
                ok = np.isfinite(hpart[c]) & (d > fl) & (hpart[c] > fl)
                for x, y, z in zip(s_[ok] // win, d[ok], hpart[c][ok]):
                    hrA[(c, int(x))], hrB[(c, int(x))] = y / hmA, z / hmB
            hb = hmB / hmA
            print(f'  Poropuntius (validation reads): partnered medA {hmA:.2f} medB {hmB:.2f} (B/A {hb:.3f})')
            wmet += [('Poropuntius rA', hrA, hb, 'ge', ('B_to_A',)), ('Poropuntius rB', hrB, 1 / hb, 'lt', ('A_to_B',))]
        m = pd.read_csv(f'{a.base}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t',
                        dtype={'A_chr': str, 'HE': str})
        m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)].copy()
        m['Ks_YN00'] = pd.to_numeric(m['Ks_YN00'], errors='coerce')
        m = m[np.isfinite(m['Ks_YN00'])]
        known = m['A_chr'].isin(set(covA)).mean()
        print(f'  sequence data: {len(idt)} A windows with A-B identity; {len(m)} homoeolog pairs '
              f'({known:.0%} on chromosomes named as in the coverage files)')
        if known < 0.5:
            print('  WARNING: master-table chromosome names do not match the coverage files; Ks evidence will be empty')
        published = None
        for name, hi, lo, mA, mB in sets:
            rec = call_all(covA, part, mA, mB, hi, lo, P)
            if name == 'published':
                published = rec
                f = pd.read_csv(f'{D}/05_HE/HE_regions_relative.tsv', sep='\t')
                fc = f['type'].value_counts().to_dict()
                mine = pd.Series([r[0] for r in rec]).value_counts().to_dict()
                print(f'  reproduction vs HE_regions_relative.tsv: ' +
                      ', '.join(f'{t} {mine.get(t, 0)} (file {fc.get(t, 0)})' for t in ('B_to_A', 'A_to_B', 'reciprocal')))
            pw = simulate(covA, part, published, mA, mB, hi, lo, P, rng)
            nB = sum(r[0] == 'B_to_A' for r in rec); nA = sum(r[0] == 'A_to_B' for r in rec)
            mbB = sum(r[3] - r[2] for r in rec if r[0] == 'B_to_A') / 1e6
            mbA = sum(r[3] - r[2] for r in rec if r[0] == 'A_to_B') / 1e6
            pB, pA = pw[('B_to_A', 10)], pw[('A_to_B', 10)]
            corr = (nB / pB) / (nA / pA) if nA and pA and pB else np.nan
            r = dict(species=sp, run=a.run, thresholds=name, HI=round(hi, 4), LO=round(lo, 4), n_B_to_A=nB,
                     Mb_B_to_A=round(mbB, 1), n_A_to_B=nA, Mb_A_to_B=round(mbA, 1),
                     **{f'power_{d}_{L}w': round(pw[(d, L)], 3) for d in ('B_to_A', 'A_to_B') for L in LENS},
                     ratio_observed=round(nB / nA, 1) if nA else np.nan, ratio_power_corrected=round(corr, 1))
            rows.append(r)
            print(f"  {name:<19} HI {hi:.3f} LO {lo:.3f} | B_to_A {nB:4d} ({mbB:5.1f} Mb)  A_to_B {nA:4d} ({mbA:5.1f} Mb) | "
                  f"power B_to_A {pw[('B_to_A', 5)]:.2f}/{pB:.2f}/{pw[('B_to_A', 20)]:.2f}  "
                  f"A_to_B {pw[('A_to_B', 5)]:.2f}/{pA:.2f}/{pw[('A_to_B', 20)]:.2f} (5/10/20 windows) | "
                  f"ratio {r['ratio_observed']} -> power-corrected {r['ratio_power_corrected']}", flush=True)
            idrows += evidence(sp, name, rec, wmet, m, win)

    os.makedirs(f'{a.base}/analysis', exist_ok=True)
    t1, t2 = pd.DataFrame(rows), pd.DataFrame(idrows)
    t1.to_csv(f'{a.base}/analysis/he_power_{a.run}.tsv', sep='\t', index=False)
    t2.to_csv(f'{a.base}/analysis/he_sequence_evidence_{a.run}.tsv', sep='\t', index=False)
    with pd.option_context('display.width', 250, 'display.max_columns', 30):
        print('\n' + t2.to_string(index=False, float_format=lambda v: f'{v:.4g}'))
    print(f'-> {a.base}/analysis/he_power_{a.run}.tsv, he_sequence_evidence_{a.run}.tsv')


if __name__ == '__main__':
    main()
