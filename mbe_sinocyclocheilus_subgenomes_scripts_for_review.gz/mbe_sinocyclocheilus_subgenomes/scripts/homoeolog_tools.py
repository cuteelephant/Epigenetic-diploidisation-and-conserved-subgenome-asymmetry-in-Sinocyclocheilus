#!/usr/bin/env python3
import argparse, bisect, os, re, subprocess, sys, tempfile
from collections import Counter, defaultdict
from multiprocessing import Pool

CHR_RE = re.compile(r'^chr([AB])(\d+)$')


def attrs(s):
    d = {}
    for kv in s.strip().strip(';').split(';'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            d[k.strip()] = v.strip()
    return d


def read_fasta(path):
    seqs, name, buf = {}, None, []
    with open(path) as f:
        for line in f:
            if line.startswith('>'):
                if name is not None:
                    seqs[name] = ''.join(buf)
                name, buf = line[1:].split()[0], []
            else:
                buf.append(line.strip())
    if name is not None:
        seqs[name] = ''.join(buf)
    return seqs


def read_tsv(path):
    with open(path) as f:
        head = f.readline().rstrip('\n').split('\t')
        return [dict(zip(head, l.rstrip('\n').split('\t'))) for l in f if l.strip()]


def write_tsv(path, cols, rows):
    with open(path, 'w') as o:
        o.write('\t'.join(cols) + '\n')
        for r in rows:
            o.write('\t'.join(str(r.get(c, 'NA')) for c in cols) + '\n')


def cmd_prep(a):
    from Bio import SeqIO
    from Bio.Seq import Seq

    m2g, minfo, cds = {}, {}, defaultdict(list)
    with open(a.gff) as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            p = line.rstrip('\n').split('\t')
            if len(p) < 9:
                continue
            chrom, typ, st, en, strand, phase, at = p[0], p[2], int(p[3]), int(p[4]), p[6], p[7], attrs(p[8])
            if typ in ('mRNA', 'transcript'):
                mid, gid = at.get('ID'), at.get('Parent', '').split(',')[0]
                if mid and gid:
                    m2g[mid], minfo[mid] = gid, (chrom, strand)
            elif typ == 'CDS':
                for par in at.get('Parent', '').split(','):
                    if par:
                        cds[par].append((st, en, phase))

    best = {}
    for mid in sorted(cds):
        if mid not in m2g:
            continue
        L = sum(e - s + 1 for s, e, _ in cds[mid])
        g = m2g[mid]
        if g not in best or L > best[g][1]:
            best[g] = (mid, L)

    bychr, skipped = defaultdict(list), Counter()
    for g, (mid, _) in best.items():
        chrom = minfo[mid][0]
        if CHR_RE.match(chrom):
            bychr[chrom].append((g, mid))
        else:
            skipped[chrom] += 1

    genes = []
    seq_out = {'A': [], 'B': []}
    for rec in SeqIO.parse(a.genome, 'fasta'):
        if rec.id not in bychr:
            continue
        chrseq = str(rec.seq).upper()
        sub = CHR_RE.match(rec.id).group(1)
        for g, mid in bychr[rec.id]:
            strand = minfo[mid][1]
            segs = sorted(cds[mid])
            s = ''.join(chrseq[x - 1:y] for x, y, _ in segs)
            first = segs[0]
            if strand == '-':
                s = str(Seq(s).reverse_complement())
                first = segs[-1]
            trim = int(first[2]) if first[2] in ('0', '1', '2') else 0
            s = s[trim:]
            s = s[:len(s) // 3 * 3]
            prot = str(Seq(s).translate(table=1))
            if prot.endswith('*'):
                prot, s = prot[:-1], s[:-3]
            genes.append(dict(gene=g, mrna=mid, chr=rec.id, sub=sub, start=segs[0][0] - 1, end=segs[-1][1],
                              strand=strand, cds_len=len(s), internal_stop=int('*' in prot)))
            seq_out[sub].append((g, s))

    genes.sort(key=lambda r: (r['chr'], r['start']))
    write_tsv(os.path.join(a.out, f'{a.sp}.genes.tsv'),
              ['gene', 'mrna', 'chr', 'sub', 'start', 'end', 'strand', 'cds_len', 'internal_stop'], genes)
    for sub in 'AB':
        with open(os.path.join(a.out, f'{a.sp}{sub}.bed'), 'w') as o:
            for r in genes:
                if r['sub'] == sub:
                    o.write(f"{r['chr']}\t{r['start']}\t{r['end']}\t{r['gene']}\t0\t{r['strand']}\n")
        with open(os.path.join(a.out, f'{a.sp}{sub}.cds'), 'w') as o:
            for g, s in sorted(seq_out[sub]):
                o.write(f'>{g}\n{s}\n')

    n = Counter(r['sub'] for r in genes)
    print(f'[{a.sp}] genes with CDS: subA {n["A"]}, subB {n["B"]}; '
          f'internal stop {sum(r["internal_stop"] for r in genes)}; '
          f'genes on non-chrA/chrB sequences skipped: {sum(skipped.values())}')


def cmd_pairs(a):
    genes = {r['gene']: r for r in read_tsv(a.genes)}
    blocks, cur = [], []
    with open(a.anchors) as f:
        for line in f:
            if line.startswith('#'):
                if cur:
                    blocks.append(cur)
                cur = []
                continue
            p = line.split()
            if len(p) >= 2:
                cur.append((p[0], p[1]))
    if cur:
        blocks.append(cur)

    rows = []
    for bi, b in enumerate(blocks, 1):
        for x, y in b:
            if x not in genes or y not in genes:
                continue
            if genes[x]['sub'] == 'B' and genes[y]['sub'] == 'A':
                x, y = y, x
            if genes[x]['sub'] == 'A' and genes[y]['sub'] == 'B':
                rows.append((x, y, bi, len(b)))
    ca, cb = Counter(r[0] for r in rows), Counter(r[1] for r in rows)
    keep = [r for r in rows if ca[r[0]] == 1 and cb[r[1]] == 1]

    out = []
    for x, y, bi, bs in keep:
        A, B = genes[x], genes[y]
        out.append(dict(A_gene=x, B_gene=y, A_chr=A['chr'], A_start=A['start'], A_end=A['end'], A_strand=A['strand'],
                        B_chr=B['chr'], B_start=B['start'], B_end=B['end'], B_strand=B['strand'],
                        same_chr_number=int(CHR_RE.match(A['chr']).group(2) == CHR_RE.match(B['chr']).group(2)),
                        block_id=bi, block_size=bs))
    write_tsv(a.out, ['A_gene', 'B_gene', 'A_chr', 'A_start', 'A_end', 'A_strand', 'B_chr', 'B_start', 'B_end',
                      'B_strand', 'same_chr_number', 'block_id', 'block_size'], out)
    same = sum(r['same_chr_number'] for r in out)
    print(f'[{a.sp}] anchor pairs A-B {len(rows)}; removed (gene in >1 pair) {len(rows) - len(keep)}; '
          f'strict 1:1 kept {len(out)}; on homoeologous chr (same number) {same} '
          f'({100 * same / max(len(out), 1):.1f}%); blocks {len({r["block_id"] for r in out})}')


CDS, YN00, WD = {}, None, None
YN_RE = re.compile(r'^\s*2\s+1\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s*\+-\s*(\S+)\s+(\S+)\s*\+-\s*(\S+)')
NG_RE = re.compile(r'^B\s+(\S+)\s*\(\s*(\S+)\s+(\S+)\s*\)')
MAX_CELLS = 1e8


def _init(cds, yn00, base):
    global CDS, YN00, WD, ALIGNER
    from Bio import Align
    from Bio.Align import substitution_matrices
    CDS, YN00 = cds, yn00
    WD = tempfile.mkdtemp(prefix='yn00_', dir=base)
    with open(os.path.join(WD, 'yn00.ctl'), 'w') as o:
        o.write('seqfile = in.nuc\noutfile = out.yn\nverbose = 0\nicode = 0\nweighting = 0\ncommonf3x4 = 0\n')
    ALIGNER = Align.PairwiseAligner(mode='global', substitution_matrix=substitution_matrices.load('BLOSUM62'),
                                    open_gap_score=-10, extend_gap_score=-0.5)


def _num(x):
    try:
        return float(x)
    except ValueError:
        return float('nan')


def _ks_one(pair):
    from Bio.Seq import Seq
    ga, gb = pair
    r = dict(A_gene=ga, B_gene=gb)
    ca, cb = CDS.get(ga), CDS.get(gb)
    if not ca or not cb:
        return {**r, 'status': 'missing_cds'}
    pa, pb = str(Seq(ca).translate()), str(Seq(cb).translate())
    if '*' in pa or '*' in pb:
        return {**r, 'status': 'internal_stop'}
    if len(pa) * len(pb) > MAX_CELLS:
        return {**r, 'status': 'too_long'}
    aln = ALIGNER.align(pa, pb)[0]
    xa, xb = aln[0], aln[1]

    def back(gapped, nuc):
        out, i = [], 0
        for c in gapped:
            if c == '-':
                out.append('---')
            else:
                out.append(nuc[3 * i:3 * i + 3])
                i += 1
        return ''.join(out)

    both = [(x, y) for x, y in zip(xa, xb) if x != '-' and y != '-']
    r.update(aln_codons=len(both), pid=round(sum(x == y for x, y in both) / max(len(both), 1), 4),
             cov=round(len(both) / max(len(pa), len(pb)), 4))
    na, nb = back(xa, ca), back(xb, cb)
    with open(os.path.join(WD, 'in.nuc'), 'w') as o:
        o.write(f'  2  {len(na)}\nA\n{na}\nB\n{nb}\n')
    outp = os.path.join(WD, 'out.yn')
    if os.path.exists(outp):
        os.remove(outp)
    try:
        subprocess.run([YN00, 'yn00.ctl'], cwd=WD, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    except subprocess.TimeoutExpired:
        return {**r, 'status': 'yn00_timeout'}
    if not os.path.exists(outp):
        return {**r, 'status': 'yn00_failed'}
    txt = open(outp).read().splitlines()
    ng = yn = None
    for i, line in enumerate(txt):
        if line.startswith('Nei & Gojobori 1986'):
            for l2 in txt[i + 1:i + 10]:
                m = NG_RE.match(l2)
                if m:
                    ng = m.groups()
                    break
        if line.startswith('seq. seq.'):
            for l2 in txt[i + 1:i + 5]:
                m = YN_RE.match(l2)
                if m:
                    yn = m.groups()
                    break
    if yn is None:
        return {**r, 'status': 'yn00_parse'}
    S, N, t, kappa, omega, dN, dNse, dS, dSse = map(_num, yn)
    r.update(S=S, N=N, Ka_YN00=dN, Ks_YN00=dS, omega_YN00=omega, status='ok')
    if ng:
        r.update(omega_NG86=_num(ng[0]), Ka_NG86=_num(ng[1]), Ks_NG86=_num(ng[2]))
    return r


def cmd_ks(a):
    import shutil
    yn00 = os.path.abspath(shutil.which(a.yn00) or a.yn00)
    if not os.access(yn00, os.X_OK):
        sys.exit(f'yn00 not found or not executable: {a.yn00}')
    cds = {**read_fasta(a.cds_a), **read_fasta(a.cds_b)}
    pairs = [(r['A_gene'], r['B_gene']) for r in read_tsv(a.pairs)]
    base = os.path.dirname(os.path.abspath(a.out))
    with Pool(a.threads, initializer=_init, initargs=(cds, yn00, base)) as pool:
        res = pool.map(_ks_one, pairs, chunksize=50)
    for d in os.listdir(base):
        if d.startswith('yn00_'):
            subprocess.run(['rm', '-rf', os.path.join(base, d)])
    write_tsv(a.out, ['A_gene', 'B_gene', 'aln_codons', 'pid', 'cov', 'S', 'N', 'Ka_YN00', 'Ks_YN00', 'omega_YN00',
                      'Ka_NG86', 'Ks_NG86', 'omega_NG86', 'status'], res)
    st = Counter(r['status'] for r in res)
    print(f'[{a.sp}] pairs {len(res)}; status: ' + ', '.join(f'{k} {v}' for k, v in st.most_common()))


BINS = [(0, .02), (.02, .05), (.05, .10), (.10, .20), (.20, .50), (.50, 3.0)]


def he_index(path):
    idx = {'A': defaultdict(list), 'B': defaultdict(list)}
    for r in read_tsv(path):
        idx['A'][r['A_chr']].append((int(r['A_start']), int(r['A_end']), r['HE_type']))
        idx['B'][r['B_chr']].append((int(r['B_start']), int(r['B_end']), r['HE_type']))
    for side in idx.values():
        for c in side:
            side[c].sort()
    return idx


def he_hit(iv, chrom, s, e):
    lst = iv.get(chrom, [])
    starts = [x[0] for x in lst]
    i = bisect.bisect_left(starts, e)
    hits = {t for (a0, a1, t) in lst[max(0, i - 50):i] if a0 < e and a1 > s}
    return hits


def cmd_summary(a):
    ks = {(r['A_gene'], r['B_gene']): r for r in read_tsv(a.ks)}
    he = he_index(a.he)
    rows = []
    for p in read_tsv(a.pairs):
        r = {**p, **ks.get((p['A_gene'], p['B_gene']), {'status': 'no_ks'})}
        hits = he_hit(he['A'], p['A_chr'], int(p['A_start']), int(p['A_end'])) | \
               he_hit(he['B'], p['B_chr'], int(p['B_start']), int(p['B_end']))
        r['HE'] = '+'.join(sorted(hits)) if hits else 'none'
        k = _num(r.get('Ks_YN00', 'NA'))
        r['qc_ks'] = int(r['status'] == 'ok' and _num(r['cov']) >= 0.5 and int(r['aln_codons']) >= 50
                         and k == k and 0 <= k < 3)
        r['Ks_class'] = 'NA' if not r['qc_ks'] else ('low_<0.05' if k < 0.05 else 'main_0.05-0.30' if k < 0.30
                                                     else 'high_>=0.30')
        rows.append(r)

    cols = ['A_gene', 'B_gene', 'A_chr', 'A_start', 'A_end', 'A_strand', 'B_chr', 'B_start', 'B_end', 'B_strand',
            'same_chr_number', 'block_id', 'block_size', 'aln_codons', 'pid', 'cov', 'Ka_YN00', 'Ks_YN00',
            'omega_YN00', 'Ka_NG86', 'Ks_NG86', 'status', 'qc_ks', 'Ks_class', 'HE']
    write_tsv(a.out, cols, rows)

    good = [r for r in rows if r['qc_ks']]
    kv = sorted(_num(r['Ks_YN00']) for r in good)
    q = lambda f: kv[min(int(f * len(kv)), len(kv) - 1)] if kv else float('nan')
    hist = Counter(min(int(k / 0.01), 40) for k in kv)
    mode = max(range(40), key=lambda b: hist[b]) * 0.01 if kv else float('nan')
    nlow = sum(k < 0.05 for k in kv)
    print(f'===== {a.sp} =====')
    print(f'strict 1:1 pairs            {len(rows)}')
    print(f'  same chromosome number    {sum(int(r["same_chr_number"]) for r in rows)}')
    print(f'  Ks status                 ' + ', '.join(f'{k} {v}' for k, v in Counter(r['status'] for r in rows).most_common()))
    print(f'  QC pass (cov>=0.5, >=50 codons, 0<=Ks<3)  {len(good)}')
    print(f'Ks (YN00, QC pass): 5% {q(.05):.3f} | 25% {q(.25):.3f} | median {q(.5):.3f} | 75% {q(.75):.3f} | '
          f'95% {q(.95):.3f} | mode bin {mode:.2f}-{mode + .01:.2f}')
    print(f'Ks < 0.05: {nlow} ({100 * nlow / max(len(kv), 1):.1f}%)')
    print('\nKs histogram (0.01 bins; last bin = >=0.40)')
    top = max(hist.values()) if hist else 1
    for b in range(41):
        lab = f'{b * .01:.2f}' if b < 40 else '>=.40'
        print(f'  {lab:>6} {hist[b]:6d} ' + '#' * round(50 * hist[b] / top))

    print('\nHE overlap by Ks bin (QC pass)')
    print(f'  {"Ks_bin":<11}{"n":>7}{"in_HE":>7}{"%HE":>7}{"B_to_A":>8}{"A_to_B":>8}')
    for lo, hi in BINS:
        sel = [r for r in good if lo <= _num(r['Ks_YN00']) < hi]
        nh = sum(r['HE'] != 'none' for r in sel)
        print(f'  {f"{lo:.2f}-{hi:.2f}":<11}{len(sel):>7}{nh:>7}{100 * nh / max(len(sel), 1):>6.1f}%'
              f'{sum("B_to_A" in r["HE"] for r in sel):>8}{sum("A_to_B" in r["HE"] for r in sel):>8}')
    lo_he = sum(_num(r['Ks_YN00']) < .05 and r['HE'] != 'none' for r in good)
    lo_no = nlow - lo_he
    hi_he = sum(_num(r['Ks_YN00']) >= .05 and r['HE'] != 'none' for r in good)
    hi_no = len(good) - nlow - hi_he
    orr = (lo_he * hi_no) / (lo_no * hi_he) if lo_no and hi_he else float('nan')
    try:
        from scipy.stats import fisher_exact
        p = f'{fisher_exact([[lo_he, lo_no], [hi_he, hi_no]])[1]:.2e}'
    except Exception:
        p = 'NA (scipy not available)'
    print(f'Low-Ks (<0.05) vs rest, in HE: {lo_he}/{nlow} vs {hi_he}/{len(good) - nlow}; OR {orr:.2f}; Fisher P {p}')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('prep'); p.add_argument('--sp', required=True); p.add_argument('--genome', required=True)
    p.add_argument('--gff', required=True); p.add_argument('--out', required=True)
    p = sp.add_parser('pairs'); p.add_argument('--sp', required=True); p.add_argument('--anchors', required=True)
    p.add_argument('--genes', required=True); p.add_argument('--out', required=True)
    p = sp.add_parser('ks'); p.add_argument('--sp', required=True); p.add_argument('--pairs', required=True)
    p.add_argument('--cds-a', required=True); p.add_argument('--cds-b', required=True)
    p.add_argument('--yn00', default='yn00'); p.add_argument('--threads', type=int, default=16)
    p.add_argument('--out', required=True)
    p = sp.add_parser('summary'); p.add_argument('--sp', required=True); p.add_argument('--pairs', required=True)
    p.add_argument('--ks', required=True); p.add_argument('--he', required=True); p.add_argument('--out', required=True)
    a = ap.parse_args()
    {'prep': cmd_prep, 'pairs': cmd_pairs, 'ks': cmd_ks, 'summary': cmd_summary}[a.cmd](a)


if __name__ == '__main__':
    main()
