#!/usr/bin/env python3
import argparse, os
from collections import Counter
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, fisher_exact

T_METH, T_FC, N_PERM, SEED = 0.3, 1.0, 10000, 1


def cmd_orth(a):
    rows = []
    with open(a.anchors) as f:
        for line in f:
            if line.startswith('#'):
                continue
            p = line.split()
            if len(p) >= 2:
                rows.append((p[0], p[1]))
    c1, c2 = Counter(r[0] for r in rows), Counter(r[1] for r in rows)
    keep = [r for r in rows if c1[r[0]] == 1 and c2[r[1]] == 1]
    pd.DataFrame(keep, columns=['tl_gene', 'cx_gene']).to_csv(a.out, sep='\t', index=False)
    print(f'{os.path.basename(a.anchors)}: anchors {len(rows)}; strict 1:1 {len(keep)} -> {a.out}')


def silenced(dm, fc):
    return np.where((dm <= -T_METH) & (fc >= T_FC), 'A', np.where((dm >= T_METH) & (fc <= -T_FC), 'B', '-'))


def cmd_analyze(a):
    rng = np.random.default_rng(SEED)
    pairs = pd.read_csv(a.pairs, sep='\t', dtype={'individual': str, 'HE': str})
    oA = dict(pd.read_csv(a.orth_a, sep='\t').values)
    oB = dict(pd.read_csv(a.orth_b, sep='\t').values)
    rows, out = [], []
    for (tissue, ind), d in pairs.groupby(['tissue', 'individual']):
        tl = d[d['species'] == 'tl'].copy()
        cx = d[d['species'] == 'cx'][['A_gene', 'B_gene', 'dMeth', 'log2FC', 'HE']]
        tl['cxA'], tl['cxB'] = tl['A_gene'].map(oA), tl['B_gene'].map(oB)
        q = tl.merge(cx, left_on=['cxA', 'cxB'], right_on=['A_gene', 'B_gene'], suffixes=('_tl', '_cx'))
        q['tissue'], q['individual'] = tissue, ind
        out.append(q)
        for pset, qq in (('all', q), ('noHE', q[(q['HE_tl'] == 'none') & (q['HE_cx'] == 'none')])):
            ddm = (qq['dMeth_tl'] - qq['dMeth_cx']).values
            dfc = (qq['log2FC_tl'] - qq['log2FC_cx']).values
            rho, p = spearmanr(ddm, dfc)
            pp = int(((ddm >= T_METH) & (dfc <= -T_FC)).sum()); mm = int(((ddm <= -T_METH) & (dfc >= T_FC)).sum())
            pm = int(((ddm >= T_METH) & (dfc >= T_FC)).sum()); mp = int(((ddm <= -T_METH) & (dfc <= -T_FC)).sum())
            orr, p_or = fisher_exact([[pp, pm], [mp, mm]])
            s_tl = silenced(qq['dMeth_tl'].values, qq['log2FC_tl'].values)
            dcx, fcx = qq['dMeth_cx'].values, qq['log2FC_cx'].values
            flips = lambda s1, s2: int((((s1 == 'A') & (s2 == 'B')) | ((s1 == 'B') & (s2 == 'A'))).sum())
            same = lambda s1, s2: int((((s1 == 'A') & (s2 == 'A')) | ((s1 == 'B') & (s2 == 'B'))).sum())
            s_cx = silenced(dcx, fcx)
            obs_f, obs_s = flips(s_tl, s_cx), same(s_tl, s_cx)
            null_f = np.empty(a.perm)
            for k in range(a.perm):
                idx = rng.permutation(len(qq))
                null_f[k] = flips(s_tl, s_cx[idx])
            mu = null_f.mean()
            p_flip = (np.sum(np.abs(null_f - mu) >= abs(obs_f - mu)) + 1) / (a.perm + 1)
            r = dict(tissue=tissue, individual=ind, pair_set=pset, n_quartets=len(qq),
                     rho_delta=round(rho, 4), p_rho=f'{p:.2e}', n_concordant=pp + mm, n_discordant=pm + mp,
                     coupling_OR=round(orr, 3), coupling_p=f'{p_or:.2e}', n_flip=obs_f, n_same=obs_s,
                     null_flip_mean=round(mu, 1), null_flip_lo95=np.percentile(null_f, 2.5),
                     null_flip_hi95=np.percentile(null_f, 97.5), p_flip=f'{p_flip:.2e}')
            rows.append(r)
            print('\t'.join(str(r[k]) for k in ('tissue', 'individual', 'pair_set', 'n_quartets', 'rho_delta',
                                                 'p_rho', 'coupling_OR', 'coupling_p', 'n_flip', 'n_same',
                                                 'null_flip_mean', 'p_flip')), flush=True)
    os.makedirs(a.outdir, exist_ok=True)
    pd.DataFrame(rows).to_csv(f'{a.outdir}/quartet_summary.tsv', sep='\t', index=False)
    pd.concat(out).to_csv(f'{a.outdir}/quartets.tsv.gz', sep='\t', index=False)
    print(f'-> {a.outdir}/quartet_summary.tsv, quartets.tsv.gz')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('orth'); p.add_argument('--anchors', required=True); p.add_argument('--out', required=True)
    p = sp.add_parser('analyze'); p.add_argument('--pairs', required=True)
    p.add_argument('--orth-a', required=True); p.add_argument('--orth-b', required=True)
    p.add_argument('--perm', type=int, default=N_PERM); p.add_argument('--outdir', required=True)
    a = ap.parse_args()
    {'orth': cmd_orth, 'analyze': cmd_analyze}[a.cmd](a)


if __name__ == '__main__':
    main()
