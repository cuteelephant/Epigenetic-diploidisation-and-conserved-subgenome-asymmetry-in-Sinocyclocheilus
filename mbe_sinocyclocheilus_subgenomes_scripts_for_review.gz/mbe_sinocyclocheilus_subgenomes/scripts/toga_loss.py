#!/usr/bin/env python3
import argparse, os
import numpy as np
import pandas as pd

T_METH, T_FC, N_PERM, SEED = 0.3, 1.0, 10000, 1
SPNAME = {'tl': 'tianlinensis', 'cx': 'longibarbatus'}
SINO = ('jii', 'rhinocerous', 'anshuiensis', 'grahami', 'maitianheensis', 'anophthalmus')
OUTGROUPS = ('Cyprinus_carpio', 'Carassius_auratus')
INTACT, LOST, UNCERTAIN = {'FI', 'I', 'PI'}, {'L'}, {'UL'}
MIN_CALLED = {'sino': 3, 'outgroup': 1}


def map_genes(genes, bed):
    out = {}
    for chrom, g in genes.groupby('chr'):
        b = bed[bed['chr'] == chrom]
        if b.empty:
            continue
        bs, be, bid = b['start'].values, b['end'].values, b['id'].values
        for gene, s, e in zip(g['gene'], g['start'].values, g['end'].values):
            ov = np.minimum(be, e) - np.maximum(bs, s)
            k = int(np.argmax(ov))
            if ov[k] > 0 and ov[k] >= 0.3 * (e - s):
                raw = bid[k]
                out[gene] = (raw.replace('lost_', ''), raw.startswith('lost_'))
    return out


def load_status(path):
    d = pd.read_csv(path, sep='\t', dtype=str)
    d = d[d['level'] == 'GENE']
    return dict(zip(d['entry'], d['status']))


def mh_or(lost, grp, strat):
    num = den = 0.0
    for s in np.unique(strat):
        m = strat == s
        a = np.sum(lost[m] & grp[m]); b = np.sum(~lost[m] & grp[m])
        c = np.sum(lost[m] & ~grp[m]); d = np.sum(~lost[m] & ~grp[m])
        n = a + b + c + d
        if n:
            num += a * d / n; den += b * c / n
    return num / den if den else np.nan


def test(df, g1, g2, outcome, rng, n_perm):
    d = df[df['cls'].isin([g1, g2])]
    lost = d[outcome].values.astype(bool)
    grp = (d['cls'] == g1).values
    strat = d['sub'].values
    obs = mh_or(lost, grp, strat)
    null = np.empty(n_perm)
    for k in range(n_perm):
        g = grp.copy()
        for s in np.unique(strat):
            m = np.where(strat == s)[0]
            g[m] = rng.permutation(g[m])
        null[k] = mh_or(lost, g, strat)
    lo, ln = np.log(obs), np.log(null[np.isfinite(null) & (null > 0)])
    p = (np.sum(np.abs(ln - np.median(ln)) >= abs(lo - np.median(ln))) + 1) / (len(ln) + 1) if np.isfinite(lo) else np.nan
    return obs, p


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    ap.add_argument('--toga', default=os.environ.get('TOGA2_DIR', 'toga2'))
    ap.add_argument('--perm', type=int, default=N_PERM)
    ap.add_argument('--exclude', nargs='*', default=[], help='genomes to leave out, e.g. maitianheensis')
    ap.add_argument('--tag', default='', help='suffix for output files')
    a = ap.parse_args()
    rng = np.random.default_rng(SEED)

    status, gset = {}, {}
    for name in SINO + OUTGROUPS:
        if name in a.exclude:
            continue
        for sub in 'AB':
            f = f'{a.toga}/results/{name}_{sub}/loss_summary.tsv'
            if not os.path.exists(f):
                print(f'WARNING: missing {f}')
                continue
            status[(name, sub)] = load_status(f)
            gset[name] = 'outgroup' if name in OUTGROUPS else 'sino'
    for s in ('sino', 'outgroup'):
        print(f'{s}: ' + ', '.join(sorted(n for n, v in gset.items() if v == s)))

    pairs = pd.read_csv(f'{a.base}/analysis/methexpr_pairs.tsv.gz', sep='\t', dtype={'individual': str})
    pairs = pairs[pairs['individual'] == 'pooled']
    rows, copies = [], []
    for sp in ('tl', 'cx'):
        genes = pd.read_csv(f'{a.base}/homoeolog/{sp}/{sp}.genes.tsv', sep='\t')
        gmap = {}
        for sub in 'AB':
            bed = pd.read_csv(f'{a.toga}/export/gene_bed_std/{SPNAME[sp]}_{sub}.gene.std.bed4', sep='\t',
                              header=None, names=['chr', 'start', 'end', 'id'], dtype={'id': str})
            gmap.update(map_genes(genes[genes['sub'] == sub], bed))
        for tissue in ('eye', 'liver'):
            d = pairs[(pairs['species'] == sp) & (pairs['tissue'] == tissue)]
            zA = d['A_gene'].map(lambda g: gmap.get(g, (None, None))[0])
            zB = d['B_gene'].map(lambda g: gmap.get(g, (None, None))[0])
            ok = zA.notna() & (zA == zB)
            print(f'[{sp} {tissue}] pairs {len(d)}; both copies mapped {int((zA.notna() & zB.notna()).sum())}; '
                  f'same zebrafish GeneID {int(ok.sum())}')
            d = d[ok].assign(zid=zA[ok])
            for _, r in d.iterrows():
                dm, fc = r['dMeth'], r['log2FC']
                for sub, gene in (('A', r['A_gene']), ('B', r['B_gene'])):
                    lower = (fc >= T_FC) if sub == 'A' else (fc <= -T_FC)
                    higher = (fc <= -T_FC) if sub == 'A' else (fc >= T_FC)
                    more_meth = (dm <= -T_METH) if sub == 'A' else (dm >= T_METH)
                    cls = 'balanced' if abs(fc) < T_FC else ('repressed' if lower and more_meth else
                                                             'lower_only' if lower else 'higher' if higher else 'other')
                    c = dict(species=sp, tissue=tissue, sub=sub, gene=gene, zid=r['zid'], cls=cls,
                             self_lost=int(gmap[gene][1]))
                    for s in ('sino', 'outgroup'):
                        st = [status[(n, sub)].get(r['zid']) for n in gset if gset[n] == s and (n, sub) in status]
                        c[f'{s}_called'] = sum(x in INTACT | LOST for x in st)
                        c[f'{s}_lost'] = sum(x in LOST for x in st)
                        c[f'{s}_called_ul'] = sum(x in INTACT | LOST | UNCERTAIN for x in st)
                        c[f'{s}_lost_ul'] = sum(x in LOST | UNCERTAIN for x in st)
                    copies.append(c)

    cp = pd.DataFrame(copies)
    os.makedirs(f'{a.base}/analysis', exist_ok=True)
    cp.to_csv(f'{a.base}/analysis/toga_copies{a.tag}.tsv.gz', sep='\t', index=False)
    print('\nspecies\ttissue\tgenomes\tdef\tclass\tn\tlost_any\trate_A\trate_B')
    for (sp, tissue), d in cp.groupby(['species', 'tissue'], sort=False):
        for s in ('sino', 'outgroup'):
            for tag, called, lost in (('L', f'{s}_called', f'{s}_lost'), ('L+UL', f'{s}_called_ul', f'{s}_lost_ul')):
                dd = d[d[called] >= MIN_CALLED[s]].copy()
                dd['lost_any'] = dd[lost] > 0
                for cls in ('repressed', 'lower_only', 'balanced', 'higher'):
                    x = dd[dd['cls'] == cls]
                    rA = x[x['sub'] == 'A']['lost_any'].mean(); rB = x[x['sub'] == 'B']['lost_any'].mean()
                    print(f'{sp}\t{tissue}\t{s}\t{tag}\t{cls}\t{len(x)}\t{int(x["lost_any"].sum())}\t{rA:.3f}\t{rB:.3f}')
                for g1, g2 in (('repressed', 'balanced'), ('lower_only', 'balanced'), ('repressed', 'lower_only')):
                    orr, p = test(dd, g1, g2, 'lost_any', rng, a.perm)
                    rows.append(dict(species=sp, tissue=tissue, genomes=s, loss_def=tag, contrast=f'{g1}_vs_{g2}',
                                     n1=int((dd['cls'] == g1).sum()), n2=int((dd['cls'] == g2).sum()),
                                     MH_OR=round(orr, 3), perm_p=f'{p:.2e}'))
            sl = d.groupby('cls')['self_lost'].agg(['sum', 'count'])
            if s == 'sino':
                print(f'{sp}\t{tissue}\tself_lost (TOGA2 calls the copy lost in {sp} itself): ' +
                      ', '.join(f'{k} {int(v["sum"])}/{int(v["count"])}' for k, v in sl.iterrows()))
    res = pd.DataFrame(rows)
    res.to_csv(f'{a.base}/analysis/toga_loss_tests{a.tag}.tsv', sep='\t', index=False)
    print('\n' + res.to_string(index=False))
    print(f'-> {a.base}/analysis/toga_loss_tests{a.tag}.tsv, toga_copies{a.tag}.tsv.gz')


if __name__ == '__main__':
    main()
