#!/usr/bin/env python3
import argparse, os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from meth_tools import load_regions, load_cov

NON_TE = ('Simple_repeat', 'Low_complexity', 'Satellite', 'rRNA', 'snRNA', 'tRNA', 'scRNA', 'srpRNA')
N_BOOT, SEED, MIN_TE = 200, 1, 200


def bins(start, end, strand, flank, nf, nb):
    s, e = np.asarray(start, np.int64)[:, None], np.asarray(end, np.int64)[:, None]
    w, L = flank // nf, e - s + 1
    i, j = np.arange(nf)[None], np.arange(nb)[None]
    fj, fj1 = (L * j) // nb, (L * (j + 1)) // nb
    plus = (s - flank + i * w, s - flank + (i + 1) * w - 1, s + fj, s + fj1 - 1, e + 1 + i * w, e + (i + 1) * w)
    minus = (e + flank - (i + 1) * w + 1, e + flank - i * w, e - fj1 + 1, e - fj, s - (i + 1) * w, s - i * w - 1)
    mk = (np.asarray(strand) == '-')[:, None]
    S = np.concatenate([np.where(mk, minus[k], plus[k]) for k in (0, 2, 4)], axis=1)
    E = np.concatenate([np.where(mk, minus[k], plus[k]) for k in (1, 3, 5)], axis=1)
    return np.maximum(S, 1), np.maximum(E, 0)


def bin_sums(cov, chrom, S, E):
    m = np.zeros(S.shape, np.int64)
    t = np.zeros(S.shape, np.int64)
    for c in np.unique(chrom):
        if c not in cov:
            continue
        pos, cm, ct = cov[c]
        k = chrom == c
        i0 = np.searchsorted(pos, S[k], 'left')
        i1 = np.searchsorted(pos, E[k], 'right')
        m[k] = cm[i1] - cm[i0]
        t[k] = ct[i1] - ct[i0]
    return m, t


def summarise(m, t, rng):
    lev = m.sum(0) / np.maximum(t.sum(0), 1)
    mf, tf = m.astype(np.float32), t.astype(np.float32)
    boot = np.empty((N_BOOT, m.shape[1]), np.float32)
    for b in range(N_BOOT):
        w = rng.poisson(1.0, m.shape[0]).astype(np.float32)
        boot[b] = (w @ mf) / np.maximum(w @ tf, 1)
    return lev, np.percentile(boot, 2.5, axis=0), np.percentile(boot, 97.5, axis=0), (t > 0).sum(0)


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    a = ap.parse_args()
    B, rng = a.base, np.random.default_rng(SEED)
    rows = []
    for sp in ('tl', 'cx'):
        reg = load_regions(f'{B}/{sp}_AB.gff', f'{B}/homoeolog/{sp}/{sp}.genes.tsv', 2000)
        m = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
        m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)]
        reg = reg[reg['gene'].isin(set(m['A_gene']) | set(m['B_gene']))].reset_index(drop=True)
        gS, gE = bins(reg['b_start'], reg['b_end'], reg['strand'], 2000, 20, 20)
        te = pd.read_csv(f'{B}/te_tad/{sp}/renamed/{sp}.TE.gff', sep='\t', header=None, usecols=[0, 2, 3, 4, 6],
                         names=['chr', 'cls', 's', 'e', 'strand'], dtype={'chr': str, 'cls': str, 'strand': str},
                         comment='#')
        te = te[~te['cls'].str.startswith(NON_TE) & (te['e'] - te['s'] + 1 >= MIN_TE)].reset_index(drop=True)
        te['sub'] = te['chr'].str.extract(r'^chr([AB])\d+$', expand=False)
        te = te[te['sub'].notna()].reset_index(drop=True)
        tS, tE = bins(te['s'], te['e'], te['strand'], 1000, 10, 20)
        near = np.zeros(len(te), bool)
        for c, g in reg.groupby('chr'):
            iv = sorted(zip(g['b_start'] - 2000, g['b_end'] + 2000))
            ms, me = [], []
            for a0, a1 in iv:
                if ms and a0 <= me[-1]:
                    me[-1] = max(me[-1], a1)
                else:
                    ms.append(a0); me.append(a1)
            ms, me = np.array(ms), np.array(me)
            k = np.where(te['chr'].values == c)[0]
            j = np.searchsorted(ms, te['e'].values[k], 'right') - 1
            near[k] = (j >= 0) & (me[np.maximum(j, 0)] >= te['s'].values[k])
        te['near'] = near
        print(f'[{sp}] genes {len(reg)} (A {int((reg["sub"] == "A").sum())}, B {int((reg["sub"] == "B").sum())}); '
              f'TE copies >= {MIN_TE} bp {len(te)} (A {int((te["sub"] == "A").sum())}, B {int((te["sub"] == "B").sum())}; '
              f'within gene +/- 2 kb {int(near.sum())})',
              flush=True)
        for tissue in ('eye', 'liver'):
            acc = {}
            for rep in (1, 2):
                cov, n = load_cov(f'{B}/wgbs/meth/{sp.upper()}_{tissue}_rep{rep}_pe.deduplicated.bismark.cov.gz')
                for feat, chrom, S, E in (('gene', reg['chr'].values, gS, gE), ('TE', te['chr'].values, tS, tE)):
                    mm, tt = bin_sums(cov, chrom, S, E)
                    if feat in acc:
                        acc[feat][0] += mm; acc[feat][1] += tt
                    else:
                        acc[feat] = [mm, tt]
                del cov
            acc['TE_2kb'] = [acc['TE'][0][near], acc['TE'][1][near]]
            for feat, subs in (('gene', reg['sub'].values), ('TE', te['sub'].values), ('TE_2kb', te['sub'].values[near])):
                nf = 20 if feat == 'gene' else 10
                region = ['upstream'] * nf + ['body'] * 20 + ['downstream'] * nf
                for s in 'AB':
                    k = subs == s
                    lev, lo, hi, nfe = summarise(acc[feat][0][k], acc[feat][1][k], rng)
                    for i in range(len(region)):
                        rows.append(dict(species=sp, tissue=tissue, feature=feat, sub=s, bin=i, region=region[i],
                                         level=round(float(lev[i]), 5), lo95=round(float(lo[i]), 5),
                                         hi95=round(float(hi[i]), 5), n_features=int(nfe[i]), n_total=int(k.sum())))
                d = pd.DataFrame([r for r in rows if r['species'] == sp and r['tissue'] == tissue and r['feature'] == feat])
                body = d[d['region'] == 'body'].groupby('sub')['level'].mean()
                print(f'[{sp} {tissue}] {feat:<6} mean body level SubA {body["A"]:.3f} SubB {body["B"]:.3f}', flush=True)
    os.makedirs(f'{B}/analysis', exist_ok=True)
    pd.DataFrame(rows).to_csv(f'{B}/analysis/meth_profiles.tsv', sep='\t', index=False)
    print(f'-> {B}/analysis/meth_profiles.tsv')


if __name__ == '__main__':
    main()
