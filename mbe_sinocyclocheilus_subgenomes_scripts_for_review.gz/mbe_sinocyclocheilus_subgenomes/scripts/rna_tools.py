#!/usr/bin/env python3
import argparse, math, os
from collections import defaultdict


def attrs(s):
    d = {}
    for kv in s.strip().strip(';').split(';'):
        if '=' in kv:
            k, v = kv.split('=', 1)
            d[k.strip()] = v.strip()
    return d


def cmd_saf(a):
    m2g, exons, cds = {}, defaultdict(list), defaultdict(list)
    with open(a.gff) as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            p = line.rstrip('\n').split('\t')
            if len(p) < 9:
                continue
            at = attrs(p[8])
            if p[2] in ('mRNA', 'transcript'):
                if at.get('ID') and at.get('Parent'):
                    m2g[at['ID']] = at['Parent'].split(',')[0]
            elif p[2] in ('exon', 'CDS'):
                for par in at.get('Parent', '').split(','):
                    if par:
                        (exons if p[2] == 'exon' else cds)[par].append((p[0], int(p[3]), int(p[4]), p[6]))
    rows, ngene = set(), set()
    for mid, gid in m2g.items():
        feats = exons.get(mid) or cds.get(mid) or []
        for chrom, s, e, strand in feats:
            rows.add((gid, chrom, s, e, strand))
            ngene.add(gid)
    with open(a.out, 'w') as o:
        o.write('GeneID\tChr\tStart\tEnd\tStrand\n')
        for r in sorted(rows, key=lambda x: (x[1], x[2], x[0])):
            o.write('\t'.join(map(str, r)) + '\n')
    print(f'{os.path.basename(a.gff)}: {len(ngene)} genes, {len(rows)} exon intervals -> {a.out}')


def pearson(x, y):
    n = len(x)
    mx, my = sum(x) / n, sum(y) / n
    sxy = sum((i - mx) * (j - my) for i, j in zip(x, y))
    sxx = sum((i - mx) ** 2 for i in x)
    syy = sum((j - my) ** 2 for j in y)
    return sxy / math.sqrt(sxx * syy) if sxx and syy else float('nan')


def cmd_tpm(a):
    sheet = {}
    with open(a.samples) as f:
        head = f.readline().rstrip('\n').split('\t')
        for l in f:
            r = dict(zip(head, l.rstrip('\n').split('\t')))
            if r['species'] == a.sp:
                sheet[f"{a.sp}_{r['sample']}.bam"] = (r['sample'], r['tissue'])
    with open(a.fc) as f:
        lines = [l.rstrip('\n').split('\t') for l in f if not l.startswith('#')]
    head, body = lines[0], lines[1:]
    bams = [os.path.basename(x) for x in head[6:]]
    ids = [sheet[b][0] for b in bams]
    tissue = {sheet[b][0]: sheet[b][1] for b in bams}
    genes = [r[0] for r in body]
    length = [int(r[5]) for r in body]
    counts = [[int(x) for x in r[6:]] for r in body]

    tpm = [[0.0] * len(ids) for _ in genes]
    for j in range(len(ids)):
        rpk = [c[j] / (L / 1000) if L else 0.0 for c, L in zip(counts, length)]
        tot = sum(rpk) / 1e6
        for i, v in enumerate(rpk):
            tpm[i][j] = v / tot if tot else 0.0

    for name, mat, fmt in (('counts', counts, '{}'), ('tpm', tpm, '{:.4f}')):
        with open(f'{a.out_prefix}.{name}.tsv', 'w') as o:
            o.write('gene\tlength\t' + '\t'.join(ids) + '\n')
            for g, L, row in zip(genes, length, mat):
                o.write(f'{g}\t{L}\t' + '\t'.join(fmt.format(v) for v in row) + '\n')

    print(f'[{a.sp}] {len(genes)} genes x {len(ids)} samples -> {a.out_prefix}.{{counts,tpm}}.tsv')
    print('sample\tassigned_fragments\tgenes_TPM>=1')
    for j, s in enumerate(ids):
        print(f'{s}\t{sum(c[j] for c in counts)}\t{sum(t[j] >= 1 for t in tpm)}')

    by_t = defaultdict(list)
    for j, s in enumerate(ids):
        by_t[tissue[s]].append(j)
    reps = {t: js for t, js in by_t.items() if len(js) > 1}
    if reps:
        print('\nreplicate Pearson r, log2(TPM+1), genes with mean TPM >= 1 in that tissue')
        for t, js in sorted(reps.items()):
            keep = [i for i in range(len(genes)) if sum(tpm[i][j] for j in js) / len(js) >= 1]
            for x in range(len(js)):
                for y in range(x + 1, len(js)):
                    vx = [math.log2(tpm[i][js[x]] + 1) for i in keep]
                    vy = [math.log2(tpm[i][js[y]] + 1) for i in keep]
                    print(f'{t}\t{ids[js[x]]} vs {ids[js[y]]}\tn={len(keep)}\tr={pearson(vx, vy):.3f}')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('saf'); p.add_argument('--gff', required=True); p.add_argument('--out', required=True)
    p = sp.add_parser('tpm'); p.add_argument('--sp', required=True); p.add_argument('--fc', required=True)
    p.add_argument('--samples', required=True); p.add_argument('--out-prefix', required=True)
    a = ap.parse_args()
    {'saf': cmd_saf, 'tpm': cmd_tpm}[a.cmd](a)


if __name__ == '__main__':
    main()
