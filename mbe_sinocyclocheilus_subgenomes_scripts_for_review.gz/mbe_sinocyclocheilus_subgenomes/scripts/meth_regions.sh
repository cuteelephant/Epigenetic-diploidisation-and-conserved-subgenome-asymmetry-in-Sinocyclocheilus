#!/usr/bin/env bash
set -euo pipefail
BASE=$HOME/mbe_review
TOOLS=$(dirname "$(readlink -f "$0")")/meth_tools.py
mkdir -p "$BASE/meth"
for sp in tl cx; do
  SP=${sp^^}
  for t in eye liver; do
    c=$BASE/wgbs/meth/${SP}_${t}
    python3 "$TOOLS" regions --gff "$BASE/${sp}_AB.gff" --genes "$BASE/homoeolog/$sp/$sp.genes.tsv" \
      --cov "${c}_rep1_pe.deduplicated.bismark.cov.gz" "${c}_rep2_pe.deduplicated.bismark.cov.gz" \
      --names rep1 rep2 --out "$BASE/meth/${sp}_${t}.gene_meth.tsv" > "$BASE/meth/${sp}_${t}.log" 2>&1 &
  done
done
wait
for f in "$BASE"/meth/*.log; do echo "== $(basename "$f" .log)"; cat "$f"; done
