#!/usr/bin/env python3
import argparse, gzip, os, sys
from collections import defaultdict
import numpy as np
import pandas as pd
from scipy.stats import hypergeom

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bias_stats import moderated_t, bh

GENOME = {'tl': 'tianlinensis', 'cx': 'longibarbatus'}
MIN_TERM, MAX_TERM, T_FC = 10, 500, 1.0


def go_dag(obo):
    parents, names, ns, cur = defaultdict(set), {}, {}, None
    for ln in open(obo):
        ln = ln.strip()
        if ln == '[Term]':
            cur = None
        elif ln.startswith('id: GO:'):
            cur = ln[4:]
        elif cur and ln.startswith('name: '):
            names[cur] = ln[6:]
        elif cur and ln.startswith('namespace: '):
            ns[cur] = ln[11:]
        elif cur and ln.startswith('is_a: '):
            parents[cur].add(ln[6:16])
        elif cur and ln.startswith('relationship: part_of '):
            parents[cur].add(ln[22:32])
    memo = {}

    def anc(t):
        if t not in memo:
            s = {t}
            for p in parents.get(t, ()):
                s |= anc(p)
            memo[t] = s
        return memo[t]
    return anc, names, ns


def load_go(godir):
    anc, names, ns = go_dag(f'{godir}/go-basic.obo')
    ann = defaultdict(set)
    with gzip.open(f'{godir}/gene2go.gz', 'rt') as f:
        for ln in f:
            if not ln.startswith('7955\t'):
                continue
            p = ln.rstrip('\n').split('\t')
            if p[7] != 'Process' or p[4].startswith('NOT'):
                continue
            ann[p[1]] |= {t for t in anc(p[2]) if ns.get(t) == 'biological_process'}
    sym = {}
    with gzip.open(f'{godir}/Danio_rerio.gene_info.gz', 'rt') as f:
        for ln in f:
            if ln.startswith('7955\t'):
                p = ln.split('\t')
                sym[p[1]] = p[2]
    return ann, names, sym


def zf_map(toga, genome, genes):
    out = {}
    for s in 'AB':
        bed = pd.read_csv(f'{toga}/export/gene_bed_std/{genome}_{s}.gene.std.bed4', sep='\t', header=None,
                          names=['chr', 's', 'e', 'id'], dtype={'chr': str, 'id': str})
        bed = bed[~bed['id'].str.startswith('lost_')]
        g = genes[genes['sub'] == s]
        for c, gg in g.groupby('chr'):
            b = bed[bed['chr'] == c].sort_values('s')
            if b.empty:
                continue
            bs, be, bid = b['s'].values, b['e'].values, b['id'].values
            mx = int((be - bs).max())
            for gene, s0, e0 in zip(gg['gene'], gg['start'], gg['end']):
                i0, i1 = np.searchsorted(bs, s0 - mx), np.searchsorted(bs, e0)
                ov = np.minimum(be[i0:i1], e0) - np.maximum(bs[i0:i1], s0)
                if len(ov) and ov.max() >= 0.3 * (e0 - s0):
                    out[gene] = bid[i0 + int(ov.argmax())]
    return out


def enrich(sel, univ, ann, terms):
    N, n = len(univ), len(sel)
    tid = {t: i for i, t in enumerate(terms)}
    K, k = np.zeros(len(terms), int), np.zeros(len(terms), int)
    for z in univ:
        for t in ann.get(z, ()):
            if t in tid:
                K[tid[t]] += 1
                if z in sel:
                    k[tid[t]] += 1
    ok = (K >= MIN_TERM) & (K <= MAX_TERM)
    p = hypergeom.sf(k - 1, N, K, n)
    d = pd.DataFrame({'term': terms, 'K': K, 'k': k, 'fold': (k / max(n, 1)) / (K / N), 'p': p})[ok]
    d['fdr'] = bh(d['p'].values) if len(d) else []
    return d


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    ap.add_argument('--toga', default=os.environ.get('TOGA2_DIR', 'toga2'))
    a = ap.parse_args()
    B = a.base
    ann, names, sym = load_go(f'{B}/go')
    terms = sorted({t for v in ann.values() for t in v})
    print(f'zebrafish genes with GO BP: {len(ann)}; BP terms: {len(terms)}', flush=True)
    rows = []
    for sp in ('tl', 'cx'):
        genes = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.genes.tsv', sep='\t', dtype={'chr': str})
        zf = zf_map(a.toga, GENOME[sp], genes)
        m = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
        m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)].copy()
        m['zf'] = [zf.get(x) or zf.get(y) for x, y in zip(m['A_gene'], m['B_gene'])]
        print(f'[{sp}] genes mapped to zebrafish {len(zf)}; pairs with a match {m["zf"].notna().sum()} / {len(m)}', flush=True)
        tp = pd.read_csv(f'{B}/rna/counts/{sp}.tpm.tsv', sep='\t').set_index('gene')
        samples = [c for c in tp.columns if c != 'length']
        for tissue in sorted({c.rsplit('_', 1)[0] for c in samples}):
            reps = [c for c in samples if c.rsplit('_', 1)[0] == tissue]
            A, Bm = tp.reindex(m['A_gene'])[reps].values, tp.reindex(m['B_gene'])[reps].values
            ok = (np.maximum(A.mean(1), Bm.mean(1)) >= 1) & m['zf'].notna().values
            r = np.log2((Bm + 1) / (A + 1))[ok]
            if len(reps) >= 2:
                mm, _, p, _ = moderated_t(r)
                sig = bh(p) < 0.05
                b_sel, a_sel = sig & (mm >= T_FC), sig & (mm <= -T_FC)
                mode = 'moderated t FDR<0.05, >=2-fold'
            else:
                mm = r[:, 0]
                b_sel, a_sel, mode = mm >= T_FC, mm <= -T_FC, '>=2-fold (one individual)'
            z = m['zf'].values[ok]
            univ = set(z)
            for direction, sel in (('SubB-biased', b_sel), ('SubA-biased', a_sel)):
                e = enrich(set(z[sel]), univ, ann, terms)
                e.insert(0, 'direction', direction); e.insert(0, 'tissue', tissue); e.insert(0, 'species', sp)
                e['classification'], e['n_selected'], e['n_universe'] = mode, int(sel.sum()), len(univ)
                rows.append(e)
            print(f'[{sp} {tissue}] universe {len(univ)}; SubB-biased {int(b_sel.sum())}, SubA-biased {int(a_sel.sum())}', flush=True)
    t = pd.concat(rows, ignore_index=True)
    t['name'] = t['term'].map(names)
    t.to_csv(f'{B}/analysis/go_enrich.tsv', sep='\t', index=False)
    top = (t[(t['fdr'] < 0.05) & (t['fold'] >= 1.5)].sort_values('fdr')
           .groupby(['species', 'tissue', 'direction']).head(10))
    top.to_csv(f'{B}/analysis/go_enrich_top.tsv', sep='\t', index=False)
    s = t[(t['fdr'] < 0.05) & (t['fold'] >= 1.5)].groupby(['species', 'tissue', 'direction']).size().unstack(fill_value=0)
    print('\nGO BP terms with FDR < 0.05 and fold >= 1.5\n' + s.to_string())
    both = (t[(t['fdr'] < 0.05) & (t['fold'] >= 1.5)].groupby(['tissue', 'direction', 'term'])['species'].nunique())
    both = both[both == 2].reset_index()
    both['name'] = both['term'].map(names)
    print(f'\nterms significant in both species for the same tissue and direction: {len(both)}')
    with pd.option_context('display.width', 200, 'display.max_colwidth', 70):
        print(both[['tissue', 'direction', 'term', 'name']].head(40).to_string(index=False))
    print(f'-> {B}/analysis/go_enrich.tsv, go_enrich_top.tsv')


if __name__ == '__main__':
    main()
