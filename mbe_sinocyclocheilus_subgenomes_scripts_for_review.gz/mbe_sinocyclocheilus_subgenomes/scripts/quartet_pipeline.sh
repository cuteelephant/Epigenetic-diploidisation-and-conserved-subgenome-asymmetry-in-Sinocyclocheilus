#!/usr/bin/env bash
set -euo pipefail
BASE=$HOME/mbe_review
H=$BASE/homoeolog
TOOLS=$(dirname "$(readlink -f "$0")")/quartet_tools.py

case ${1:-} in
orth)
  for S in A B; do
    d=$H/orth_tl_cx_$S; mkdir -p "$d"
    for sp in tl cx; do for ext in bed cds; do ln -sf "$H/$sp/$sp$S.$ext" "$d/$sp$S.$ext"; done; done
    (
      cd "$d"
      python3 -m jcvi.compara.catalog ortholog "tl$S" "cx$S" --cscore=.99 --no_strip_names > jcvi.log 2>&1 || true
      [ -s "tl$S.cx$S.anchors" ] || { echo "[$S] JCVI produced no anchors; see $d/jcvi.log"; exit 1; }
      python3 "$TOOLS" orth --anchors "tl$S.cx$S.anchors" --out "$H/orth_tl_cx_$S.tsv"
    )
  done
  ;;
analyze)
  python3 "$TOOLS" analyze --pairs "$BASE/analysis/methexpr_pairs.tsv.gz" \
    --orth-a "$H/orth_tl_cx_A.tsv" --orth-b "$H/orth_tl_cx_B.tsv" --outdir "$BASE/analysis"
  ;;
*)
  echo "Usage: bash $0 {orth|analyze}"; exit 1 ;;
esac
