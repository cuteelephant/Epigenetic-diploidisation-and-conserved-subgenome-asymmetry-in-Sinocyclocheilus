#!/usr/bin/env bash
set -euo pipefail
BASE=$HOME/mbe_review
H=$BASE/homoeolog
OUT=$BASE/te_polar
TOOLS=$(dirname "$(readlink -f "$0")")
THREADS=${THREADS:-32}
YN00=${YN00:-yn00}
MU=3.51e-9
mkdir -p "$OUT"

case ${1:-} in
check)
  for t in minimap2 "$YN00" python3; do printf '%-9s %s\n' "$t" "$(command -v "$t" || echo MISSING)"; done
  minimap2 --version 2>/dev/null || true
  for sp in tl cx; do ls -lh "$BASE/${sp}_AB.fa" "$BASE/te_tad/$sp/renamed/$sp.TE.gff"; done
  for S in A B; do ls -lh "$H/orth_tl_cx_$S.tsv" "$H/tl/tl$S.cds" "$H/cx/cx$S.cds"; done
  free -g | head -2
  ;;
orthks)
  for S in A B; do
    awk 'BEGIN{OFS="\t"; print "A_gene","B_gene"} NR>1{print $1,$2}' "$H/orth_tl_cx_$S.tsv" > "$OUT/orth_$S.pairs.tsv"
    python3 "$TOOLS/homoeolog_tools.py" ks --sp "tl_cx_$S" --pairs "$OUT/orth_$S.pairs.tsv" \
      --cds-a "$H/tl/tl$S.cds" --cds-b "$H/cx/cx$S.cds" --yn00 "$(command -v "$YN00")" --threads "$THREADS" \
      --out "$OUT/orth_$S.ks.tsv"
  done
  python3 - "$OUT" "$MU" <<'EOF'
import sys
import numpy as np, pandas as pd
out, mu = sys.argv[1], float(sys.argv[2])
rows = []
for S in 'AB':
    d = pd.read_csv(f'{out}/orth_{S}.ks.tsv', sep='\t')
    for c in ('Ks_YN00', 'cov', 'aln_codons'):
        d[c] = pd.to_numeric(d[c], errors='coerce')
    q = d[(d['status'] == 'ok') & (d['cov'] >= 0.5) & (d['aln_codons'] >= 50) & (d['Ks_YN00'] >= 0) & (d['Ks_YN00'] < 3)]
    k = q['Ks_YN00'].values
    if not len(k):
        print(f'[{S}] no ortholog pair passed QC; status counts: {d["status"].value_counts().to_dict()}')
        continue
    h, e = np.histogram(k[k < 0.2], bins=np.arange(0, 0.2001, 0.005))
    mode = e[h.argmax()] + 0.0025
    rows.append(dict(subgenome=S, pairs=len(d), qc_pass=len(q), Ks_median=np.median(k), Ks_q25=np.quantile(k, .25),
                     Ks_q75=np.quantile(k, .75), Ks_mode=mode, share_Ks0=np.mean(k < 0.001),
                     T_split_Ma_median=np.median(k) / (2 * mu) / 1e6, T_split_Ma_mode=mode / (2 * mu) / 1e6))
    print(f'Ks histogram, tl{S}-cx{S} orthologs (QC pass, Ks < 0.2)')
    for x, n in zip(e[:-1], h):
        print(f'  {x:.3f} {n:6d} ' + '#' * int(60 * n / h.max()))
t = pd.DataFrame(rows).round(4)
t.to_csv(f'{out}/orth_ks_summary.tsv', sep='\t', index=False)
print(t.to_string(index=False))
print(f'mu = {mu}; T = Ks / (2 mu) -> {out}/orth_ks_summary.tsv')
EOF
  ;;
align)
  for q in tl cx; do
    t=$([ "$q" = tl ] && echo cx || echo tl)
    if [ -s "$OUT/${q}_to_$t.paf" ]; then echo "[$q] $OUT/${q}_to_$t.paf exists, skipped"; continue; fi
    minimap2 -cx asm10 --cs --secondary=no -t "$THREADS" "$BASE/${t}_AB.fa" "$BASE/${q}_AB.fa" \
      > "$OUT/${q}_to_$t.paf.tmp" 2> "$OUT/${q}_to_$t.log"
    mv "$OUT/${q}_to_$t.paf.tmp" "$OUT/${q}_to_$t.paf"
    awk -v q="$q" '$12 >= 1 && /tp:A:P/ {n++; al += $4 - $3; m += $10; b += $11; if ($1 == $6) same += $4 - $3}
      END {printf "[%s] primary alignments %d; aligned query %.1f Mb; same-named target chromosome %.1f%%; identity %.4f\n",
           q, n, al / 1e6, 100 * same / al, m / b}' "$OUT/${q}_to_$t.paf"
  done
  ;;
*)
  echo "Usage: bash $0 {check|orthks|align}"; exit 1 ;;
esac
