#!/usr/bin/env python3
import argparse, os
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

N_BOOT, SEED, T_METH, T_FC = 2000, 1, 0.3, 1.0


def load_orth(path):
    d = pd.read_csv(path, sep='\t')
    for c in ('Ka_YN00', 'Ks_YN00', 'S', 'N', 'cov', 'aln_codons'):
        d[c] = pd.to_numeric(d[c], errors='coerce')
    d = d[(d['status'] == 'ok') & (d['cov'] >= 0.5) & (d['aln_codons'] >= 50) & (d['Ks_YN00'] < 0.5) &
          (d['Ka_YN00'] < 0.5)].dropna(subset=['Ka_YN00', 'Ks_YN00', 'S', 'N'])
    return d.rename(columns={'A_gene': 'tl', 'B_gene': 'cx'})[['tl', 'cx', 'Ka_YN00', 'Ks_YN00', 'S', 'N']]


def agg(ka, ks, s, n):
    return (np.sum(ka * n) / np.sum(n)) / (np.sum(ks * s) / np.sum(s))


def compare(q, x, y, label, rng):
    if len(q) < 20:
        return None
    cols = [f'{p}_{v}' for p in (x, y) for v in ('Ka_YN00', 'Ks_YN00', 'S', 'N')]
    M = q[cols].values
    wx, wy = agg(*M[:, 0:4].T), agg(*M[:, 4:8].T)
    boot = np.empty(N_BOOT)
    n = len(q)
    for b in range(N_BOOT):
        i = rng.integers(0, n, n)
        boot[b] = agg(*M[i, 0:4].T) / agg(*M[i, 4:8].T)
    dka = q[f'{x}_Ka_YN00'] - q[f'{y}_Ka_YN00']
    dks = q[f'{x}_Ks_YN00'] - q[f'{y}_Ks_YN00']
    return dict(comparison=label, n_quartets=n, omega_1=round(wx, 4), omega_2=round(wy, 4),
                ratio=round(wx / wy, 3), ratio_lo95=round(np.percentile(boot, 2.5), 3),
                ratio_hi95=round(np.percentile(boot, 97.5), 3),
                p_boot=round(min(1.0, 2 * min((boot <= 1).mean(), (boot >= 1).mean())), 4),
                median_dKa=round(float(np.median(dka)), 5), p_Ka=wilcoxon(dka).pvalue if (dka != 0).any() else np.nan,
                median_dKs=round(float(np.median(dks)), 5), p_Ks=wilcoxon(dks).pvalue if (dks != 0).any() else np.nan)


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    a = ap.parse_args()
    B, rng = a.base, np.random.default_rng(SEED)
    oa, ob = load_orth(f'{B}/te_polar/orth_A.ks.tsv'), load_orth(f'{B}/te_polar/orth_B.ks.tsv')
    m = {sp: pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
         for sp in ('tl', 'cx')}
    m = {sp: d[(d['qc_ks'] == 1) & (d['same_chr_number'] == 1)][['A_gene', 'B_gene']] for sp, d in m.items()}
    q = m['tl'].rename(columns={'A_gene': 'tlA', 'B_gene': 'tlB'})
    q = q.merge(oa.add_prefix('A_').rename(columns={'A_tl': 'tlA', 'A_cx': 'cxA'}), on='tlA')
    q = q.merge(ob.add_prefix('B_').rename(columns={'B_tl': 'tlB', 'B_cx': 'cxB'}), on='tlB')
    q = q.merge(m['cx'].rename(columns={'A_gene': 'cxA', 'B_gene': 'cxB'}), on=['cxA', 'cxB'])
    print(f'quartets with QC-passing SubA and SubB ortholog comparisons: {len(q)} '
          f'(SubA orthologs {len(oa)}, SubB orthologs {len(ob)})')
    rows = []
    r = compare(q, 'B', 'A', 'SubB vs SubA (all quartets)', rng)
    r.update(tissue='all', set='all')
    rows.append(r)
    print(f"SubA dN {np.sum(q['A_Ka_YN00'] * q['A_N']) / q['A_N'].sum():.5f} dS {np.sum(q['A_Ks_YN00'] * q['A_S']) / q['A_S'].sum():.5f}; "
          f"SubB dN {np.sum(q['B_Ka_YN00'] * q['B_N']) / q['B_N'].sum():.5f} dS {np.sum(q['B_Ks_YN00'] * q['B_S']) / q['B_S'].sum():.5f}")

    pairs = pd.read_csv(f'{B}/analysis/methexpr_pairs.tsv.gz', sep='\t', dtype={'individual': str, 'HE': str})
    pairs = pairs[pairs['individual'] == 'pooled']
    for tissue in ('eye', 'liver'):
        e = {sp: pairs[(pairs['species'] == sp) & (pairs['tissue'] == tissue)][['A_gene', 'B_gene', 'log2FC', 'dMeth']]
             for sp in ('tl', 'cx')}
        x = q.merge(e['tl'].rename(columns={'A_gene': 'tlA', 'B_gene': 'tlB', 'log2FC': 'fc_tl', 'dMeth': 'dm_tl'}),
                    on=['tlA', 'tlB'])
        x = x.merge(e['cx'].rename(columns={'A_gene': 'cxA', 'B_gene': 'cxB', 'log2FC': 'fc_cx', 'dMeth': 'dm_cx'}),
                    on=['cxA', 'cxB'])
        def oriented(sel, sub_is_A):
            y = x[sel].copy()
            for v in ('Ka_YN00', 'Ks_YN00', 'S', 'N'):
                y[f'S_{v}'] = np.where(sub_is_A[sel], y[f'A_{v}'], y[f'B_{v}'])
                y[f'D_{v}'] = np.where(sub_is_A[sel], y[f'B_{v}'], y[f'A_{v}'])
            return y
        bothB = (x['fc_tl'] >= T_FC) & (x['fc_cx'] >= T_FC)
        bothA = (x['fc_tl'] <= -T_FC) & (x['fc_cx'] <= -T_FC)
        sel = (bothA | bothB).values
        for label, s_ in (('submissive vs dominant copy (same bias in both species)', sel),
                          ('  of which SubA submissive', bothB.values), ('  of which SubB submissive', bothA.values)):
            r = compare(oriented(s_, bothB.values), 'S', 'D', label, rng)
            if r:
                r.update(tissue=tissue, set='biased_both')
                rows.append(r)
        cand = lambda dm, fc: np.where((dm <= -T_METH) & (fc >= T_FC), 'A', np.where((dm >= T_METH) & (fc <= -T_FC), 'B', ''))
        ct, cc = cand(x['dm_tl'], x['fc_tl']), cand(x['dm_cx'], x['fc_cx'])
        subA = bothB.values
        is_c = sel & (((ct == 'A') | (cc == 'A')) & subA | ((ct == 'B') | (cc == 'B')) & ~subA)
        y = oriented(sel, subA)
        flagc = is_c[sel]
        yc, yo = y[flagc], y[~flagc]
        if len(yc) >= 20 and len(yo) >= 20:
            Mc = yc[[f'S_{v}' for v in ('Ka_YN00', 'Ks_YN00', 'S', 'N')]].values
            Mo = yo[[f'S_{v}' for v in ('Ka_YN00', 'Ks_YN00', 'S', 'N')]].values
            wc, wo = agg(*Mc.T), agg(*Mo.T)
            boot = np.array([agg(*Mc[rng.integers(0, len(Mc), len(Mc))].T) / agg(*Mo[rng.integers(0, len(Mo), len(Mo))].T)
                             for _ in range(N_BOOT)])
            rows.append(dict(tissue=tissue, set='biased_both', n_quartets=f'{len(yc)} vs {len(yo)}',
                             comparison='  submissive copy: methylation candidate vs not (unpaired)',
                             omega_1=round(wc, 4), omega_2=round(wo, 4), ratio=round(wc / wo, 3),
                             ratio_lo95=round(np.percentile(boot, 2.5), 3), ratio_hi95=round(np.percentile(boot, 97.5), 3),
                             p_boot=round(min(1.0, 2 * min((boot <= 1).mean(), (boot >= 1).mean())), 4)))
        rep = np.where(ct != '', ct, cc)
        conflict = (ct != '') & (cc != '') & (ct != cc)
        for label, s_ in (('candidate repressed copy vs partner (either species)', (rep != '') & ~conflict),
                          ('  repressed in both species', (ct != '') & (ct == cc)),
                          ('  repressed in one species only', ((ct != '') ^ (cc != ''))),):
            r = compare(oriented(s_, rep == 'A'), 'S', 'D', label, rng)
            if r:
                r.update(tissue=tissue, set='candidate')
                rows.append(r)
    t = pd.DataFrame(rows)[['tissue', 'set', 'comparison', 'n_quartets', 'omega_1', 'omega_2', 'ratio', 'ratio_lo95',
                            'ratio_hi95', 'p_boot', 'median_dKa', 'p_Ka', 'median_dKs', 'p_Ks']]
    os.makedirs(f'{B}/analysis', exist_ok=True)
    t.to_csv(f'{B}/analysis/orth_omega.tsv', sep='\t', index=False)
    with pd.option_context('display.width', 250, 'display.max_columns', 30, 'display.max_colwidth', 60):
        print('\nomega_1 / omega_2 = first vs second copy in "comparison"; ratio CI from bootstrap over quartets')
        print(t.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
    print(f'-> {B}/analysis/orth_omega.tsv')


if __name__ == '__main__':
    main()
