#!/usr/bin/env python3
import argparse
import numpy as np
import pandas as pd


def pc1_chrom(A, gd, ignore_diags=2):
    A = np.array(A, dtype=float)
    n = A.shape[0]
    i, j = np.indices(A.shape)
    A[np.abs(i - j) < ignore_diags] = np.nan
    valid = np.isfinite(A).sum(axis=0) > 0
    out = np.full(n, np.nan)
    if valid.sum() < 10:
        return out, dict(n_bins=n, n_valid=int(valid.sum()), pc=0, r_gene_density=np.nan, eig_frac=np.nan)
    B = A[np.ix_(valid, valid)]
    m = B.shape[0]
    oe = np.full_like(B, np.nan)
    for k in range(m):
        d = np.diagonal(B, k)
        if not np.isfinite(d).any():
            continue
        e = np.nanmean(d)
        if e > 0:
            r = np.arange(m - k)
            oe[r, r + k] = d / e
            oe[r + k, r] = d / e
    hi = np.nanpercentile(oe, 99.9)
    oe = np.minimum(oe, hi)
    oe[~np.isfinite(oe)] = 1.0
    C = np.corrcoef(oe)
    C[~np.isfinite(C)] = 0.0
    vals, vecs = np.linalg.eigh(C)
    order = np.argsort(vals)[::-1]
    g = np.asarray(gd, dtype=float)[valid]
    best, best_r, best_k = None, 0.0, 0
    for k in range(2):
        v = vecs[:, order[k]]
        ok = np.isfinite(g)
        r = np.corrcoef(v[ok], g[ok])[0, 1] if ok.sum() > 2 else 0.0
        if best is None or abs(r) > abs(best_r):
            best, best_r, best_k = v, r, k + 1
    if best_r < 0:
        best, best_r = -best, -best_r
    out[valid] = best
    pos = vals[vals > 0]
    return out, dict(n_bins=n, n_valid=int(valid.sum()), pc=best_k, r_gene_density=round(best_r, 3),
                     eig_frac=round(vals[order[best_k - 1]] / pos.sum(), 3))


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--mcool', required=True)
    ap.add_argument('--res', type=int, default=100000)
    ap.add_argument('--gd', required=True, help='gene-density bedGraph at --res, original chromosome names')
    ap.add_argument('--map', required=True, help='TSV: old_name new_name length status')
    ap.add_argument('--out', required=True)
    ap.add_argument('--qc', required=True)
    ap.add_argument('--coverage-res', type=int, nargs='*', default=[100000, 40000])
    a = ap.parse_args()
    import cooler

    mp = pd.read_csv(a.map, sep='\t', header=None, names=['old', 'new', 'len', 'status'])
    rename = dict(zip(mp['old'], mp['new']))
    gd = pd.read_csv(a.gd, sep='\t', header=None, usecols=[0, 1, 2, 3], names=['chrom', 'start', 'end', 'gd'])
    clr = cooler.Cooler(f'{a.mcool}::resolutions/{a.res}')
    rows, qc = [], []
    for chrom in clr.chromnames:
        if chrom not in rename:
            continue
        bins = clr.bins().fetch(chrom)[['chrom', 'start', 'end']].reset_index(drop=True)
        g = bins.merge(gd[gd['chrom'] == chrom][['start', 'gd']], on='start', how='left')['gd'].values
        v, q = pc1_chrom(clr.matrix(balance=True).fetch(chrom), g)
        bins['chrom'] = rename[chrom]
        bins['PC1'] = v
        rows.append(bins)
        qc.append(dict(chrom_old=chrom, chrom=rename[chrom], **q))
    res = pd.concat(rows)
    res.to_csv(a.out, sep='\t', header=False, index=False, na_rep='NA', float_format='%.5f')
    q = pd.DataFrame(qc)

    cov = []
    for r in a.coverage_res:
        c = cooler.Cooler(f'{a.mcool}::resolutions/{r}')
        per_bin = []
        for chrom in c.chromnames:
            if chrom in rename:
                per_bin.append(np.nansum(c.matrix(balance=False).fetch(chrom), axis=0))
        pb = np.concatenate(per_bin)
        cov.append(f'{r // 1000} kb: median cis contacts per bin {np.median(pb[pb > 0]):.0f}, '
                   f'bins with >= 1000 cis contacts {100 * np.mean(pb >= 1000):.1f}%')
    with open(a.qc, 'w') as o:
        q.to_csv(o, sep='\t', index=False)
    print(q.to_string(index=False))
    print(f'\nchromosomes {len(q)}; PC2 chosen on {int((q["pc"] == 2).sum())}; '
          f'median r(PC, gene density) {q["r_gene_density"].median():.3f}; '
          f'chromosomes with r < 0.2: {", ".join(q.loc[q["r_gene_density"] < 0.2, "chrom"]) or "none"}')
    print('\n'.join(cov))
    print(f'-> {a.out}, {a.qc}')


if __name__ == '__main__':
    main()
