#!/usr/bin/env python3
import argparse, os, re, sys
from collections import defaultdict
import numpy as np
import pandas as pd
from scipy.stats import binomtest, mannwhitneyu, wilcoxon

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from meth_tools import load_regions

NON_TE = ('Simple_repeat', 'Low_complexity', 'Satellite', 'rRNA', 'snRNA', 'tRNA', 'scRNA', 'srpRNA')
FLANK, PAD, MU, T_METH, T_FC = 2000, 100, 3.51e-9, 0.3, 1.0
OTHER = {'tl': 'cx', 'cx': 'tl'}
CS = re.compile(r':(\d+)|\*[a-z]([a-z])|\+([a-z]+)|-([a-z]+)')
K_RE = re.compile(r'KIMURA80=([0-9.eE+-]+)')


def read_te(path):
    te = pd.read_csv(path, sep='\t', header=None, usecols=[0, 2, 3, 4, 8], names=['chr', 'cls', 's', 'e', 'att'],
                     dtype={'chr': str, 'cls': str, 's': np.int64, 'e': np.int64, 'att': str})
    te = te[~te['cls'].str.startswith(NON_TE)].copy()
    te['s0'] = te['s'] - 1
    te['K'] = te['att'].str.extract(K_RE, expand=False).astype(float)
    te['fam'] = te['att'].str.extract(r'ID=([^;]+)', expand=False)
    te['top'] = te['cls'].str.split('/').str[0]
    return te.drop(columns=['att', 's']).reset_index(drop=True)


def merged(s, e):
    o = np.argsort(s)
    s, e = s[o], e[o]
    out = []
    for a, b in zip(s, e):
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    a = np.array(out, dtype=np.int64).reshape(-1, 2)
    return a[:, 0], a[:, 1], np.concatenate([[0], np.cumsum(a[:, 1] - a[:, 0])])


def covered(m, x):
    S, E, CL = m
    k = np.searchsorted(S, x, 'right')
    out = np.zeros(len(x), dtype=np.int64)
    ok = k > 0
    kk = k[ok] - 1
    out[ok] = CL[kk] + np.minimum(E[kk], x[ok]) - S[kk]
    return out


def flanks(base, sp):
    m = pd.read_csv(f'{base}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
    m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)]
    keep = set(m['A_gene']) | set(m['B_gene'])
    reg = load_regions(f'{base}/{sp}_AB.gff', f'{base}/homoeolog/{sp}/{sp}.genes.tsv', FLANK)
    reg = reg[reg['gene'].isin(keep)].reset_index(drop=True)
    plus = reg['strand'] == '+'
    up = pd.DataFrame({'gene': reg['gene'], 'chr': reg['chr'], 'side': 'up',
                       'a': reg['p_start'] - 1, 'b': reg['p_end']})
    dn = pd.DataFrame({'gene': reg['gene'], 'chr': reg['chr'], 'side': 'down',
                       'a': np.where(plus, reg['b_end'], np.maximum(0, reg['b_start'] - 1 - FLANK)),
                       'b': np.where(plus, reg['b_end'] + FLANK, reg['b_start'] - 1)})
    return pd.concat([up, dn], ignore_index=True)


def lift(paf, pts_by_chr):
    best = {}
    with open(paf) as f:
        for ln in f:
            p = ln.rstrip('\n').split('\t')
            if len(p) < 12 or p[0] != p[5] or 'tp:A:P' not in p[12:]:
                continue
            pts = pts_by_chr.get(p[0])
            if pts is None:
                continue
            qs, qe, strand, ts, mt = int(p[2]), int(p[3]), p[4], int(p[7]), int(p[9])
            i0, i1 = np.searchsorted(pts, qs, 'left'), np.searchsorted(pts, qe, 'left')
            if i1 <= i0:
                continue
            cs = next((x[5:] for x in p[12:] if x.startswith('cs:Z:')), None)
            if cs is None:
                continue
            order = pts[i0:i1].tolist() if strand == '+' else pts[i0:i1][::-1].tolist()
            q, step, t, k, n_pt = (qs, 1, ts, 0, i1 - i0) if strand == '+' else (qe - 1, -1, ts, 0, i1 - i0)
            for mm in CS.finditer(cs):
                if k >= n_pt:
                    break
                if mm.group(1):
                    n = int(mm.group(1))
                    while k < n_pt and (order[k] - q) * step < n:
                        pos = order[k]
                        if mt > best.get((p[0], pos), (0, -1))[0]:
                            best[(p[0], pos)] = (mt, t + (pos - q) * step)
                        k += 1
                    q += step * n
                    t += n
                elif mm.group(2):
                    if k < n_pt and order[k] == q:
                        pos = order[k]
                        if mt > best.get((p[0], pos), (0, -1))[0]:
                            best[(p[0], pos)] = (mt, t)
                        k += 1
                    q += step
                    t += 1
                elif mm.group(3):
                    n = len(mm.group(3))
                    while k < n_pt and (order[k] - q) * step < n:
                        k += 1
                    q += step * n
                else:
                    t += len(mm.group(4))
    return best


def cmd_polar(a):
    for sp in a.sp:
        o = OTHER[sp]
        fl = flanks(a.base, sp)
        te = read_te(f'{a.base}/te_tad/{sp}/renamed/{sp}.TE.gff')
        k25 = float(np.nanquantile(te['K'], 0.25))
        hits = []
        for c, g in fl.groupby('chr'):
            t = te[te['chr'] == c]
            if not len(t):
                continue
            o_ = np.argsort(t['s0'].values)
            S, E, I = t['s0'].values[o_], t['e'].values[o_], t.index.values[o_]
            ml = int((E - S).max())
            for gene, side, x, y in zip(g['gene'], g['side'], g['a'], g['b']):
                i0, i1 = np.searchsorted(S, x - ml, 'left'), np.searchsorted(S, y, 'left')
                j = np.nonzero(E[i0:i1] > x)[0] + i0
                hits += [(gene, side, int(i)) for i in I[j]]
        h = pd.DataFrame(hits, columns=['gene', 'side', 'te'])
        u = te.loc[np.unique(h['te'])]
        print(f'[{sp}] flank regions {len(fl)}; TE copies overlapping them {len(u)} (gene-side-TE rows {len(h)}); '
              f'young TE = K < {k25:.4f}', flush=True)
        pl, pr = u['s0'].values - PAD, u['e'].values - 1 + PAD
        pts = defaultdict(list)
        for c, x, y in zip(u['chr'], pl, pr):
            if x >= 0:
                pts[c] += [x, y]
        pts = {c: np.unique(np.array(v, dtype=np.int64)) for c, v in pts.items()}
        best = lift(f'{a.base}/te_polar/{sp}_to_{o}.paf', pts)
        print(f'[{sp}] lifted {len(best)} of {sum(len(v) for v in pts.values())} flank points to {o}', flush=True)
        ot = read_te(f'{a.base}/te_tad/{o}/renamed/{o}.TE.gff')
        cov = {k: merged(g['s0'].values, g['e'].values) for k, g in ot.groupby(['chr', 'top'])}
        status, dt = [], []
        for c, x, y, L, top in zip(u['chr'], pl, pr, u['e'].values - u['s0'].values, u['top']):
            bl, br = best.get((c, int(x))), best.get((c, int(y)))
            if x < 0 or bl is None or br is None:
                status.append('unresolved'); dt.append(np.nan)
                continue
            d = abs(br[1] - bl[1]) + 1
            dt.append(d)
            if d <= 2 * PAD + max(0.2 * L, 20):
                status.append('specific')
            elif abs(d - (L + 2 * PAD)) <= max(0.3 * L, 50):
                lo, hi = min(bl[1], br[1]) + PAD, max(bl[1], br[1]) - PAD + 1
                m = cov.get((c, top))
                f = (covered(m, np.array([hi]))[0] - covered(m, np.array([lo]))[0]) / max(hi - lo, 1) if m else 0
                status.append('shared' if f >= 0.5 else 'unresolved')
            else:
                status.append('unresolved')
        u = u.assign(status=status, lifted_dist=dt, young=(u['K'] < k25).astype(int))
        out = h.merge(u[['chr', 's0', 'e', 'cls', 'top', 'fam', 'K', 'young', 'status', 'lifted_dist']],
                      left_on='te', right_index=True)
        out['species'] = sp
        os.makedirs(f'{a.base}/te_polar', exist_ok=True)
        out.to_csv(f'{a.base}/te_polar/{sp}.flank_te.tsv.gz', sep='\t', index=False)
        vc = u['status'].value_counts()
        print(f'[{sp}] flank TE copies: ' + ', '.join(f'{k} {vc.get(k, 0)} ({vc.get(k, 0) / len(u):.1%})'
                                                       for k in ('specific', 'shared', 'unresolved')) +
              f' -> {a.base}/te_polar/{sp}.flank_te.tsv.gz', flush=True)


def gene_flags(ft, k_recent):
    sp = ft['status'] == 'specific'
    x = ft.assign(specific=sp.astype(int), recent=(sp & (ft['K'] < k_recent)).astype(int),
                  shared=(ft['status'] == 'shared').astype(int), any=1)
    g = x.groupby(['gene', 'side'])[['any', 'specific', 'recent', 'shared', 'young']].max()
    return {k: dict(zip(g.columns, v)) for k, v in zip(g.index, g.values.tolist())}


def flag(fl, gene, side, metric):
    return fl.get((gene, side), {}).get(metric, 0)


def cand(dm, fc):
    return ((dm <= -T_METH) & (fc >= T_FC)) | ((dm >= T_METH) & (fc <= -T_FC))


N_BOOT_CI = 2000
_BRNG = np.random.default_rng(20261104)


def _boot_medians(x, n=N_BOOT_CI, chunk=250):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) < 2:
        return np.full(n, np.nan)
    out = np.empty(n)
    for k in range(0, n, chunk):
        m = min(chunk, n - k)
        out[k:k + m] = np.median(x[_BRNG.integers(0, len(x), (m, len(x)))], axis=1)
    return out


def ci_med(x, sign=1):
    b = sign * _boot_medians(x)
    return round(float(np.nanpercentile(b, 2.5)), 4) if np.isfinite(b).any() else np.nan, \
        round(float(np.nanpercentile(b, 97.5)), 4) if np.isfinite(b).any() else np.nan


def ci_diff(x, y, sign=1):
    x, y = np.asarray(x, float), np.asarray(y, float)
    x, y = x[np.isfinite(x)], y[np.isfinite(y)]
    if len(x) < 2 or len(y) < 2:
        return np.nan, np.nan, np.nan
    b = sign * (_boot_medians(x) - _boot_medians(y))
    return (round(float(sign * (np.median(x) - np.median(y))), 4), round(float(np.percentile(b, 2.5)), 4),
            round(float(np.percentile(b, 97.5)), 4))


def dosage_rows(q, tissue, mode, rep, TP):
    ct, cc = cand(q['dMeth_tl'], q['log2FC_tl']).values, cand(q['dMeth_cx'], q['log2FC_cx']).values
    tpm = {}
    for s in ('tl', 'cx'):
        for X in 'AB':
            tpm[(s, X)] = (q[f'tpm_{X}_{s}'].values if rep is None else
                           TP[s][f'{tissue}_{rep}'].reindex(q[f'{X}_gene_{s}']).values)
    lt = {k: np.log2(v + 1) for k, v in tpm.items()}
    T = {s: np.log2(tpm[(s, 'A')] + tpm[(s, 'B')] + 1) for s in ('tl', 'cx')}
    none = ~ct & ~cc & np.isfinite(T['tl']) & np.isfinite(T['cx'])
    out = []
    for g, sel, s, o in (('tl_only', ct & ~cc, 'tl', 'cx'), ('cx_only', cc & ~ct, 'cx', 'tl')):
        sel = sel & np.isfinite(T['tl']) & np.isfinite(T['cx'])
        if sel.sum() < 5:
            continue
        rep_c = np.where(q[f'log2FC_{s}'].values > 0, 'A', 'B')[sel]
        dT, dT0 = (T[s] - T[o])[sel], (T[s] - T[o])[none]
        base = {X: np.median((lt[(s, X)] - lt[(o, X)])[none]) for X in 'AB'}
        d = {X: (lt[(s, X)] - lt[(o, X)])[sel] for X in 'AB'}
        adj_rep = np.where(rep_c == 'A', d['A'] - base['A'], d['B'] - base['B'])
        adj_par = np.where(rep_c == 'A', d['B'] - base['B'], d['A'] - base['A'])
        out.append(dict(tissue=tissue, mode=mode, group=g, n=int(sel.sum()), n_none=int(none.sum()),
                        d_total_median=round(float(np.median(dT)), 4), d_total_none_median=round(float(np.median(dT0)), 4),
                        p_total=mannwhitneyu(dT, dT0).pvalue,
                        d_repressed_vs_none=round(float(np.median(adj_rep)), 4), p_repressed=wilcoxon(adj_rep).pvalue,
                        d_partner_vs_none=round(float(np.median(adj_par)), 4), p_partner=wilcoxon(adj_par).pvalue))
        tdf, tlo, thi = ci_diff(dT, dT0)
        rlo, rhi = ci_med(adj_rep)
        plo, phi = ci_med(adj_par)
        out[-1].update(d_total_diff=tdf, d_total_lo95=tlo, d_total_hi95=thi, d_repressed_lo95=rlo,
                       d_repressed_hi95=rhi, d_partner_lo95=plo, d_partner_hi95=phi)
    return out


def auc(x, y):
    if not len(x) or not len(y):
        return np.nan
    return mannwhitneyu(x, y).statistic / (len(x) * len(y))


def cmd_test(a):
    B = a.base
    ks = pd.read_csv(f'{B}/te_polar/orth_ks_summary.tsv', sep='\t')
    ks_split = float(ks['Ks_median'].mean())
    t_split, k_split = ks_split / (2 * MU), ks_split / 2
    pairs = pd.read_csv(f'{B}/analysis/methexpr_pairs.tsv.gz', sep='\t', dtype={'individual': str, 'HE': str})
    allpairs = pairs
    pairs = pairs[pairs['individual'] == 'pooled']
    FT, FL = {}, {}
    summ = []
    for sp in ('tl', 'cx'):
        ft = pd.read_csv(f'{B}/te_polar/{sp}.flank_te.tsv.gz', sep='\t')
        FT[sp], FL[sp] = ft, gene_flags(ft, ks_split)
        u = ft.drop_duplicates('te')
        Ks_, Ksh = u.loc[u['status'] == 'specific', 'K'].dropna(), u.loc[u['status'] == 'shared', 'K'].dropna()
        for st in ('specific', 'shared', 'unresolved'):
            x = u.loc[u['status'] == st, 'K'].dropna()
            summ.append(dict(species=sp, status=st, n_TE=int((u['status'] == st).sum()),
                             share=round(float((u['status'] == st).mean()), 4), K_median=round(x.median(), 4),
                             K_q10=round(x.quantile(.1), 4), K_q90=round(x.quantile(.9), 4),
                             T_median_Ma=round(x.median() / MU / 1e6, 1),
                             frac_K_below_split=round(float((x < k_split).mean()), 4),
                             frac_K_below_Ks_split=round(float((x < ks_split).mean()), 4),
                             frac_young=round(float(u.loc[u['status'] == st, 'young'].mean()), 4)))
        summ[-3]['AUC_K_shared_gt_specific'] = round(auc(Ksh, Ks_), 4)
    S = pd.DataFrame(summ)
    os.makedirs(f'{B}/analysis', exist_ok=True)
    S.to_csv(f'{B}/analysis/te_polar_summary.tsv', sep='\t', index=False)
    print(f'1. Dating: tl-cx ortholog Ks {ks_split:.4f} -> T_split = Ks/(2 mu) = {t_split / 1e6:.2f} Ma; '
          f'a TE inserted at the split has K ~ mu*T = {k_split:.4f} (T = K/mu); K < Ks_split ({ks_split:.4f}) '
          f'<=> inserted < {ks_split / MU / 1e6:.1f} Ma. recent = specific and K < {ks_split:.4f}')
    print(S.to_string(index=False))

    rows = []
    for sp in ('tl', 'cx'):
        fl = FL[sp]
        for tissue in ('eye', 'liver'):
            d = pairs[(pairs['species'] == sp) & (pairs['tissue'] == tissue) & (pairs['log2FC'].abs() >= T_FC)]
            lo = np.where(d['log2FC'] > 0, d['A_gene'], d['B_gene'])
            hi = np.where(d['log2FC'] > 0, d['B_gene'], d['A_gene'])
            for side in ('up', 'down'):
                for metric in ('any', 'specific', 'recent', 'shared', 'young'):
                    x = np.array([flag(fl, g, side, metric) for g in lo])
                    y = np.array([flag(fl, g, side, metric) for g in hi])
                    b, c = int(((x == 1) & (y == 0)).sum()), int(((x == 0) & (y == 1)).sum())
                    p = binomtest(b, b + c, 0.5).pvalue if b + c else np.nan
                    rows.append(dict(species=sp, tissue=tissue, side=side, metric=metric, n_pairs=len(d),
                                     frac_lower=round(x.mean(), 4), frac_higher=round(y.mean(), 4),
                                     lower_only=b, higher_only=c, paired_OR=round(b / c, 3) if c else np.nan, p=p))
    P2 = pd.DataFrame(rows)
    P2.to_csv(f'{B}/analysis/te_polar_pairs.tsv', sep='\t', index=False)
    print('\n2. Lower- vs higher-expressed copy of biased pairs (|log2FC| >= 1): TE in the 2-kb flank')
    print(P2.to_string(index=False, float_format=lambda v: f'{v:.3g}'))

    oA = dict(pd.read_csv(f'{B}/homoeolog/orth_tl_cx_A.tsv', sep='\t').values)
    oB = dict(pd.read_csv(f'{B}/homoeolog/orth_tl_cx_B.tsv', sep='\t').values)
    qrows, drows, arows = [], [], []
    TP = {sp: pd.read_csv(f'{B}/rna/counts/{sp}.tpm.tsv', sep='\t').set_index('gene') for sp in ('tl', 'cx')}
    q1_by_tissue = {}
    for tissue in ('eye', 'liver'):
        p1 = allpairs[(allpairs['individual'] == '1') & (allpairs['tissue'] == tissue)]
        t1 = p1[p1['species'] == 'tl'].copy()
        t1['cxA'], t1['cxB'] = t1['A_gene'].map(oA), t1['B_gene'].map(oB)
        q1_by_tissue[tissue] = t1.merge(p1[p1['species'] == 'cx'], left_on=['cxA', 'cxB'],
                                        right_on=['A_gene', 'B_gene'], suffixes=('_tl', '_cx'))
    for tissue in ('eye', 'liver'):
        tl = pairs[(pairs['species'] == 'tl') & (pairs['tissue'] == tissue)].copy()
        cx = pairs[(pairs['species'] == 'cx') & (pairs['tissue'] == tissue)]
        tl['cxA'], tl['cxB'] = tl['A_gene'].map(oA), tl['B_gene'].map(oB)
        q = tl.merge(cx, left_on=['cxA', 'cxB'], right_on=['A_gene', 'B_gene'], suffixes=('_tl', '_cx'))
        for side, ins in ((sd, m) for sd in ('up', 'down') for m in ('specific', 'recent')):
            recs = []
            for X in 'AB':
                sgn = 1 if X == 'B' else -1
                it = np.array([flag(FL['tl'], g, side, ins) for g in q[f'{X}_gene_tl']])
                ic = np.array([flag(FL['cx'], g, side, ins) for g in q[f'{X}_gene_cx']])
                st = np.array([flag(FL['tl'], g, side, 'specific') for g in q[f'{X}_gene_tl']])
                sc = np.array([flag(FL['cx'], g, side, 'specific') for g in q[f'{X}_gene_cx']])
                rel_tl, rel_cx = sgn * q['log2FC_tl'].values, sgn * q['log2FC_cx'].values
                mrel_tl, mrel_cx = sgn * q['dMeth_tl'].values, sgn * q['dMeth_cx'].values
                grp = np.where((it == 1) & (ic == 0) & (sc == 0), 'tl_only',
                               np.where((it == 0) & (ic == 1) & (st == 0), 'cx_only',
                                        np.where((st == 0) & (sc == 0), 'none', 'other')))
                recs.append(pd.DataFrame(dict(X=X, grp=grp, d_rel=rel_tl - rel_cx, d_mrel=mrel_tl - mrel_cx,
                                              rel_tl=rel_tl, rel_cx=rel_cx)))
            r = pd.concat(recs, ignore_index=True)
            for X in ('A', 'B', 'pooled'):
                rr = r if X == 'pooled' else r[r['X'] == X]
                none = rr[rr['grp'] == 'none']
                for g, sign in (('tl_only', 1), ('cx_only', -1)):
                    x = rr[rr['grp'] == g]
                    if len(x) < 5:
                        continue
                    other_rel = x['rel_cx'] if g == 'tl_only' else x['rel_tl']
                    base_rel = pd.concat([none['rel_tl'], none['rel_cx']])
                    qrows.append(dict(tissue=tissue, side=side, insertion=ins, subgenome=X, group=g, n=len(x),
                                      n_none=len(none),
                                      d_rel_ins_median=round(sign * x['d_rel'].median(), 4),
                                      d_rel_none_median=round(sign * none['d_rel'].median(), 4),
                                      p_rel=mannwhitneyu(x['d_rel'], none['d_rel']).pvalue,
                                      d_meth_ins_median=round(sign * x['d_mrel'].median(), 4),
                                      p_meth=mannwhitneyu(x['d_mrel'].dropna(), none['d_mrel'].dropna()).pvalue,
                                      rel_without_ins_median=round(other_rel.median(), 4),
                                      rel_none_median=round(base_rel.median(), 4),
                                      p_prior=mannwhitneyu(other_rel, base_rel).pvalue))
                    rdf, rlo, rhi = ci_diff(x['d_rel'], none['d_rel'], sign)
                    mdf, mlo, mhi = ci_diff(x['d_mrel'], none['d_mrel'], sign)
                    qrows[-1].update(d_rel_diff=rdf, d_rel_lo95=rlo, d_rel_hi95=rhi,
                                     d_meth_diff=mdf, d_meth_lo95=mlo, d_meth_hi95=mhi)
        q1 = q1_by_tissue[tissue]
        for mode, qq, meas in (('pooled', q, None), ('indep', q1, '3')):
            if qq is None or not len(qq):
                continue
            drows += dosage_rows(qq, tissue, mode, meas, TP)
        for s in ('tl', 'cx'):
            d = pairs[(pairs['species'] == s) & (pairs['tissue'] == tissue)]
            c = cand(d['dMeth'], d['log2FC'])
            biased = (d['log2FC'].abs() >= T_FC) & ~c
            for name, sel in (('candidate', c), ('biased_not_candidate', biased)):
                x = d[sel]
                lo, hi = np.minimum(x['tpm_A'], x['tpm_B']), np.maximum(x['tpm_A'], x['tpm_B'])
                arows.append(dict(species=s, tissue=tissue, pairs=name, n=int(sel.sum()),
                                  lower_TPM_median=round(lo.median(), 2), higher_TPM_median=round(hi.median(), 2),
                                  frac_lower_below_1TPM=round(float((lo < 1).mean()), 4),
                                  frac_lower_below_0_1TPM=round(float((lo < 0.1).mean()), 4),
                                  lower_share_of_pair_median=round(float((lo / (lo + hi)).median()), 4)))
    Q, D, A = pd.DataFrame(qrows), pd.DataFrame(drows), pd.DataFrame(arows)
    Q.to_csv(f'{B}/analysis/te_polar_quartets.tsv', sep='\t', index=False)
    D.to_csv(f'{B}/analysis/dosage_quartets.tsv', sep='\t', index=False)
    A.to_csv(f'{B}/analysis/dosage_absolute.tsv', sep='\t', index=False)
    with pd.option_context('display.width', 250, 'display.max_columns', 30):
        print('\n3. Quartets: copy with a species-specific flank insertion in one species only vs copies without '
              '(d_* = species with the insertion minus the other; rel_without_ins = copy in the species without it)')
        print(Q[Q['subgenome'] == 'pooled'].to_string(index=False, float_format=lambda v: f'{v:.3g}'))
        print('   (per-subgenome rows in te_polar_quartets.tsv)')
        print('\n4a. Dosage: quartets with a candidate repressed copy in one species only (species with it minus the other)')
        print(D.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
        print('\n4b. Absolute expression of both copies')
        print(A.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
    print(f'-> {B}/analysis/te_polar_summary.tsv, te_polar_pairs.tsv, te_polar_quartets.tsv, dosage_quartets.tsv, '
          f'dosage_absolute.tsv')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('polar'); p.add_argument('--sp', nargs='+', default=['tl', 'cx'], choices=['tl', 'cx'])
    sub.add_parser('test')
    a = ap.parse_args()
    {'polar': cmd_polar, 'test': cmd_test}[a.cmd](a)


if __name__ == '__main__':
    main()
