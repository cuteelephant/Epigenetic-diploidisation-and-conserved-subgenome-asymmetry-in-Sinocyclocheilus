#!/usr/bin/env python3
import argparse, os, shutil, sys
from collections import Counter
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from he_power import params, load_cov, partner_windows, partners, call_all

RUNS = {'tl': 'tl/legacy_tianlinensis', 'cx': 'cx/legacy_longibarbatus'}


def b_span(pw, c, x, y, win):
    hits = [pw[(c, wi)] for wi in range(x // win, y // win) if (c, wi) in pw]
    if not hits:
        return 'NA', -1, -1
    bc = Counter(h[0] for h in hits).most_common(1)[0][0]
    ws = [h[1] for h in hits if h[0] == bc]
    return bc, min(ws) * win, (max(ws) + 1) * win


def annotate(m, reg):
    idx = {}
    for side in 'AB':
        d = reg[reg[f'{side}_chr'] != 'NA']
        idx[side] = {c: (g[f'{side}_start'].values, g[f'{side}_end'].values, g['type'].values)
                     for c, g in d.groupby(f'{side}_chr')}
    out = []
    for r in m.itertuples(index=False):
        h = set()
        for side in 'AB':
            c = getattr(r, f'{side}_chr')
            if c in idx[side]:
                s, e, t = idx[side][c]
                h |= set(t[(s < int(getattr(r, f'{side}_end'))) & (e > int(getattr(r, f'{side}_start')))])
        out.append('+'.join(sorted(h)) if h else 'none')
    return out


def union(a, b):
    h = {x for v in (a, b) if v != 'none' for x in v.split('+')}
    return '+'.join(sorted(h)) if h else 'none'


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--he', default=os.path.expanduser('~/mbe_review/he'))
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    a = ap.parse_args()
    allreg, masters = [], {}
    for sp in ('tl', 'cx'):
        D = f'{a.he}/{RUNS[sp]}/HE_analysis'
        P = params(f'{D}/05_HE/TableS3_parameters.tsv')
        win, fl = int(P['WIN']), float(P['T_B_FLOOR'])
        covA, covB = load_cov(f'{D}/02_cov/omac_to_A.win.bed'), load_cov(f'{D}/02_cov/omac_to_B.win.bed')
        medA = float(np.median(np.concatenate([d[d > 0] for _, d in covA.values()])))
        medB = float(np.median(np.concatenate([d[d > 0] for _, d in covB.values()])))
        pw = partner_windows(f'{D}/04_homoeolog_map/homoeolog_blocks.bed', win)
        part = partners(pw, covA, covB, win)
        ok = {c: np.isfinite(part[c]) & (d > fl) & (part[c] > fl) for c, (_, d) in covA.items()}
        mA = float(np.median(np.concatenate([d[ok[c]] for c, (_, d) in covA.items()])))
        mB = float(np.median(np.concatenate([part[c][ok[c]] for c in covA])))
        sets = [('published', float(P['RATIO_HI']), float(P['RATIO_LO']), medA, medB),
                ('recalibrated', mB / mA, mA / mB, mA, mB)]
        for name, hi, lo, x, y in sets:
            rec = call_all(covA, part, x, y, hi, lo, P)
            for t, c, s0, e0, n in rec:
                bc, bs, be = b_span(pw, c, s0, e0, win)
                allreg.append(dict(species=sp, set=name, type=t, A_chr=c, A_start=s0, A_end=e0, n_windows=n,
                                   B_chr=bc, B_start=bs, B_end=be, HI=round(hi, 3), LO=round(lo, 3)))
            k = Counter(r[0] for r in rec)
            print(f'[{sp}] {name:<12} HI {hi:.3f} LO {lo:.3f}: ' +
                  ', '.join(f'{t} {k.get(t, 0)}' for t in ('B_to_A', 'A_to_B', 'reciprocal')))

        mp = f'{a.base}/homoeolog/{sp}/{sp}.homoeolog_master.tsv'
        bak = f'{a.base}/homoeolog/{sp}/{sp}.homoeolog_master.pre_recal.tsv'
        if not os.path.exists(bak):
            shutil.copy(mp, bak)
        m = pd.read_csv(bak, sep='\t', dtype={'A_chr': str, 'B_chr': str, 'HE': str})
        reg = pd.DataFrame([r for r in allreg if r['species'] == sp and r['set'] == 'recalibrated'])
        m['HE_published'] = m['HE']
        m['HE_recal'] = annotate(m, reg) if len(reg) else 'none'
        m['HE'] = [union(x, y) for x, y in zip(m['HE_published'], m['HE_recal'])]
        m.to_csv(mp, sep='\t', index=False)
        q = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)]
        n = len(q)
        print(f'[{sp}] strict 1:1 pairs {n}: in HE published {(q["HE_published"] != "none").sum()}, '
              f'recalibrated {(q["HE_recal"] != "none").sum()}, union (excluded from noHE) '
              f'{(q["HE"] != "none").sum()} ({(q["HE"] != "none").mean():.1%}) -> {mp}')
        masters[sp] = m

    os.makedirs(f'{a.base}/analysis', exist_ok=True)
    out = f'{a.base}/analysis/he_calls_legacy.tsv'
    R = pd.DataFrame(allreg)
    R['Mb'] = ((R['A_end'] - R['A_start']) / 1e6).round(3)
    R.to_csv(out, sep='\t', index=False)

    op = f'{a.base}/homoeolog/orth_tl_cx_A.tsv'
    if os.path.exists(op):
        o = pd.read_csv(op, sep='\t')
        print('\nB_to_A signatures shared at orthologous SubA genes (genes of strict 1:1 pairs in both species)')
        for col in ('HE_published', 'HE_recal'):
            st = {sp: dict(zip(m['A_gene'], m[col].str.contains('B_to_A'))) for sp, m in masters.items()}
            d = o[o['tl_gene'].isin(st['tl']) & o['cx_gene'].isin(st['cx'])]
            x, y = d['tl_gene'].map(st['tl']).values.astype(bool), d['cx_gene'].map(st['cx']).values.astype(bool)
            orr, p = fisher_exact([[int((x & y).sum()), int((x & ~y).sum())], [int((~x & y).sum()), int((~x & ~y).sum())]])
            print(f'  {col:<13} orthologs {len(d)}; tl B_to_A {x.sum()}, cx B_to_A {y.sum()}, both {(x & y).sum()} '
                  f'({(x & y).sum() / max(x.sum(), 1):.0%} of tl, {(x & y).sum() / max(y.sum(), 1):.0%} of cx; '
                  f'expected {x.sum() * y.mean():.0f}); OR {orr:.1f}, Fisher P {p:.1e}')
    print(f'-> {out}')


if __name__ == '__main__':
    main()
