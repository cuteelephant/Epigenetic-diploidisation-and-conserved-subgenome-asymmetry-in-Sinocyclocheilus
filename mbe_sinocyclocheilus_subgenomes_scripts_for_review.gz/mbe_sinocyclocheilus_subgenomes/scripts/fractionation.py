#!/usr/bin/env python3
import argparse, os
import numpy as np
import pandas as pd
from scipy.stats import binomtest, fisher_exact

FOCAL = {'tianlinensis': 'tl', 'longibarbatus': 'cx'}
SINO = ('jii', 'rhinocerous', 'anshuiensis', 'grahami', 'maitianheensis', 'anophthalmus')
OUTGROUPS = ('Cyprinus_carpio', 'Carassius_auratus')
RET = {'FI', 'I', 'PI'}
MIN_OTHERS = 6


def load(path):
    d = pd.read_csv(path, sep='\t', dtype=str)
    d = d[d['level'] == 'GENE']
    return dict(zip(d['entry'], d['status']))


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--toga', default=os.environ.get('TOGA2_DIR', 'toga2'))
    ap.add_argument('--out', default=os.path.expanduser('~/mbe_review/analysis'))
    ap.add_argument('--exclude', nargs='*', default=[])
    ap.add_argument('--with-ul', action='store_true')
    a = ap.parse_args()
    lost_set = {'L', 'UL'} if a.with_ul else {'L'}
    tag = '_withUL' if a.with_ul else ''
    genomes = [g for g in list(FOCAL) + list(SINO) + list(OUTGROUPS) if g not in a.exclude]
    st = {}
    for g in genomes:
        for s in 'AB':
            st[(g, s)] = load(f'{a.toga}/results/{g}_{s}/loss_summary.tsv')
    cls = lambda x: 'R' if x in RET else ('L' if x in lost_set else None)
    genes = sorted(set().union(*[set(v) for v in st.values()]))
    C = {g: {s: np.array([cls(st[(g, s)].get(z)) for z in genes], dtype=object) for s in 'AB'} for g in genomes}
    os.makedirs(a.out, exist_ok=True)

    rows = []
    for g in genomes:
        A, B = C[g]['A'], C[g]['B']
        ok = (A != None) & (B != None)
        both = int(((A == 'R') & (B == 'R') & ok).sum()); a_only = int(((A == 'R') & (B == 'L')).sum())
        b_only = int(((A == 'L') & (B == 'R')).sum()); none = int(((A == 'L') & (B == 'L')).sum())
        p = binomtest(b_only, a_only + b_only, 0.5).pvalue if a_only + b_only else np.nan
        rows.append(dict(genome=g, called_both=int(ok.sum()), both_retained=both, A_only=a_only, B_only=b_only,
                         both_lost=none, B_share_of_single=round(b_only / max(a_only + b_only, 1), 4), binom_p=f'{p:.2e}'))
    t1 = pd.DataFrame(rows)
    t1.to_csv(f'{a.out}/fractionation_genomes{tag}.tsv', sep='\t', index=False)
    print('1. Genome-wide retention (genes called in both subgenomes)\n' + t1.to_string(index=False))

    print('\n2. Per homoeologous chromosome pair')
    rows = []
    for g, sp in FOCAL.items():
        if g not in genomes:
            continue
        loc = {}
        for s in 'AB':
            bed = pd.read_csv(f'{a.toga}/export/gene_bed_std/{g}_{s}.gene.std.bed4', sep='\t', header=None,
                              names=['chr', 'start', 'end', 'id'], dtype={'id': str})
            bed = bed[~bed['id'].str.startswith('lost_')]
            loc[s] = dict(zip(bed['id'], bed['chr']))
        A, B = C[g]['A'], C[g]['B']
        cnt = {}
        for z, x, y in zip(genes, A, B):
            if x == 'R' and y == 'L' and z in loc['A']:
                k = ('A_only', int(loc['A'][z][4:]))
            elif x == 'L' and y == 'R' and z in loc['B']:
                k = ('B_only', int(loc['B'][z][4:]))
            else:
                continue
            cnt[k] = cnt.get(k, 0) + 1
        pairs = sorted({k[1] for k in cnt})
        for n in pairs:
            ao, bo = cnt.get(('A_only', n), 0), cnt.get(('B_only', n), 0)
            rows.append(dict(species=sp, chr_pair=f'{n:02d}', A_only=ao, B_only=bo,
                             B_share=round(bo / max(ao + bo, 1), 3)))
        d = pd.DataFrame([r for r in rows if r['species'] == sp])
        more_b = int((d['B_only'] > d['A_only']).sum()); more_a = int((d['A_only'] > d['B_only']).sum())
        print(f'[{sp}] chromosome pairs with more B-only genes {more_b} / {len(d)} (more A-only {more_a}); '
              f'sign test P = {binomtest(more_b, more_b + more_a, 0.5).pvalue:.2e}; '
              f'B share per pair {d["B_share"].min():.2f}-{d["B_share"].max():.2f}')
    pd.DataFrame(rows).to_csv(f'{a.out}/fractionation_chrpairs{tag}.tsv', sep='\t', index=False)

    print('\n3. Lineage-specific losses (gene retained in that subgenome in every other called genome)')
    rows = []
    for f in genomes:
        others = [g for g in genomes if g != f]
        res = {}
        for s in 'AB':
            M = np.array([C[g][s] for g in others])
            called = (M != None).sum(axis=0)
            all_ret = ((M == 'R') | (M == None)).all(axis=0)
            og = np.array([g in OUTGROUPS for g in others])
            og_ret = (M[og] == 'R').any(axis=0) if og.any() else np.ones(len(genes), bool)
            risk = all_ret & (called >= MIN_OTHERS) & og_ret & (C[f][s] != None)
            res[s] = (int(risk.sum()), int((risk & (C[f][s] == 'L')).sum()))
        (nA, lA), (nB, lB) = res['A'], res['B']
        orr, p = fisher_exact([[lA, nA - lA], [lB, nB - lB]])
        rows.append(dict(focal=f, at_risk_A=nA, lost_A=lA, rate_A=round(lA / max(nA, 1), 5), at_risk_B=nB,
                         lost_B=lB, rate_B=round(lB / max(nB, 1), 5), OR_A_vs_B=round(orr, 3), fisher_p=f'{p:.2e}'))
    t3 = pd.DataFrame(rows)
    t3.to_csv(f'{a.out}/fractionation_lineage_specific{tag}.tsv', sep='\t', index=False)
    print(t3.to_string(index=False))
    print(f'\n-> {a.out}/fractionation_genomes{tag}.tsv, fractionation_chrpairs{tag}.tsv, fractionation_lineage_specific{tag}.tsv')


if __name__ == '__main__':
    main()
