#!/usr/bin/env python3
import argparse, os
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, fisher_exact

T_METH, T_FC, MIN_READS, N_PERM, SEED = 0.3, 1.0, 10, 10000, 1


def classify(dm, fc, t, f):
    a = int(((dm <= -t) & (fc >= f)).sum())
    b = int(((dm >= t) & (fc <= -f)).sum())
    return a, b


def perm_share(dm, fc, t, f, n, rng):
    sh = np.empty(n)
    for k in range(n):
        p = rng.permutation(dm)
        a = ((p <= -t) & (fc >= f)).sum()
        b = ((p >= t) & (fc <= -f)).sum()
        sh[k] = a / (a + b) if a + b else np.nan
    return sh


def pair_table(base, sp, tissue, ind):
    m = pd.read_csv(f'{base}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
    m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)][['A_gene', 'B_gene', 'HE', 'Ks_YN00']]
    me = pd.read_csv(f'{base}/meth/{sp}_{tissue}.gene_meth.tsv', sep='\t').set_index('gene')
    tp = pd.read_csv(f'{base}/rna/counts/{sp}.tpm.tsv', sep='\t').set_index('gene')
    if ind == 'pooled':
        meth = me['rep1_prom_meth'] + me['rep2_prom_meth']
        tot = me['rep1_prom_total'] + me['rep2_prom_total']
        cols = [c for c in tp.columns if c.startswith(f'{tissue}_')]
        tpm = tp[cols].mean(axis=1)
    else:
        meth, tot = me[f'rep{ind}_prom_meth'], me[f'rep{ind}_prom_total']
        tpm = tp[f'{tissue}_{ind}']
    lev = meth / tot.where(tot > 0)
    d = m.copy()
    for s in 'AB':
        g = d[f'{s}_gene']
        d[f'tot_{s}'] = tot.reindex(g).values
        d[f'meth_{s}'] = lev.reindex(g).values
        d[f'tpm_{s}'] = tpm.reindex(g).values
    keep = (d['tot_A'] >= MIN_READS) & (d['tot_B'] >= MIN_READS) & \
           (np.maximum(d['tpm_A'], d['tpm_B']) >= 1) & d['tpm_A'].notna() & d['tpm_B'].notna()
    d = d[keep].copy()
    d['dMeth'] = d['meth_B'] - d['meth_A']
    d['log2FC'] = np.log2((d['tpm_B'] + 1) / (d['tpm_A'] + 1))
    d['species'], d['tissue'], d['individual'] = sp, tissue, str(ind)
    return d


def summarise(d, rng, n_perm):
    dm, fc = d['dMeth'].values, d['log2FC'].values
    rho, p_rho = spearmanr(dm, fc)
    a, b = classify(dm, fc, T_METH, T_FC)
    sh = perm_share(dm, fc, T_METH, T_FC, n_perm, rng)
    obs = a / (a + b) if a + b else np.nan
    mu = np.nanmean(sh)
    p_perm = (np.sum(np.abs(sh - mu) >= abs(obs - mu)) + 1) / (n_perm + 1)
    am_bl = int(((dm <= -T_METH) & (fc <= -T_FC)).sum())
    bm_al = int(((dm >= T_METH) & (fc >= T_FC)).sum())
    orr, p_or = fisher_exact([[a, am_bl], [bm_al, b]])
    low_tpm = np.minimum(d['tpm_A'].values, d['tpm_B'].values)
    a_near = int(((dm <= -T_METH) & (fc >= T_FC) & (low_tpm < 1)).sum())
    b_near = int(((dm >= T_METH) & (fc <= -T_FC) & (low_tpm < 1)).sum())
    return dict(n_pairs=len(d), rho=round(rho, 4), rho2=round(rho ** 2, 5), p_rho=f'{p_rho:.2e}',
                median_dMeth=round(np.median(dm), 4), median_log2FC=round(np.median(fc), 4),
                n_A_silenced=a, n_B_silenced=b, share_A=round(obs, 4),
                perm_null_share_A=round(mu, 4), perm_lo95=round(np.nanpercentile(sh, 2.5), 4),
                perm_hi95=round(np.nanpercentile(sh, 97.5), 4), perm_p=f'{p_perm:.2e}',
                n_Ameth_Blow=am_bl, n_Bmeth_Alow=bm_al, coupling_OR=round(orr, 3), coupling_p=f'{p_or:.2e}',
                A_sil_near_silent=a_near, B_sil_near_silent=b_near)


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    ap.add_argument('--perm', type=int, default=N_PERM)
    a = ap.parse_args()
    out = f'{a.base}/analysis'
    os.makedirs(out, exist_ok=True)
    rng = np.random.default_rng(SEED)

    rows, grid, pairs = [], [], []
    for sp in ('tl', 'cx'):
        for tissue in ('eye', 'liver'):
            per_ind = {}
            for ind in (1, 2, 'pooled'):
                d = pair_table(a.base, sp, tissue, ind)
                per_ind[ind] = d
                pairs.append(d)
                for pset, dd in (('all', d), ('noHE', d[d['HE'] == 'none'])):
                    r = dict(species=sp, tissue=tissue, individual=ind, pair_set=pset)
                    r.update(summarise(dd, rng, a.perm))
                    rows.append(r)
                    print('\t'.join(str(r[k]) for k in ('species', 'tissue', 'individual', 'pair_set', 'n_pairs',
                                                         'rho', 'n_A_silenced', 'n_B_silenced', 'share_A',
                                                         'perm_null_share_A', 'perm_p', 'coupling_OR', 'coupling_p')),
                          flush=True)
            x = per_ind[1].merge(per_ind[2], on=['A_gene', 'B_gene'], suffixes=('_1', '_2'))
            print(f'  {sp} {tissue}: individual 1 vs 2 (n={len(x)}): Spearman log2FC '
                  f'{spearmanr(x["log2FC_1"], x["log2FC_2"])[0]:.3f}, dMeth {spearmanr(x["dMeth_1"], x["dMeth_2"])[0]:.3f}')
            d = per_ind['pooled']
            for t in (0.2, 0.3, 0.4):
                for f in (1.0, 1.5, 2.0):
                    dm, fc = d['dMeth'].values, d['log2FC'].values
                    aa, bb = classify(dm, fc, t, f)
                    sh = perm_share(dm, fc, t, f, 1000, rng)
                    obs = aa / (aa + bb) if aa + bb else np.nan
                    mu = np.nanmean(sh)
                    p = (np.sum(np.abs(sh - mu) >= abs(obs - mu)) + 1) / 1001
                    grid.append(dict(species=sp, tissue=tissue, t_meth=t, t_log2FC=f, n_A_silenced=aa,
                                     n_B_silenced=bb, share_A=round(obs, 4), perm_null_share_A=round(mu, 4),
                                     perm_p=f'{p:.3f}'))

    pd.DataFrame(rows).to_csv(f'{out}/methexpr_summary.tsv', sep='\t', index=False)
    pd.DataFrame(grid).to_csv(f'{out}/methexpr_grid.tsv', sep='\t', index=False)
    pd.concat(pairs).to_csv(f'{out}/methexpr_pairs.tsv.gz', sep='\t', index=False)
    print(f'-> {out}/methexpr_summary.tsv, methexpr_grid.tsv, methexpr_pairs.tsv.gz')


if __name__ == '__main__':
    main()
