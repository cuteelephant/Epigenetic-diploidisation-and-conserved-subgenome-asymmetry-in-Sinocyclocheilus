#!/usr/bin/env bash
set -euo pipefail

export BASE=$HOME/mbe_review
export OUT=$BASE/homoeolog
TOOLS=$(dirname "$(readlink -f "$0")")/homoeolog_tools.py
YN00=${YN00:-yn00}
THREADS=${THREADS:-32}
SPECIES=(tl cx)
declare -A HE=([tl]=TableS1_HE_regions_tianlinensis.tsv [cx]=TableS1_HE_regions_longibarbatus.tsv)

case ${1:-} in
check)
  for t in python3 lastdb lastal "$YN00"; do printf '%-8s %s\n' "$t" "$(command -v "$t" || echo MISSING)"; done
  python3 -c "import Bio, jcvi; print('biopython', Bio.__version__, '| jcvi OK')"
  python3 -c "import scipy; print('scipy', scipy.__version__)" 2>/dev/null || echo "scipy missing (Fisher P will be skipped)"
  ls -lh "$TOOLS"
  for sp in "${SPECIES[@]}"; do ls -lh "$BASE/${sp}_AB.fa" "$BASE/${sp}_AB.gff" "$BASE/${HE[$sp]}"; done
  ;;

prep)
  for sp in "${SPECIES[@]}"; do
    mkdir -p "$OUT/$sp"
    python3 "$TOOLS" prep --sp "$sp" --genome "$BASE/${sp}_AB.fa" --gff "$BASE/${sp}_AB.gff" --out "$OUT/$sp"
  done
  ;;

pairs)
  for sp in "${SPECIES[@]}"; do
    (
      cd "$OUT/$sp"
      python3 -m jcvi.compara.catalog ortholog "${sp}A" "${sp}B" --cscore=.99 --no_strip_names > jcvi.log 2>&1 || true
      [ -s "${sp}A.${sp}B.anchors" ] || { echo "[$sp] JCVI produced no anchors; see $OUT/$sp/jcvi.log"; exit 1; }
      python3 "$TOOLS" pairs --sp "$sp" --anchors "${sp}A.${sp}B.anchors" --genes "$sp.genes.tsv" --out "$sp.pairs.tsv"
    )
  done
  ;;

ks)
  for sp in "${SPECIES[@]}"; do
    d=$OUT/$sp
    python3 "$TOOLS" ks --sp "$sp" --pairs "$d/$sp.pairs.tsv" --cds-a "$d/${sp}A.cds" --cds-b "$d/${sp}B.cds" \
      --yn00 "$(command -v "$YN00")" --threads "$THREADS" --out "$d/$sp.ks.tsv"
  done
  ;;

summary)
  for sp in "${SPECIES[@]}"; do
    d=$OUT/$sp
    python3 "$TOOLS" summary --sp "$sp" --pairs "$d/$sp.pairs.tsv" --ks "$d/$sp.ks.tsv" --he "$BASE/${HE[$sp]}" \
      --out "$d/$sp.homoeolog_master.tsv" | tee "$d/$sp.summary.txt"
    echo
  done
  ;;

*)
  echo "Usage: bash $0 {check|prep|pairs|ks|summary}"; exit 1 ;;
esac
