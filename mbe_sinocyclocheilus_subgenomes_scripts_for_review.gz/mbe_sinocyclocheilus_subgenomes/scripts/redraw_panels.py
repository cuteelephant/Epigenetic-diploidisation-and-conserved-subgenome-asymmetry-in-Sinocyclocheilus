#!/usr/bin/env python3
"""Redraw Fig. 3c (compact, eye + liver) and Fig. S17b (clean labels) from figs_R2 source data."""
import os, sys, re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_figs as mf

R = sys.argv[1] if len(sys.argv) > 1 else 'figs_R2'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'figs_R2_fix'
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.family': 'Arial' if any('Arial' in f.name for f in matplotlib.font_manager.fontManager.ttflist)
                     else plt.rcParams['font.family'], 'font.size': 6, 'pdf.fonttype': 42})
MM = mf.MM
FS = 6


def out(fig, name):
    for e in ('pdf', 'png'):
        fig.savefig(f'{OUT}/{name}.{e}', dpi=600 if e == 'png' else None, bbox_inches='tight', pad_inches=0.02)
    plt.close(fig)
    print('->', f'{OUT}/{name}.pdf')


def fig3c():
    t = pd.read_csv(f'{R}/Fig3/source_data/Fig3c_GO_enrichment.tsv', sep='\t')
    t = t[t['tissue'].isin(['eye', 'liver'])].copy()
    t['_sp'] = t['species'].map({'tl': 0, 'cx': 1})
    t['_ti'] = t['tissue'].map({'eye': 0, 'liver': 1})
    t['_di'] = (~t['direction'].str.startswith('SubB')).astype(int)
    t = t.sort_values(['_sp', '_ti', '_di', 'fdr'])
    drop = {'oxoacid metabolic process', 'organic acid transmembrane transport'}
    rows = []
    for (sp, ti, di), g in t.groupby(['species', 'tissue', 'direction'], sort=False):
        g = g[~g['name'].isin(drop)].head(3)
        name = mf.SP_NAME[sp].replace(' ', '\\ ')
        rows.append(('h', f'$\\it{{{name}}}$ {ti}, {di}', None))
        rows += [('t', r.name, r) for r in g.itertuples()]
    n = len(rows)
    fig, ax = plt.subplots(figsize=(40 * MM, (2.45 * n + 4) * MM))
    y = np.arange(n)[::-1].astype(float)
    kmax = max(r[2].k for r in rows if r[0] == 't')
    for yi, (kind, lab, r) in zip(y, rows):
        if kind == 'h':
            ax.axhline(yi + 0.5, color=mf.LIGHTER, lw=0.4, zorder=0)
            continue
        c = mf.SUB['B'] if r.direction.startswith('SubB') else mf.SUB['A']
        ax.scatter([r.fold], [yi], s=4 + 26 * r.k / kmax, color=c, edgecolor=mf.INK, linewidth=0.3, zorder=3)
        ax.text(1.02, yi, mf.fmt_p(r.fdr), transform=ax.get_yaxis_transform(), va='center', ha='left', fontsize=FS - 0.5)
    ax.set_yticks(y, [lab for _, lab, _ in rows], fontsize=FS)
    for tl_, (kind, _, _) in zip(ax.get_yticklabels(), rows):
        if kind == 'h':
            tl_.set_fontweight('bold')
    ax.tick_params(axis='y', length=0, pad=1)
    ax.tick_params(axis='x', labelsize=FS, length=2, pad=1)
    xs = [r[2].fold for r in rows if r[0] == 't']
    ax.set_xlim(1.0, max(xs) * 1.1)
    ax.xaxis.set_major_locator(MaxNLocator(4))
    ax.set_ylim(-0.6, n - 0.4)
    ax.set_xlabel('Fold enrichment', fontsize=FS, labelpad=1)
    ax.text(1.02, 1.0, 'FDR', transform=ax.transAxes, ha='left', va='bottom', fontsize=FS - 0.5, color=mf.GREY)
    out(fig, 'Fig3c_GO_enrichment_compact')
    t.drop(columns=['_sp', '_ti', '_di']).to_csv(f'{OUT}/Fig3c_GO_enrichment_compact.tsv', sep='\t', index=False)


def clean_key(k):
    k = re.sub(r'\bind (\d)', r'ind. \1', k).replace('ind pooled', 'pooled')
    k = k.replace(' signed_M3', ', with ATAC').replace(' signed', '')
    return k


def figS17b():
    w = pd.read_csv(f'{R}/FigS17/source_data/FigS17b_noHE_robustness.tsv', sep='\t')
    order = {'tl': 0, 'cx': 1}
    w['_o'] = w['key'].str.split().str[0].map(order).fillna(0)
    stats = list(dict.fromkeys(w['stat']))
    fig, axes = plt.subplots(1, len(stats), figsize=(170 * MM, 62 * MM))
    for ax, st in zip(axes, stats):
        d = w[w['stat'] == st].sort_values(['_o', 'key'], kind='stable')
        y = np.arange(len(d))[::-1]
        for yi, r in zip(y, d.itertuples()):
            ax.plot([r.all, r.noHE], [yi, yi], color=mf.LIGHT, lw=1.0, zorder=1)
            ax.plot([r.all], [yi], marker='o', ms=3, color=mf.INK, ls='none', zorder=3)
            ax.plot([r.noHE], [yi], marker='o', ms=3, mfc='white', mec=mf.INK, mew=0.6, ls='none', zorder=3)
        ax.set_yticks(y, [clean_key(k) for k in d['key']], fontsize=FS)
        ax.set_ylim(-0.7, len(d) - 0.3)
        ax.set_title(st, fontsize=FS, pad=3)
        ax.tick_params(axis='y', length=0, pad=1)
        ax.tick_params(axis='x', labelsize=FS, length=2)
        ax.xaxis.set_major_locator(MaxNLocator(3))
        lo, hi = np.nanmin(d[['all', 'noHE']].values), np.nanmax(d[['all', 'noHE']].values)
        pad = (hi - lo) * 0.15 or 0.01
        ax.set_xlim(lo - pad, hi + pad)
    axes[-1].legend([Line2D([], [], marker='o', ms=3, color=mf.INK, ls='none'),
                     Line2D([], [], marker='o', ms=3, mfc='white', mec=mf.INK, ls='none')],
                    ['all pairs', 'pairs outside HE regions'], loc='upper left', bbox_to_anchor=(1.0, 1.0),
                    fontsize=FS, frameon=False)
    fig.subplots_adjust(wspace=0.75)
    out(fig, 'FigS17b_noHE_robustness_clean')


if __name__ == '__main__':
    fig3c()
    figS17b()
