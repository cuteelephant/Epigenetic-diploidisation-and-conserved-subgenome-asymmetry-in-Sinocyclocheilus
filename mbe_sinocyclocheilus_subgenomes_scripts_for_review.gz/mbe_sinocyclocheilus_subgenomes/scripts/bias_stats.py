#!/usr/bin/env python3
import argparse, os, re
import numpy as np
import pandas as pd
from scipy.special import digamma, polygamma
from scipy.stats import t as tdist, binomtest, rankdata

T_METH, T_FC, N_PERM, SEED, WIN = 0.3, 1.0, 1000, 1, 1_000_000


def trigamma_inv(x):
    y = 0.5 + 1.0 / x
    for _ in range(50):
        tri = polygamma(1, y)
        dif = tri * (1 - tri / x) / polygamma(2, y)
        y = y + dif
        if np.all(np.abs(dif / y) < 1e-8):
            break
    return y


def moderated_t(r):
    n = r.shape[1]
    d = n - 1
    m, s2 = r.mean(1), r.var(1, ddof=1)
    s2 = np.maximum(s2, 1e-8)
    z = np.log(s2)
    e = z - digamma(d / 2) + np.log(d / 2)
    emean, evar = e.mean(), e.var(ddof=1) - polygamma(1, d / 2)
    if evar > 0:
        d0 = 2 * trigamma_inv(evar)
        s02 = np.exp(emean + digamma(d0 / 2) - np.log(d0 / 2))
        post = (d0 * s02 + d * s2) / (d0 + d)
        df = d0 + d
    else:
        d0, post, df = np.inf, np.full_like(s2, np.exp(emean)), 1e6
    tt = m / np.sqrt(post / n)
    return m, tt, 2 * tdist.sf(np.abs(tt), df), d0


def bh(p):
    p = np.asarray(p)
    o = np.argsort(p)
    q = p[o] * len(p) / np.arange(1, len(p) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty_like(q)
    out[o] = np.minimum(q, 1)
    return out


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    a = ap.parse_args()
    B, rng = a.base, np.random.default_rng(SEED)
    crows, krows, trows = [], [], []
    pairs = pd.read_csv(f'{B}/analysis/methexpr_pairs.tsv.gz', sep='\t', dtype={'individual': str, 'HE': str})
    pairs = pairs[pairs['individual'] == 'pooled']
    for sp in ('tl', 'cx'):
        m = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str, 'A_chr': str})
        m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)].sort_values(['A_chr', 'A_start']).reset_index(drop=True)
        tp = pd.read_csv(f'{B}/rna/counts/{sp}.tpm.tsv', sep='\t').set_index('gene')
        samples = [c for c in tp.columns if re.fullmatch(r'.+_\d+', c)]
        tissues = sorted({c.rsplit('_', 1)[0] for c in samples})
        fc_by_tissue = {}
        for tissue in tissues:
            reps = sorted(c for c in samples if c.rsplit('_', 1)[0] == tissue)
            A, Bm = tp.reindex(m['A_gene'])[reps].values, tp.reindex(m['B_gene'])[reps].values
            ok = np.isfinite(A).all(1) & np.isfinite(Bm).all(1) & (np.maximum(A.mean(1), Bm.mean(1)) >= 1)
            r = np.log2((Bm + 1) / (A + 1))
            fc = np.where(ok, r.mean(1), np.nan)
            fc_by_tissue[tissue] = fc
            row = dict(species=sp, tissue=tissue, replicates=len(reps), n_pairs=int(ok.sum()))
            if len(reps) >= 2:
                mm, tt, p, d0 = moderated_t(r[ok])
                q = bh(p)
                sig = q < 0.05
                row.update(prior_df=round(float(d0), 2), B_biased=int((sig & (mm >= T_FC)).sum()),
                           A_biased=int((sig & (mm <= -T_FC)).sum()), sig_lt2fold=int((sig & (np.abs(mm) < T_FC)).sum()),
                           not_sig=int((~sig).sum()))
                row['test'] = 'moderated t, FDR < 0.05'
            else:
                mm = r[ok, 0]
                row.update(B_biased=int((mm >= T_FC).sum()), A_biased=int((mm <= -T_FC).sum()),
                           not_sig=int((np.abs(mm) < T_FC).sum()))
                row['test'] = 'fold change only (1 sample)'
            nb, na = row['B_biased'], row['A_biased']
            row.update(share_biased=round((nb + na) / row['n_pairs'], 4), B_share_of_biased=round(nb / max(nb + na, 1), 4),
                       binom_p=binomtest(nb, nb + na, 0.5).pvalue if nb + na else np.nan,
                       median_log2FC=round(float(np.nanmedian(fc)), 4))
            crows.append(row)

            for pset in ('all', 'noHE'):
                keep = ok & ((m['HE'] == 'none').values if pset == 'noHE' else True)
                d = pd.DataFrame({'chr': m['A_chr'], 'pos': m['A_start'], 'fc': fc})[keep]
                d = d[d.groupby('chr')['fc'].transform('size') > 10]
                grp = pd.factorize(d['chr'])[0]
                wcode = pd.factorize(d['chr'].astype(str) + ':' + (d['pos'] // WIN).astype(str))[0]
                rk = rankdata(d['fc'].values)
                cw = np.bincount(wcode)

                def stats(v):
                    out = []
                    for lag in (1, 2, 3):
                        msk = grp[:-lag] == grp[lag:]
                        out.append(np.corrcoef(v[:-lag][msk], v[lag:][msk])[0, 1])
                    out.append(np.var(np.bincount(wcode, weights=v) / cw))
                    return out
                obs = np.array(stats(rk)[:3] + [stats(d['fc'].values)[3]])
                null = np.empty((N_PERM, 4))
                for b in range(N_PERM):
                    o = np.lexsort((rng.random(len(rk)), grp))
                    st_r, st_v = stats(rk[o]), stats(d['fc'].values[o])
                    null[b] = st_r[:3] + [st_v[3]]
                for k, lab in enumerate(('lag1_rho', 'lag2_rho', 'lag3_rho', 'var_1Mb_mean')):
                    mu, sd = null[:, k].mean(), null[:, k].std()
                    krows.append(dict(species=sp, tissue=tissue, pair_set=pset, n_pairs=len(d), statistic=lab,
                                      observed=round(obs[k], 5), null_mean=round(mu, 5), z=round((obs[k] - mu) / sd, 2),
                                      p_perm=(np.sum(null[:, k] >= obs[k]) + 1) / (N_PERM + 1)))

        idx = {(x, y): i for i, (x, y) in enumerate(zip(m['A_gene'], m['B_gene']))}
        for dt in ('eye', 'liver'):
            d = pairs[(pairs['species'] == sp) & (pairs['tissue'] == dt)]
            cand = ((d['dMeth'] <= -T_METH) & (d['log2FC'] >= T_FC)) | ((d['dMeth'] >= T_METH) & (d['log2FC'] <= -T_FC))
            biased = (d['log2FC'].abs() >= T_FC) & (d['dMeth'].abs() < T_METH)
            ii = np.array([idx.get((x, y), -1) for x, y in zip(d['A_gene'], d['B_gene'])])
            sgn = np.sign(d['log2FC'].values)
            for ot in tissues:
                if ot == dt:
                    continue
                f = np.array([fc_by_tissue[ot][i] if i >= 0 else np.nan for i in ii])
                for name, sel in (('candidate', cand.values), ('biased_no_meth_difference', biased.values)):
                    s_ = sel & np.isfinite(f)
                    same = (np.sign(f[s_]) == sgn[s_])
                    rev = (f[s_] * sgn[s_]) <= -T_FC
                    trows.append(dict(species=sp, defined_in=dt, other_tissue=ot, pairs=name, n=int(s_.sum()),
                                      frac_same_lower_copy=round(float(same.mean()), 4),
                                      frac_reversed_2fold=round(float(rev.mean()), 4),
                                      median_log2_repressed_over_partner=round(float(np.median(-f[s_] * sgn[s_])), 4)))
    C, K, T = pd.DataFrame(crows), pd.DataFrame(krows), pd.DataFrame(trows)
    os.makedirs(f'{B}/analysis', exist_ok=True)
    C.to_csv(f'{B}/analysis/bias_classes.tsv', sep='\t', index=False)
    K.to_csv(f'{B}/analysis/bias_clustering.tsv', sep='\t', index=False)
    T.to_csv(f'{B}/analysis/bias_tissue_consistency.tsv', sep='\t', index=False)
    with pd.option_context('display.width', 250, 'display.max_columns', 30):
        print('1. Homoeolog expression bias classes')
        print(C.to_string(index=False, float_format=lambda v: f'{v:.3g}'))
        print('\n2. Clustering of log2FC along SubA chromosomes (vs permutation within chromosomes)')
        print(K[K['statistic'].isin(['lag1_rho', 'var_1Mb_mean'])].to_string(index=False, float_format=lambda v: f'{v:.3g}'))
        print('   (lag 2-3 in bias_clustering.tsv)')
        print('\n3. Tissue consistency of candidate repressed copies (summary over other tissues)')
        s = T.groupby(['species', 'defined_in', 'pairs'])[['frac_same_lower_copy', 'frac_reversed_2fold']].median()
        print(s.round(3).to_string())
        print('   (per tissue in bias_tissue_consistency.tsv)')
    print(f'-> {B}/analysis/bias_classes.tsv, bias_clustering.tsv, bias_tissue_consistency.tsv')


if __name__ == '__main__':
    main()
