#!/usr/bin/env python3
import argparse, json, os, re, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from meth_tools import load_regions

FLANK, PROM = 2000, 500


def read_frag(path):
    d = pd.read_csv(path, sep='\t', header=None, names=['chr', 's', 'e'], dtype={'chr': str, 's': np.int64, 'e': np.int64})
    cuts = {c: np.sort(np.concatenate([g['s'].values, g['e'].values - 1])) for c, g in d.groupby('chr', sort=False)}
    return d, cuts


def tss_table(base, sp):
    reg = load_regions(f'{base}/{sp}_AB.gff', f'{base}/homoeolog/{sp}/{sp}.genes.tsv', FLANK)
    reg['tss'] = np.where(reg['strand'] == '+', reg['b_start'] - 1, reg['b_end'] - 1)
    return reg[['gene', 'sub', 'chr', 'strand', 'tss']]


def tss_enrichment(cuts, tss):
    prof = np.zeros(2 * FLANK + 1)
    for c, g in tss.groupby('chr'):
        x = cuts.get(c)
        if x is None:
            continue
        for t, st in zip(g['tss'].values, g['strand'].values):
            i0, i1 = np.searchsorted(x, t - FLANK, 'left'), np.searchsorted(x, t + FLANK, 'right')
            off = x[i0:i1] - t
            if st == '-':
                off = -off
            np.add.at(prof, off + FLANK, 1)
    bg = (prof[:100].mean() + prof[-100:].mean()) / 2
    sm = np.convolve(prof / max(bg, 1e-9), np.ones(11) / 11, mode='same')
    return float(sm[FLANK - 50:FLANK + 51].max())


def read_peaks(path):
    p = pd.read_csv(path, sep='\t', header=None, usecols=[0, 1, 2], names=['chr', 's', 'e'], dtype={'chr': str})
    return p.sort_values(['chr', 's']).reset_index(drop=True)


def merged(p):
    out = {}
    for c, g in p.groupby('chr'):
        s, e = g['s'].values, g['e'].values
        o = np.argsort(s); s, e = s[o], e[o]
        ms, me = [s[0]], [e[0]]
        for a, b in zip(s[1:], e[1:]):
            if a <= me[-1]:
                me[-1] = max(me[-1], b)
            else:
                ms.append(a); me.append(b)
        out[c] = (np.array(ms), np.array(me))
    return out


def in_intervals(x, iv):
    s, e = iv
    k = np.searchsorted(s, x, 'right') - 1
    ok = k >= 0
    res = np.zeros(len(x), bool)
    res[ok] = x[ok] < e[k[ok]]
    return res


def overlaps(p, iv):
    res = np.zeros(len(p), bool)
    for c, idx in p.groupby('chr').indices.items():
        if c not in iv:
            continue
        s, e = iv[c]
        ps, pe = p['s'].values[idx], p['e'].values[idx]
        k = np.searchsorted(s, pe, 'left') - 1
        ok = k >= 0
        r = np.zeros(len(idx), bool)
        r[ok] = e[k[ok]] > ps[ok]
        res[idx] = r
    return res


def prom_counts(cuts, tss):
    n = np.zeros(len(tss))
    for c, idx in tss.groupby('chr').indices.items():
        x = cuts.get(c)
        if x is None:
            continue
        t = tss['tss'].values[idx]
        n[idx] = np.searchsorted(x, t + PROM, 'right') - np.searchsorted(x, t - PROM, 'left')
    return n


def cmd_qc(a):
    B = a.base
    sheet = pd.read_csv(f'{B}/atac/samples.tsv', sep='\t')
    rows, prom = [], {}
    for sp, g in sheet.groupby('species', sort=False):
        tss = tss_table(B, sp)
        peaks = {}
        for r in g.itertuples():
            pre = f'{sp}_{r.sample}'
            row = dict(species=sp, sample=r.sample, raw=r.raw)
            try:
                j = json.load(open(f'{B}/atac/clean/{pre}.fastp.json'))
                row['read_pairs'] = j['summary']['before_filtering']['total_reads'] // 2
            except (OSError, KeyError):
                pass
            bl = open(f'{B}/atac/bam/{pre}.bowtie2.log').read()
            m = re.search(r'([\d.]+)% overall alignment rate', bl)
            row['aligned_pct'] = float(m.group(1)) if m else np.nan
            md = open(f'{B}/atac/bam/{pre}.markdup.txt').read()
            rd, du = re.search(r'READ:\s*(\d+)', md), re.search(r'DUPLICATE TOTAL:\s*(\d+)', md)
            if rd and du:
                row['dup_pct'] = round(100 * int(du.group(1)) / int(rd.group(1)), 2)
            try:
                ix = pd.read_csv(f'{B}/atac/bam/{pre}.idxstats.txt', sep='\t', header=None, names=['chr', 'len', 'm', 'u'])
                row['chrM_pct'] = round(100 * ix.loc[ix['chr'] == 'chrM', 'm'].sum() / ix['m'].sum(), 2)
            except OSError:
                pass
            d, cuts = read_frag(f'{B}/atac/frag/{pre}.frag.bed.gz')
            L = d['e'] - d['s'] + 9
            row.update(final_fragments=len(d), NFR_frac=round(float((L < 147).mean()), 4),
                       mono_frac=round(float(((L >= 147) & (L < 294)).mean()), 4),
                       TSS_enrichment=round(tss_enrichment(cuts, tss), 2))
            pk = read_peaks(f'{B}/atac/peaks/{pre}_peaks.narrowPeak')
            peaks[r.sample] = pk
            iv = merged(pk)
            tot = sum(len(x) for x in cuts.values())
            inp = sum(int(in_intervals(x, iv[c]).sum()) for c, x in cuts.items() if c in iv)
            row.update(peaks=len(pk), FRiP=round(inp / tot, 4))
            pc = prom_counts(cuts, tss)
            prom[(sp, r.sample)] = np.log2(pc / tot * 1e6 + 1)
            rows.append(row)
            print(f'[{sp} {r.sample}] done', flush=True)
        s1, s2 = list(g['sample'])[:2]
        o12 = overlaps(peaks[s1], merged(peaks[s2])).mean()
        o21 = overlaps(peaks[s2], merged(peaks[s1])).mean()
        pooled = read_peaks(f'{B}/atac/peaks/{sp}_liver_pooled_peaks.narrowPeak')
        rep = pooled[overlaps(pooled, merged(peaks[s1])) & overlaps(pooled, merged(peaks[s2]))]
        rep.to_csv(f'{B}/atac/peaks/{sp}_liver.reproducible.bed', sep='\t', header=False, index=False)
        x, y = prom[(sp, s1)], prom[(sp, s2)]
        rows.append(dict(species=sp, sample='replicates', raw=f'{s1} vs {s2}',
                         peaks=len(rep), FRiP=np.nan, rep1_peaks_in_rep2=round(float(o12), 4),
                         rep2_peaks_in_rep1=round(float(o21), 4),
                         promoter_logCPM_r=round(float(np.corrcoef(x, y)[0, 1]), 4)))
    t = pd.DataFrame(rows)
    t.to_csv(f'{B}/atac/atac_qc.tsv', sep='\t', index=False)
    with pd.option_context('display.width', 250, 'display.max_columns', 30):
        print(t.to_string(index=False))
    print('ENCODE ATAC guidance: >= 25 M non-duplicate fragments per replicate (human), TSS enrichment > 5-7 '
          '(assembly-dependent), FRiP > 0.2, NFR and mono-nucleosome peaks present')
    print(f'-> {B}/atac/atac_qc.tsv, {B}/atac/peaks/<sp>_liver.reproducible.bed (reproducible peaks; "peaks" in the replicates row)')


MIN_PROM = 10


def cmd_promoter(a):
    B = a.base
    sheet = pd.read_csv(f'{B}/atac/samples.tsv', sep='\t')
    tot_rows = []
    for sp, g in sheet.groupby('species', sort=False):
        tss = tss_table(B, sp).reset_index(drop=True)
        out = tss[['gene', 'sub', 'chr', 'tss']].copy()
        for r in g.itertuples():
            _, cuts = read_frag(f'{B}/atac/frag/{sp}_{r.sample}.frag.bed.gz')
            out[r.sample] = prom_counts(cuts, tss).astype(int)
            tot_rows.append(dict(species=sp, sample=r.sample, cut_sites=sum(len(x) for x in cuts.values())))
        out['pooled'] = out[list(g['sample'])].sum(axis=1)
        win = pd.DataFrame({'chr': tss['chr'], 's': tss['tss'] - PROM, 'e': tss['tss'] + PROM + 1})
        rep = read_peaks(f'{B}/atac/peaks/{sp}_liver.reproducible.bed')
        out['in_peak'] = overlaps(win, merged(rep)).astype(int)
        out.to_csv(f'{B}/atac/promoter_counts_{sp}.tsv', sep='\t', index=False)
        print(f'[{sp}] genes {len(out)}; promoters in reproducible peaks {out["in_peak"].mean():.1%} '
              f'(SubA {out.loc[out["sub"] == "A", "in_peak"].mean():.1%}, SubB {out.loc[out["sub"] == "B", "in_peak"].mean():.1%})')
    pd.DataFrame(tot_rows).to_csv(f'{B}/atac/promoter_totals.tsv', sep='\t', index=False)
    print(f'-> {B}/atac/promoter_counts_<sp>.tsv')


def cmd_analysis(a):
    from scipy.stats import spearmanr, mannwhitneyu, fisher_exact, binomtest
    B = a.base
    pairs = pd.read_csv(f'{B}/analysis/methexpr_pairs.tsv.gz', sep='\t', dtype={'individual': str, 'HE': str})
    pairs = pairs[(pairs['individual'] == 'pooled') & (pairs['tissue'] == 'liver')]
    rows, Q = [], {}
    add = lambda **k: rows.append(k)
    for sp in ('tl', 'cx'):
        pc = pd.read_csv(f'{B}/atac/promoter_counts_{sp}.tsv', sep='\t').set_index('gene')
        reps = [c for c in pc.columns if c.startswith('liver_')]
        m = pd.read_csv(f'{B}/homoeolog/{sp}/{sp}.homoeolog_master.tsv', sep='\t', dtype={'HE': str})
        m = m[(m['qc_ks'] == 1) & (m['same_chr_number'] == 1)][['A_gene', 'B_gene', 'HE']].copy()
        for c in reps + ['pooled', 'in_peak']:
            for s in 'AB':
                m[f'{c}_{s}'] = pc[c].reindex(m[f'{s}_gene']).values
        for c in reps + ['pooled']:
            n = m[f'{c}_A'] + m[f'{c}_B']
            m[f'd_{c}'] = np.where(n >= (MIN_PROM * (len(reps) if c == 'pooled' else 1)),
                                   np.log2((m[f'{c}_B'] + 1) / (m[f'{c}_A'] + 1)), np.nan)
        ok = m[[f'd_{c}' for c in reps]].notna().all(axis=1)
        r, p = spearmanr(m.loc[ok, f'd_{reps[0]}'], m.loc[ok, f'd_{reps[1]}'])
        add(species=sp, test='replicate agreement of promoter asymmetry (Spearman)', n=int(ok.sum()), value=r, p=p)
        d = m['d_pooled'].dropna()
        nb, na = int((d > 0).sum()), int((d < 0).sum())
        add(species=sp, test='median promoter asymmetry log2(B/A); share B > A', n=len(d), value=float(d.median()),
            p=binomtest(nb, nb + na).pvalue, extra=round(nb / (nb + na), 4))
        add(species=sp, test='promoters in reproducible peaks: SubB vs SubA', n=len(pc),
            value=float(pc.loc[pc['sub'] == 'B', 'in_peak'].mean() - pc.loc[pc['sub'] == 'A', 'in_peak'].mean()),
            extra=f"A {pc.loc[pc['sub'] == 'A', 'in_peak'].mean():.3f} B {pc.loc[pc['sub'] == 'B', 'in_peak'].mean():.3f}")
        x = m.merge(pairs[pairs['species'] == sp][['A_gene', 'B_gene', 'log2FC', 'dMeth']], on=['A_gene', 'B_gene'])
        x = x.dropna(subset=['d_pooled'])
        Q[sp] = x
        for pset, y in (('all', x), ('noHE', x[x['HE'] == 'none'])):
            r, p = spearmanr(y['d_pooled'], y['log2FC'])
            add(species=sp, test=f'promoter asymmetry vs expression bias log2FC ({pset})', n=len(y), value=r, p=p)
            r, p = spearmanr(y['d_pooled'], y['dMeth'])
            add(species=sp, test=f'promoter asymmetry vs promoter methylation dMeth ({pset})', n=len(y), value=r, p=p)
        b = x[(x['log2FC'].abs() >= 1) & (x['d_pooled'].abs() >= 1)]
        tab = [[int(((b['log2FC'] > 0) & (b['d_pooled'] > 0)).sum()), int(((b['log2FC'] > 0) & (b['d_pooled'] < 0)).sum())],
               [int(((b['log2FC'] < 0) & (b['d_pooled'] > 0)).sum()), int(((b['log2FC'] < 0) & (b['d_pooled'] < 0)).sum())]]
        orr, p = fisher_exact(tab)
        add(species=sp, test='coupling: >=2-fold expression bias with >=2-fold accessibility bias (OR, same direction)',
            n=int(b.shape[0]), value=orr, p=p, extra=f'concordant {tab[0][0] + tab[1][1]} discordant {tab[0][1] + tab[1][0]}')
        cand = ((x['dMeth'] <= -0.3) & (x['log2FC'] >= 1)) | ((x['dMeth'] >= 0.3) & (x['log2FC'] <= -1))
        biased = (x['log2FC'].abs() >= 1) & (x['dMeth'].abs() < 0.3)
        orient = -np.sign(x['log2FC']) * x['d_pooled']
        oc, ob = orient[cand], orient[biased]
        add(species=sp, test='lower copy minus partner accessibility: candidate repressed vs biased without dMeth',
            n=f'{len(oc)} vs {len(ob)}', value=float(oc.median()), extra=f'biased_no_meth {ob.median():.3f}; '
            f'lower copy less accessible: {(oc < 0).mean():.3f} vs {(ob < 0).mean():.3f}',
            p=mannwhitneyu(oc, ob).pvalue if len(oc) > 4 and len(ob) > 4 else np.nan)
    oA = dict(pd.read_csv(f'{B}/homoeolog/orth_tl_cx_A.tsv', sep='\t').values)
    oB = dict(pd.read_csv(f'{B}/homoeolog/orth_tl_cx_B.tsv', sep='\t').values)
    tl = Q['tl'].copy()
    tl['cxA'], tl['cxB'] = tl['A_gene'].map(oA), tl['B_gene'].map(oB)
    q = tl.merge(Q['cx'], left_on=['cxA', 'cxB'], right_on=['A_gene', 'B_gene'], suffixes=('_tl', '_cx'))
    dd = q['d_pooled_tl'] - q['d_pooled_cx']
    for lab, col in (('expression bias', 'log2FC'), ('promoter methylation', 'dMeth')):
        r, p = spearmanr(dd, q[f'{col}_tl'] - q[f'{col}_cx'])
        add(species='tl-cx', test=f'quartets: lineage-specific change in accessibility asymmetry vs {lab}', n=len(q), value=r, p=p)
    t_ = pd.DataFrame(rows)[['species', 'test', 'n', 'value', 'p', 'extra']]
    t_.to_csv(f'{B}/analysis/atac_summary.tsv', sep='\t', index=False)
    with pd.option_context('display.width', 250, 'display.max_colwidth', 110):
        print(t_.to_string(index=False, float_format=lambda v: f'{v:.4g}'))
    print(f'-> {B}/analysis/atac_summary.tsv')


def main():
    ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base', default=os.path.expanduser('~/mbe_review'))
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('qc'); sub.add_parser('promoter'); sub.add_parser('analysis')
    a = ap.parse_args()
    {'qc': cmd_qc, 'promoter': cmd_promoter, 'analysis': cmd_analysis}[a.cmd](a)


if __name__ == '__main__':
    main()
