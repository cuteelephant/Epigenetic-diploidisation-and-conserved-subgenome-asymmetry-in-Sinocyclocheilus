# Subgenome asymmetry and promoter methylation in *Sinocyclocheilus*

Analysis code for Mao et al., *Molecular Biology and Evolution* (MBE-26-0753).

**Requirements:** Python ≥ 3.10 with numpy, pandas, scipy, matplotlib, openpyxl and cooler. Also HISAT2, featureCounts, Bismark, bowtie2, MACS3, samtools, minimap2, JCVI/LAST, PAML `yn00`, and TOGA2 projections (set `TOGA2_DIR`).

All scripts read and write under `--base` (default `~/mbe_review`).

## Order

| Step | Command | Output |
|---|---|---|
| 1 | `homoeolog_pipeline.sh prep / pairs / ks / summary` | SubA–SubB homoeolog pairs, Ks |
| 2 | `quartet_pipeline.sh orth` | tl–cx orthologs |
| 3 | `rna_pipeline.sh index / align / count` | TPM |
| 4 | `wgbs_pipeline.sh prep / trim / align / extract`; `meth_regions.sh` | promoter and gene-body methylation |
| 5 | `atac_pipeline.sh index / trim / align / peaks`; `atac_tools.py qc / promoter` | liver promoter accessibility |
| 6 | `hic_te_prep.sh map / pc1` | 100-kb compartments, TE and TAD annotation |
| 7 | `te_polar_prep.sh orthks / align`; `te_polar.py polar` | TE polarisation |
| 8 | `he_power.py`; `he_calls.py` | homoeologous exchanges |
| 9 | `methexpr_analysis.py`; `quartet_pipeline.sh analyze`; `te_polar.py test`; `bias_stats.py`; `orth_omega.py`; `toga_loss.py`; `fractionation.py`; `joint_model.py features / model`; `atac_tools.py analysis`; `go_enrich.py`; `meth_profile.py`; `extra_tests.py all` | statistics (`analysis/`) |
| 10 | `make_figs.py all`; `compile_tables.py` | figure panels and supplementary tables |
| 11 | `redraw_panels.py <figs_dir> <out_dir>` | final versions of Fig. 3c and Fig. S17b |
